# 키보드-터치 충돌 분석 및 수정 가이드

전수 분석 결과 **5가지 독립적인 충돌 문제** 발견.

---

## 발견된 충돌 요약

| 문제 | 심각도 | 발생 시나리오 | 증상 |
|---|---|---|---|
| [K1] 팝업 좀비 상태 | ★★★ | 팝업 열린 상태에서 키보드 화면 전환 | 터치 먹통, 키보드로만 조작 |
| [K2] currentScreen Race | ★★ | 터치/키보드 동시 화면 전환 | 엉뚱한 화면 표시 |
| [K3] changeState Race | ★★ | START 버튼과 키보드 '1' 동시 입력 | 상태 충돌 |
| [K4] UI 상태 변수 Race | ★ | helpPageIndex 등 동시 변경 | 페이지 점프 |
| [K5] PIN 우회 | ★★★ | PIN 입력 중 키보드 화면 전환 | 권한 우회 |

---

## [K1] 팝업 좀비 상태 ★★★

**파일**: `USB_Keyboard.cpp` — `processKeyboardCommand()`

**시나리오**:
```
1. PID 화면에서 Kp 팝업 열림 → popupActive = true
2. 키보드 '5' 누름 → processKeyboardCommand(5)
3. currentScreen = SCREEN_STATISTICS 직접 대입
4. screenNeedsRedraw = true
5. 다음 프레임: updateUI() → 통계 화면 그려짐
6. 하지만 popupActive는 여전히 true
7. 터치 입력: handlePopupTouch()가 터치를 모두 소비
8. 통계 화면 조작 불가능 (터치 먹통)
```

**근본 원인**:
- `processKeyboardCommand()`가 `popupActive` 상태를 전혀 체크하지 않음
- 팝업이 열려있어도 화면 전환 명령이 그대로 실행됨
- 팝업을 닫는 로직 없이 `currentScreen`만 바뀜

**수정**:
```cpp
void processKeyboardCommand(uint8_t key) {
  // [K1] 팝업 활성화 중이면 화면 전환 차단 (ESC/취소만 허용)
  if (popupActive) {
    if (key == 0x1B || key == 0x08 || key == 0x7F) {  // ESC, BS, DEL
      hidePopup();
      return;
    }
    Serial.println("[키보드] 팝업 활성 중 — 다른 명령 차단");
    return;  // 모든 화면 전환 차단
  }
  // ... 이후 정상 처리
}
```

**효과**: 팝업 열린 상태에서 키보드 명령 무시 → 팝업 닫기 후에만 화면 전환 가능.

---

## [K2] currentScreen Race Condition ★★

**파일**: `USB_Keyboard.cpp` 16곳

**문제**:
```cpp
// 키보드 (uiUpdateTask 50ms 주기)
currentScreen = SCREEN_STATISTICS;   // 직접 대입
screenNeedsRedraw = true;

// 터치 (uiUpdateStep 내부)
if (screenNeedsRedraw) {
    switch (currentScreen) {  // ← 키보드가 중간에 바꿀 수 있음
        case SCREEN_MAIN: ...
```

`currentScreen` 변수에 대한 Mutex 보호가 전혀 없습니다.  
키보드와 터치가 동시에 `currentScreen`을 읽고 쓰면:
- 키보드가 SCREEN_STATISTICS로 바꿈
- 동시에 터치가 SCREEN_PID로 바꿈
- `screenNeedsRedraw`는 true인데 어떤 화면을 그릴지 불명확

**수정**: `uiManager.setScreen()` 경유 → 내부 Mutex 보호

```cpp
// 기존
currentScreen = SCREEN_STATISTICS;
screenNeedsRedraw = true;

// 수정
uiManager.setScreen(SCREEN_STATISTICS);  // Mutex + needsRedraw 자동
```

개선판 UIManager.cpp에서 `setScreen()`은 이미 `g_screenMutex`로 보호됨.

---

## [K3] changeState() Race Condition ★★

**파일**: `StateMachine.cpp` — `changeState()`

**시나리오**:
```
터치: START 버튼 누름 → handleMainTouch() → changeState(STATE_VACUUM_ON)
키보드: 동시에 '1' 누름 → processKeyboardCommand() → changeState(STATE_VACUUM_ON)

두 호출이 거의 동시에 들어오면:
  currentState 읽기/쓰기 Race
  previousState 저장 오류
  stateStartTime 중복 설정
```

**근본 원인**: `changeState()` 함수가 Mutex로 보호되지 않음.

**수정**: Mutex 추가

```cpp
static SemaphoreHandle_t g_stateMutex = nullptr;

void changeState(SystemState newState) {
  if (xSemaphoreTake(g_stateMutex, pdMS_TO_TICKS(100)) != pdTRUE) {
    Serial.println("[StateMachine] Mutex 획득 실패");
    return;
  }

  if (currentState == newState) {
    xSemaphoreGive(g_stateMutex);
    return;
  }

  previousState  = currentState;
  currentState   = newState;
  stateStartTime = millis();

  xSemaphoreGive(g_stateMutex);
}
```

`StateMachine.cpp` 또는 `main.cpp`의 `setup()`에서 초기화:
```cpp
void initStateMachine() {
  g_stateMutex = xSemaphoreCreateMutex();
}
```

---

## [K4] UI 상태 변수 Race ★

**파일**: `USB_Keyboard.cpp` + 각 화면 터치 핸들러

**영향 받는 변수**:
- `helpPageIndex` (도움말 페이지 번호)
- `currentMode` (MODE_MANUAL/AUTO/PID)
- 기타 화면별 인덱스 변수

**문제**: 키보드와 터치가 동시에 `helpPageIndex++` 하면 2페이지 점프.

**심각도**: 낮음 (UX 불편 수준, 시스템 안정성 영향 없음)

**수정**: 
1. **간단한 방법**: 키보드 명령 처리 시 `uiManager.getCurrentScreen()` 체크 추가
2. **완전한 방법**: 화면별 상태 구조체를 각 화면 클래스 내부로 캡슐화

현재는 간단한 방법 적용 (수정본에 포함됨):
```cpp
ScreenType current = uiManager.getCurrentScreen();
if (current == SCREEN_HELP) {
  helpPageIndex++;  // Race 가능하지만 영향 미미
}
```

---

## [K5] PIN 입력 중 키보드로 권한 우회 ★★★

**파일**: `USB_Keyboard.cpp` — `processKeyboardCommand()`

**시나리오**:
```
1. 작업자 모드에서 캘리브레이션 화면 진입 시도
2. PIN 입력 화면 표시 (4자리 숫자 패드)
3. 키보드 '7' 누름 → processKeyboardCommand(7)
4. currentScreen = SCREEN_TIMING_SETUP 직접 대입
5. PIN 우회 완료, 관리자 권한 화면 접근
```

**근본 원인**: 키보드가 PIN 화면 상태를 전혀 체크하지 않음.

**수정**:
```cpp
#include "UI_AccessControl.h"  // isPinScreenActive()

void processKeyboardCommand(uint8_t key) {
  // [K5] PIN 화면 활성화 중이면 모든 키보드 입력 차단
  if (isPinScreenActive()) {
    Serial.println("[키보드] PIN 입력 중 — 키보드 차단");
    return;
  }
  // ... 정상 처리
}
```

**대안**: PIN 입력 화면에 키보드 숫자 입력도 연동
- 더 나은 UX
- PIN 화면에서 키보드로 숫자 입력 가능하도록 개선

---

## 처리 우선순위

키보드와 터치의 실행 순서 (Tasks.cpp uiUpdateStep):
```cpp
1. handleTouch()       // 터치 우선
2. handleKeyboardInput() // 키보드 후순위
3. updateUI()          // 화면 그리기
```

터치가 키보드보다 **먼저** 처리됩니다.  
같은 프레임에서 터치+키보드 동시 입력 시 **터치가 이김**.

---

## 적용 방법

### Step 1 — USB_Keyboard.cpp 교체

`USB_Keyboard_fixed.cpp` 전체로 교체.

필요한 include 추가:
```cpp
#include "UIManager.h"
#include "UI_AccessControl.h"
```

필요한 extern 추가:
```cpp
extern UIManager uiManager;
extern bool popupActive;
```

### Step 2 — StateMachine.cpp 수정

`changeState()` 함수를 `StateMachine_mutex.cpp`의 버전으로 교체.

`StateMachine.h`에 선언 추가:
```cpp
void initStateMachine();  // Mutex 초기화
```

`main.cpp` `setup()` 내:
```cpp
void setup() {
  // ... 기존 초기화 ...
  initStateMachine();  // [K3] 상태 전이 Mutex 초기화
  // ...
}
```

### Step 3 — UIManager.cpp 확인

개선판 UIManager.cpp의 `setScreen()` 함수에 이미 Mutex 보호가 있는지 확인:
```cpp
void UIManager::setScreen(ScreenType screen) {
    if (xSemaphoreTake(g_screenMutex, pdMS_TO_TICKS(10)) == pdTRUE) {
        // ...
        xSemaphoreGive(g_screenMutex);
    }
}
```

없다면 추가 필요.

---

## 테스트 시나리오

### 1. 팝업 좀비 상태 재현 (수정 전)
```
1. PID 화면 진입
2. Kp 편집 버튼 터치 → 팝업 열림
3. 키보드 '5' 누름 (통계 화면)
4. 확인: 화면은 통계인데 터치가 전부 먹히지 않음
```

### 2. 팝업 좀비 상태 수정 확인 (수정 후)
```
1. 위와 동일
2. 키보드 '5' 누름
3. 확인: "팝업 활성 중 — 다른 명령 차단" 시리얼 메시지
4. ESC 또는 Backspace 누름
5. 확인: 팝업 닫힘, 이후 키보드 '5' 정상 동작
```

### 3. START/STOP Race (수정 전/후)
```
수정 전: 터치 START + 키보드 '1' 동시 → 시리얼에 상태전이 2번 출력
수정 후: 터치 START + 키보드 '1' 동시 → Mutex로 순차 처리, 1번만 출력
```

### 4. PIN 우회 (수정 전)
```
1. 작업자 모드
2. 설정 → 캘리브레이션 터치 (접근 거부, PIN 화면 표시)
3. 키보드 '7' 누름
4. 확인: 타이밍 설정 화면으로 이동 (권한 우회)
```

### 5. PIN 우회 수정 확인 (수정 후)
```
1. 위와 동일
2. 키보드 '7' 누름
3. 확인: "PIN 입력 중 — 키보드 차단" 메시지, 화면 이동 안 됨
```

---

## 전체 체크리스트

```
[K1] ✅ USB_Keyboard.cpp — popupActive 체크 + ESC로 팝업 닫기
[K2] ✅ USB_Keyboard.cpp — currentScreen 직접 대입 → uiManager.setScreen()
[K3] ✅ StateMachine.cpp — changeState() Mutex 보호
[K4] ✅ USB_Keyboard.cpp — getCurrentScreen() 안전한 읽기
[K5] ✅ USB_Keyboard.cpp — isPinScreenActive() 체크 추가
[K2] □  UIManager.cpp 확인 — setScreen() Mutex 있는지 (개선판에 이미 포함)
[K3] □  main.cpp setup() — initStateMachine() 호출 추가
```

---

## 추가 개선 제안 (선택사항)

### PIN 화면 키보드 통합

현재는 PIN 입력 중 키보드를 완전히 차단하지만, 더 나은 UX는:
```cpp
// UI_AccessControl.cpp handlePinInputTouch() 수정
void handleKeyboardOnPinScreen(uint8_t key) {
  if (key >= '0' && key <= '9') {
    // 숫자 입력 처리
    if (g_pinLen < PIN_MAX_DIGITS) {
      g_pinInput[g_pinLen++] = key;
      drawPinInputScreen();
    }
  } else if (key == '\r' || key == '\n') {
    // Enter → PIN 검증 (OK 버튼과 동일)
  } else if (key == 0x08 || key == 0x7F) {
    // Backspace → 지우기
  } else if (key == 0x1B) {
    // ESC → 취소
  }
}
```

### 키보드 도움말 표시

첫 화면 또는 도움말 화면에 키보드 단축키 안내:
```
────────────────────────────
  키보드 단축키
────────────────────────────
  0: 메인 화면
  1: 시작
  2: 정지
  3: 모드 전환
  4: 알람 리셋
  5: 통계
  *: 설정
  ESC: 메인으로
  Backspace: 뒤로
────────────────────────────
```
