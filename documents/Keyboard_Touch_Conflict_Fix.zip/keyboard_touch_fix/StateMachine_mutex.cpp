// ================================================================
// StateMachine.cpp — changeState() Mutex 보호 추가
//
// [K3] 문제: 터치 START 버튼과 키보드 '1' 동시 입력 시
//            두 곳에서 동시에 changeState(STATE_VACUUM_ON) 호출
//            → currentState 변수 Race Condition
//
// 수정: changeState() 진입 시 Mutex 획득
//       중복 진입 방지 (이미 동일 상태면 즉시 반환)
// ================================================================

#include "StateMachine.h"
#include "Config.h"
#include "Control.h"

#ifdef ENABLE_VOICE_ALERTS
#include "../include/VoiceAlert.h"
extern VoiceAlert voiceAlert;
#endif

extern SystemState currentState;
extern SystemState previousState;
extern uint32_t stateStartTime;
extern bool screenNeedsRedraw;

// [K3] 상태 전이 Mutex 추가
static SemaphoreHandle_t g_stateMutex = nullptr;

// ================================================================
// StateMachine 초기화
// ================================================================
void initStateMachine() {
  if (g_stateMutex == nullptr) {
    g_stateMutex = xSemaphoreCreateMutex();
    if (g_stateMutex == nullptr) {
      Serial.println("[StateMachine] ⚠️  Mutex 생성 실패!");
    } else {
      Serial.println("[StateMachine] Mutex 생성 완료");
    }
  }
}

// ================================================================
// [K3] 상태 전이 — Mutex 보호
// ================================================================
void changeState(SystemState newState) {
  // [K3] Mutex 획득 (100ms 타임아웃)
  if (g_stateMutex == nullptr || 
      xSemaphoreTake(g_stateMutex, pdMS_TO_TICKS(100)) != pdTRUE) {
    Serial.println("[StateMachine] ⚠️  Mutex 획득 실패 — 상태 전이 건너뜀");
    return;
  }

  // 중복 진입 방지
  if (currentState == newState) {
    xSemaphoreGive(g_stateMutex);
    return;
  }

  previousState  = currentState;
  currentState   = newState;
  stateStartTime = millis();
  screenNeedsRedraw = true;

  Serial.printf("[상태 전이] %s → %s\n",
                getStateName(previousState),
                getStateName(currentState));

  // 음성 알림
#ifdef ENABLE_VOICE_ALERTS
  if (voiceAlert.isOnline() && voiceAlert.isAutoVoiceEnabled()) {
    voiceAlert.playStateMessage(newState);
  }
#endif

  // 상태 진입 시 초기화
  if (newState == STATE_WAIT_REMOVAL) {
    // 대기 상태 초기화 로직 (기존 코드 유지)
  }

  // [K3] Mutex 해제
  xSemaphoreGive(g_stateMutex);
}

// ================================================================
// getStateName() — Mutex 불필요 (읽기 전용 문자열 반환)
// ================================================================
const char* getStateName(SystemState state) {
  switch (state) {
    case STATE_IDLE:           return "대기";
    case STATE_VACUUM_ON:      return "진공 동작";
    case STATE_WAIT_REMOVAL:   return "제품 제거 대기";
    case STATE_RELEASE:        return "압력 해제";
    case STATE_ERROR:          return "에러";
    default:                   return "알 수 없음";
  }
}
