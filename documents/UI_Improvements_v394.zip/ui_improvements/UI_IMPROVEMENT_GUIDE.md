# UI/UX 개선 통합 가이드 — v3.9.4 → v3.9.5

개선 항목 12가지 [U1]~[U12] 전부 반영

---

## 신규/변경 파일 목록

| 파일 | 상태 | 대상 원본 |
|---|---|---|
| `src/UI_Screen_Main.cpp` | **교체** | 기존 동일 파일 |
| `src/UI_Screen_Alarm.cpp` | **교체** | 기존 동일 파일 |
| `src/UI_Screen_Settings.cpp` | **교체** | 기존 동일 파일 |
| `src/UIManager.cpp` | **교체** | 기존 동일 파일 |
| `src/UI_Popup.cpp` | **교체** | 기존 동일 파일 |
| `src/UI_AccessControl.cpp` | **신규 추가** | — |
| `src/UI_Screen_EStop.cpp` | **신규 추가** | — |
| `src/UIComponents_patch.cpp` | 참고용 패치 | `UIComponents.cpp` 내 함수 교체 |
| `include/UIManager.h` | **교체** | 기존 동일 파일 |
| `include/UI_AccessControl.h` | **신규 추가** | — |

---

## Step 1 — Config.h 추가 항목

```cpp
// ── 기존 SCREEN_WATCHDOG_STATUS 뒤에 추가 ──
enum ScreenType {
    // ... 기존 항목들 ...
    SCREEN_WATCHDOG_STATUS,
    SCREEN_ESTOP,          // ← [U5] 비상정지 전용 화면 추가
    // ... ifdef 블록들 ...
};
```

```cpp
// ── 압력/온도 임계값 상수 (main_hardened.cpp와 공유) ──
// Config.h 또는 HardenedConfig.h에 없으면 추가
#ifndef PRESSURE_TRIP_KPA
  #define PRESSURE_TRIP_KPA  -95.0f
#endif
#ifndef PRESSURE_ALARM_KPA
  #define PRESSURE_ALARM_KPA -80.0f
#endif
#ifndef PRESSURE_MIN_KPA
  #define PRESSURE_MIN_KPA   -100.0f
#endif
#ifndef PRESSURE_MAX_KPA
  #define PRESSURE_MAX_KPA    0.0f
#endif
#ifndef TEMP_TRIP_C
  #define TEMP_TRIP_C         75.0f
#endif
#ifndef TEMP_ALARM_C
  #define TEMP_ALARM_C        60.0f
#endif
#ifndef PIN_ESTOP
  #define PIN_ESTOP            0     // GPIO0 (main_hardened.cpp의 PIN::ESTOP와 동일)
#endif
```

---

## Step 2 — UIManager.h 멤버 추가

새 UIManager.h의 private 섹션에 Toast 관련 변수가 추가됩니다.
기존 UIManager.h를 신규 버전으로 교체하면 됩니다.

---

## Step 3 — ManagerUI.cpp / UI_Screens.cpp 중복 제거 [U2]

`canAccessScreen()` 함수가 두 곳에 있습니다.
두 파일에서 해당 함수 **본체를 삭제**하고,
`UI_AccessControl.h`를 include 추가하세요.

```cpp
// ManagerUI.cpp 수정
#include "../include/UI_AccessControl.h"
// bool canAccessScreen(ScreenType screen) { ... }  ← 이 함수 본체 삭제

// UI_Screens.cpp 수정
#include "../include/UI_AccessControl.h"
// bool canAccessScreen(ScreenType screen) { ... }  ← 이 함수 본체 삭제
```

선언부도 정리:
```cpp
// ManagerUI.h — 중복 선언 삭제
// bool canAccessScreen(ScreenType screen);   ← 삭제

// UI_Screens.h — 중복 선언 삭제
// bool canAccessScreen(ScreenType screen);   ← 삭제
```

대신 두 헤더에 `#include "UI_AccessControl.h"` 추가.

---

## Step 4 — UIComponents.cpp 함수 교체 [U7][U11][U12]

`UIComponents_patch.cpp`에 있는 함수들로
기존 `UIComponents.cpp`의 해당 함수 본체를 교체합니다.

교체 대상:
- `drawHeader()` → [U12] 건강도 아이콘 재설계
- `drawButton()` → [U7] strlen()*6 → textWidth()
- `drawNavBar()` → [U7] 중앙 정렬 수정
- `drawBadge()`  → [U7] 배지 너비 수정
- `drawManagerBadge()` → [U11] TFT_* 색상 제거

---

## Step 5 — vTaskDelay 호출 제거 [U3]

아래 4곳의 `vTaskDelay` 블로킹 코드를 제거합니다.

```cpp
// ❌ UI_Screen_Calibration.cpp:325
vTaskDelay(pdMS_TO_TICKS(3000));
// ✅ 교체: uiManager.showMessage("...", 3000); return;

// ❌ UI_Screen_Statistics.cpp:266
vTaskDelay(pdMS_TO_TICKS(2000));
// ✅ 교체: uiManager.showMessage("...", 2000); return;

// ❌ ManagerUI.cpp:156 (showPermissionDialog)
vTaskDelay(pdMS_TO_TICKS(3000));
// ✅ 교체: uiManager.showMessage(msg, 3000); return false;

// ❌ ManagerUI.cpp:225 (showAccessDenied)
vTaskDelay(pdMS_TO_TICKS(3000));
// ✅ 교체: showAccessDeniedAsync(screenName); (UI_AccessControl.h)
```

---

## Step 6 — UI_Screen_EStop.cpp include 추가 [U5]

`UI_Screen_EStop.cpp`가 `gpio_get_level` 을 사용하므로:

```cpp
// UI_Screen_EStop.cpp 상단 (이미 포함됨, 확인만)
#include <driver/gpio.h>
```

그리고 `UI_Screens.h`에 선언 추가:

```cpp
// UI_Screens.h
void drawEStopScreen();
void handleEStopTouch(uint16_t x, uint16_t y);
void recordEStopStart(ScreenType prevScreen);
```

---

## Step 7 — UIManager::update()에 팝업 long-press 추가 [U9]

```cpp
// UIManager.cpp의 update() 함수 내 추가
void UIManager::update() {
    // ... 기존 코드 ...
    updatePopupLongPress();   // ← [U9] 이 줄 추가
}
```

---

## Step 8 — main.cpp / Tasks.cpp 터치 디스패치 추가 [U5]

E-Stop 화면 터치를 처리하는 케이스 추가:

```cpp
// 기존 handleTouch() 스위치에 추가
case SCREEN_ESTOP:
    handleEStopTouch(x, y);
    break;
```

---

## Step 9 — g_estopActive 외부 변수 연결 [U5]

`UIManager.cpp`에서 참조하는 `g_estopActive`를
`main_hardened.cpp`의 `g_state`에서 읽도록 연결:

```cpp
// UIManager.cpp 상단 extern 선언 교체
// extern bool g_estopActive;   ← 이 방식 대신

// SharedState.h 또는 main_hardened.cpp에서 getter 제공
extern VacuumSystemState g_state;
// UIManager::update() 내에서:
bool g_estopActive = g_state.isEstop();
```

---

## 개선 항목 체크리스트

```
Critical (즉시)
  [U1] ✅ UI_Screen_Main.cpp — UITheme/UIComponents 전면 적용
  [U2] ✅ canAccessScreen() 중복 → UI_AccessControl.cpp 단일 구현
  [U3] ✅ vTaskDelay 4곳 → 비동기 showMessage/showAccessDeniedAsync
  [U4] ✅ PIN 입력 화면 — UI_AccessControl.cpp

Major (단기)
  [U5] ✅ 비상정지 전용 화면 — UI_Screen_EStop.cpp
  [U6] ✅ 경보 화면 조치 가이드 — UI_Screen_Alarm.cpp
  [U7] ✅ strlen()*6 → textWidth() 11곳 교체
  [U8] ✅ screenNeedsRedraw/currentScreen Mutex 보호 — UIManager.cpp
  [U9] ✅ 팝업 long-press 연속 증가 — UI_Popup.cpp

Minor (중장기)
  [U10] ✅ 설정 메뉴 단일 배열 통합 — UI_Screen_Settings.cpp
  [U11] ✅ TFT_* 색상 → UITheme 통일 — UIComponents_patch.cpp
  [U12] ✅ 헤더 건강도 아이콘 재설계 — UIComponents_patch.cpp
```

---

## 예상 효과

| 항목 | 개선 전 | 개선 후 |
|---|---|---|
| 메인 화면 일관성 | UITheme 미적용, 단순 텍스트 | 카드/배지/프로그레스바 통일 |
| 권한 전환 | 막힘 + 3초 대기 | PIN 화면 즉시 제시 |
| E-Stop 화면 | 없음 | 전용 화면 + 복구 절차 안내 |
| 경보 화면 | 코드/시간만 표시 | 조치 방법 3단계 표시 |
| 파라미터 입력 | + 버튼 50번 클릭 | Long-press 연속 증가 |
| UI 블로킹 | 3초 화면 멈춤 | 비동기, 멈춤 없음 |
| 텍스트 정렬 (한국어) | 오정렬 | textWidth() 정확한 정렬 |
```
