// ================================================================
// VoiceAlert.h  —  v3.9 DFPlayer Mini 음성 알림 시스템 (수정본)
// ================================================================
#pragma once

#ifdef ENABLE_VOICE_ALERTS

#include <Arduino.h>
#include <DFRobotDFPlayerMini.h>
#include <HardwareSerial.h>
#include "Config.h"
#include "Lang.h"  // ← Language 열거형을 Lang.h에서 가져옴

// ═══════════════════════════════════════════════════════════════
//  언어 설정 - Lang.h의 Language 열거형 사용
// ═══════════════════════════════════════════════════════════════

// Language 열거형은 Lang.h에 정의되어 있음:
// enum Language : uint8_t {
//   LANG_EN = 0,
//   LANG_KO = 1
// };

// 언어별 폴더 오프셋 (Lang.h의 값과 매핑)
#define FOLDER_OFFSET_KOREAN    0    // LANG_KO(1) → 폴더 01-05
#define FOLDER_OFFSET_ENGLISH   10   // LANG_EN(0) → 폴더 11-15

// 기본 폴더 번호 (언어 무관)
#define FOLDER_BASE_SYSTEM       1
#define FOLDER_BASE_STATE        2
#define FOLDER_BASE_ERROR        3
#define FOLDER_BASE_MAINTENANCE  4
#define FOLDER_BASE_GUIDE        5

// ═══════════════════════════════════════════════════════════════
//  음성 메시지 정의
// ═══════════════════════════════════════════════════════════════

// 시스템 메시지 (폴더 01/11)
enum SystemVoice {
    VOICE_WELCOME = 1,           // "시스템을 시작합니다" / "System starting"
    VOICE_READY,                 // "준비 완료" / "System ready"
    VOICE_SHUTDOWN,              // "시스템을 종료합니다" / "Shutting down"
    VOICE_RESTART,               // "재시작합니다" / "Restarting"
};

// 상태 메시지 (폴더 02/12)
enum StateVoice {
    VOICE_STATE_IDLE = 1,        // "대기 중입니다" / "System idle"
    VOICE_STATE_VACUUM_ON,       // "진공을 생성하고 있습니다" / "Creating vacuum"
    VOICE_STATE_VACUUM_HOLD,     // "진공을 유지하고 있습니다" / "Holding vacuum"
    VOICE_STATE_VACUUM_BREAK,    // "진공을 해제하고 있습니다" / "Releasing vacuum"
    VOICE_STATE_COMPLETE,        // "작업이 완료되었습니다" / "Operation complete"
    VOICE_STATE_STANDBY,         // "대기 모드입니다" / "Standby mode"
    VOICE_STATE_MANUAL_MODE,     // "수동 모드로 전환" / "Switched to manual mode"
    VOICE_STATE_AUTO_MODE,       // "자동 모드로 전환" / "Switched to automatic mode"
    VOICE_STATE_PID_MODE,        // "PID 제어 모드" / "Switched to PID control mode"
};

// 에러 메시지 (폴더 03/13)
enum ErrorVoice {
    VOICE_ERROR_OVERHEAT = 1,    // "온도가 높습니다" / "Temperature too high"
    VOICE_ERROR_OVERCURRENT,     // "과전류가 감지되었습니다" / "Overcurrent detected"
    VOICE_ERROR_VACUUM_FAIL,     // "진공 생성에 실패했습니다" / "Vacuum creation failed"
    VOICE_ERROR_SENSOR,          // "센서 오류" / "Sensor fault detected"
    VOICE_ERROR_EMERGENCY,       // "비상 정지되었습니다" / "Emergency stop activated"
    VOICE_ERROR_TIMEOUT,         // "시간 초과" / "Operation timeout"
    VOICE_ERROR_PRESSURE_LOW,    // "진공 압력이 낮습니다" / "Pressure too low"
    VOICE_ERROR_LEAKAGE,         // "누기가 감지되었습니다" / "Leakage detected"
};

// 유지보수 메시지 (폴더 04/14)
enum MaintenanceVoice {
    VOICE_MAINT_SOON = 1,        // "곧 점검 시기입니다" / "Maintenance approaching"
    VOICE_MAINT_REQUIRED,        // "점검이 필요합니다" / "Maintenance required"
    VOICE_MAINT_URGENT,          // "긴급 점검 필요" / "Urgent maintenance required"
    VOICE_MAINT_COMPLETE,        // "점검이 완료되었습니다" / "Maintenance complete"
    VOICE_MAINT_FILTER_CHANGE,   // "필터 교체 시기" / "Filter replacement required"
    VOICE_MAINT_OIL_CHECK,       // "오일 점검" / "Check oil level"
    VOICE_MAINT_PUMP_SERVICE,    // "펌프 점검 필요" / "Pump service required"
};

// 안내 메시지 (폴더 05/15)
enum GuideVoice {
    VOICE_GUIDE_PLACE_BOX = 1,   // "박스를 올려주세요" / "Please place the box"
    VOICE_GUIDE_REMOVE_BOX,      // "박스를 제거해주세요" / "Please remove the box"
    VOICE_GUIDE_CHECK_SYSTEM,    // "시스템을 점검해주세요" / "Please check the system"
    VOICE_GUIDE_WAIT,            // "잠시 기다려주세요" / "Please wait"
    VOICE_GUIDE_DOOR_OPEN,       // "도어를 열어주세요" / "Please open the door"
    VOICE_GUIDE_DOOR_CLOSE,      // "도어를 닫아주세요" / "Please close the door"
    VOICE_GUIDE_START_BUTTON,    // "시작 버튼을 눌러주세요" / "Please press start button"
    VOICE_GUIDE_STOP_BUTTON,     // "정지 버튼을 눌러주세요" / "Please press stop button"
    VOICE_GUIDE_ADJUST_POSITION, // "위치를 조정해주세요" / "Please adjust position"
    VOICE_GUIDE_CHECK_SEAL,      // "실링을 확인해주세요" / "Please check the seal"
};

// ═══════════════════════════════════════════════════════════════
//  VoiceAlert 클래스
// ═══════════════════════════════════════════════════════════════

class VoiceAlert {
public:
    VoiceAlert();
    
    // ──── 초기화 ────
    bool begin();
    bool isOnline();
    
    // ──── 언어 설정 ────
    void setLanguage(Language lang);
    Language getLanguage() const;
    
    // ──── 볼륨 제어 ────
    void setVolume(uint8_t volume);  // 0-30
    uint8_t getVolume();
    void volumeUp();
    void volumeDown();
    void mute();
    void unmute();
    
    // ──── 재생 제어 ────
    void play(uint8_t folder, uint8_t track);
    void playSystem(SystemVoice voice);
    void playState(StateVoice voice);
    void playError(ErrorVoice voice);
    void playMaintenance(MaintenanceVoice voice);
    void playGuide(GuideVoice voice);
    
    void pause();
    void resume();
    void stop();
    
    // ──── 상태 메시지 자동 재생 ────
    void playStateMessage(SystemState state);
    void playErrorMessage(ErrorCode error);
    void playMaintenanceMessage(MaintenanceLevel level);
    
    // ──── 재생 상태 ────
    bool isPlaying();
    bool isBusy();
    
    // ──── 설정 ────
    void enableAutoVoice(bool enable);
    bool isAutoVoiceEnabled();
    
    void enableRepeat(bool enable);  // 중요 메시지 반복
    void setRepeatCount(uint8_t count);
    
    // ──── 큐 시스템 ────
    void queueVoice(uint8_t folder, uint8_t track);
    void clearQueue();
    uint8_t getQueueSize();
    
    // ──── 큐/반복 처리 (loop에서 호출) ────
    void handleRepeat();
    
    // ──── 통계 ────
    uint32_t getTotalPlayed();
    uint32_t getLastPlayTime();
    
private:
    DFRobotDFPlayerMini dfPlayer;
    HardwareSerial* serial;
    
    bool online;
    bool autoVoice;
    bool muted;
    uint8_t currentVolume;
    uint8_t savedVolume;  // mute 전 볼륨
    
    Language currentLanguage;
    
    // 반복 재생
    bool repeatEnabled;
    uint8_t repeatCount;
    uint8_t currentRepeat;
    uint8_t repeatFolder;
    uint8_t repeatTrack;
    
    // 큐
    struct VoiceQueue {
        uint8_t folder;
        uint8_t track;
    };
    VoiceQueue queue[10];
    uint8_t queueHead;
    uint8_t queueTail;
    
    // 통계
    uint32_t totalPlayed;
    uint32_t lastPlayTime;
    
    // 내부 함수
    uint8_t getFolderNumber(uint8_t baseFolder);
    void processQueue();
    bool enqueue(uint8_t folder, uint8_t track);
    bool dequeue(uint8_t& folder, uint8_t& track);
    
    // 상수
    static const uint8_t DEFAULT_VOLUME = 20;
    static const uint8_t MAX_VOLUME = 30;
};

// ═══════════════════════════════════════════════════════════════
//  전역 인스턴스
// ═══════════════════════════════════════════════════════════════

extern VoiceAlert voiceAlert;

// ═══════════════════════════════════════════════════════════════
//  설정 (Config.h에 정의된 것 사용)
// ═══════════════════════════════════════════════════════════════

// DFPlayer 핀 설정은 Config.h에 정의되어 있음:
// #define DFPLAYER_RX_PIN     17
// #define DFPLAYER_TX_PIN     18
// #define DFPLAYER_UART       2
// #define DFPLAYER_BAUD       9600

// 기본 설정
#define DFPLAYER_TIMEOUT    1000  // ms

#endif // ENABLE_VOICE_ALERTS
