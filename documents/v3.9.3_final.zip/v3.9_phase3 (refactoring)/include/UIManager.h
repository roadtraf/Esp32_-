// ================================================================
// UIManager.h - UI 관리 모듈
// ESP32-S3 v3.9.2 Phase 3-1 - Step 6
// ================================================================
#pragma once

#include <Arduino.h>
#include "../include/Config.h"

// ================================================================
// UI 관리자 클래스
// ================================================================
class UIManager {
public:
    // 초기화
    void begin();
    void update();
    
    // 화면 관리
    void setScreen(ScreenType screen);
    ScreenType getCurrentScreen() const { return currentScreen; }
    void redrawScreen();
    void requestRedraw() { needsRedraw = true; }
    
    // 터치 처리
    void handleTouch();
    
    // 메시지 표시
    void showMessage(const char* message, uint32_t duration = 2000);
    void showToast(const char* message, uint16_t color);
    void hideMessage();
    
    // 팝업 관리
    void showPopup(const char* label, float* target, float min, float max, 
                   float step, uint8_t decimals);
    void showPopupU32(const char* label, uint32_t* target, uint32_t min, 
                      uint32_t max, uint32_t step);
    void hidePopup();
    bool isPopupActive() const { return popupActive; }
    
    // 백라이트 제어
    void setBrightness(uint8_t level);
    uint8_t getBrightness() const { return brightness; }
    
    // 절전 모드
    void enterSleepMode();
    void exitSleepMode();
    bool isSleepMode() const { return sleepMode; }
    
    // 상태 조회
    void printStatus();
    
private:
    ScreenType currentScreen;
    ScreenType previousScreen;
    bool needsRedraw;
    uint32_t lastUpdate;
    
    // 메시지
    bool messageActive;
    char messageText[100];
    uint32_t messageStartTime;
    uint32_t messageDuration;
    
    // 팝업
    bool popupActive;
    char popupLabel[50];
    float popupValue;
    float popupMin;
    float popupMax;
    float popupStep;
    uint8_t popupDecimals;
    float* popupTargetFloat;
    uint32_t* popupTargetU32;
    
    // 백라이트
    uint8_t brightness;
    
    // 절전
    bool sleepMode;
    uint8_t savedBrightness;
    
    // 내부 메서드
    void drawCurrentScreen();
    void handlePopupTouch(uint16_t x, uint16_t y);
    void updateBrightness();
};

extern UIManager uiManager;
