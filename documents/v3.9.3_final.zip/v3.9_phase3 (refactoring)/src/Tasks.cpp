// ================================================================
// Tasks.cpp - FreeRTOS 태스크 구현
// ESP32-S3 v3.9.2 Phase 3-1
// ================================================================
#include "Tasks.h"
#include "../include/Config.h"
#include "../include/EnhancedWatchdog.h"

// ================================================================
// 태스크 핸들 정의
// ================================================================
TaskHandle_t vacuumTaskHandle = NULL;
TaskHandle_t sensorTaskHandle = NULL;
TaskHandle_t uiTaskHandle = NULL;
TaskHandle_t wifiTaskHandle = NULL;
TaskHandle_t mqttTaskHandle = NULL;
TaskHandle_t loggerTaskHandle = NULL;
TaskHandle_t healthTaskHandle = NULL;
TaskHandle_t predictorTaskHandle = NULL;

// ================================================================
// 외부 참조 (main.cpp에서 정의된 전역 변수/함수)
// ================================================================
extern void updateStateMachine();
extern void handleError();
extern void updatePID();
extern void readSensors();
extern void updateSensorBuffers();
extern void checkSensorHealth();
extern void handleTouch();
extern void handleKeyboardInput();
extern void updateUI();
extern void enterSleepMode();
extern void connectWiFi();
extern void mqttLoop();
extern void publishMQTT();
extern void checkSDWriteStatus();

extern SystemState currentState;
extern ControlMode currentMode;
extern bool errorActive;
extern bool screenNeedsRedraw;
extern bool keyboardConnected;
extern uint32_t lastIdleTime;
extern bool sleepMode;
extern SystemConfig config;
extern SensorData sensorData;
extern bool mqttConnected;

#ifdef ENABLE_DATA_LOGGING
extern DataLogger dataLogger;
#endif

#ifdef ENABLE_PREDICTIVE_MAINTENANCE
extern HealthMonitor healthMonitor;
extern MLPredictor mlPredictor;
#endif

#define IDLE_TIMEOUT 120000
#define HEALTH_UPDATE_INTERVAL 10000
#define ML_UPDATE_INTERVAL 5000

// ================================================================
// 1. vacuumControlTask - 진공 제어
// ================================================================
void vacuumControlTask(void* param) {
    Serial.println("[Task] vacuumControlTask 시작");
    
    TickType_t lastWakeTime = xTaskGetTickCount();
    const TickType_t frequency = pdMS_TO_TICKS(100);  // 100ms
    
    while (1) {
        // 상태 머신 업데이트
        updateStateMachine();
        
        // 에러 처리
        if (errorActive) {
            handleError();
        }
        
        // PID 제어
        if (currentMode == MODE_PID && !errorActive) {
            updatePID();
        }
        
        // ✅ Enhanced Watchdog 체크인
        WDT_CHECKIN("VacuumCtrl");
        
        // 정확한 주기 유지
        vTaskDelayUntil(&lastWakeTime, frequency);
    }
}

// ================================================================
// 2. sensorReadTask - 센서 읽기
// ================================================================
void sensorReadTask(void* param) {
    Serial.println("[Task] sensorReadTask 시작");
    
    TickType_t lastWakeTime = xTaskGetTickCount();
    const TickType_t frequency = pdMS_TO_TICKS(100);  // 100ms
    
    while (1) {
        // 센서 읽기
        readSensors();
        
        // 센서 버퍼 업데이트
        updateSensorBuffers();
        
        // 센서 건강 체크
        checkSensorHealth();
        
        // ✅ Enhanced Watchdog 체크인
        WDT_CHECKIN("SensorRead");
        
        vTaskDelayUntil(&lastWakeTime, frequency);
    }
}

// ================================================================
// 3. uiUpdateTask - UI 업데이트
// ================================================================
void uiUpdateTask(void* param) {
    Serial.println("[Task] uiUpdateTask 시작");
    
    uint32_t lastUpdate = 0;
    
    while (1) {
        uint32_t now = millis();
        
        // 터치 입력 처리
        handleTouch();
        
        // 키보드 입력 처리
        if (keyboardConnected) {
            handleKeyboardInput();
        }
        
        // 화면 업데이트 (200ms마다)
        if (now - lastUpdate >= 200) {
            if (screenNeedsRedraw) {
                updateUI();
                screenNeedsRedraw = false;
            }
            lastUpdate = now;
        }
        
        // 절전 모드 체크
        if (!sleepMode && (now - lastIdleTime > IDLE_TIMEOUT)) {
            if (currentState == STATE_IDLE) {
                enterSleepMode();
            }
        }
        
        // ✅ Enhanced Watchdog 체크인
        WDT_CHECKIN("UIUpdate");
        
        vTaskDelay(pdMS_TO_TICKS(50));  // 50ms
    }
}

// ================================================================
// 4. wifiManagerTask - WiFi 관리
// ================================================================
void wifiManagerTask(void* param) {
    Serial.println("[Task] wifiManagerTask 시작");
    
    TickType_t lastWakeTime = xTaskGetTickCount();
    const TickType_t frequency = pdMS_TO_TICKS(5000);  // 5초
    
    while (1) {
        // WiFi 연결 상태 확인
        if (strlen(config.wifiSSID) > 0 && WiFi.status() != WL_CONNECTED) {
            Serial.println("[WiFi] 재연결 시도...");
            connectWiFi();
        }
        
        // ✅ Enhanced Watchdog 체크인
        WDT_CHECKIN("WiFiMgr");
        
        vTaskDelayUntil(&lastWakeTime, frequency);
    }
}

// ================================================================
// 5. mqttHandlerTask - MQTT 처리
// ================================================================
void mqttHandlerTask(void* param) {
    Serial.println("[Task] mqttHandlerTask 시작");
    
    uint32_t lastPublish = 0;
    
    while (1) {
        uint32_t now = millis();
        
        if (mqttConnected) {
            // MQTT 루프
            mqttLoop();
            
            // 주기적 발행 (2초마다)
            if (now - lastPublish >= 2000) {
                publishMQTT();
                lastPublish = now;
            }
        }
        
        vTaskDelay(pdMS_TO_TICKS(100));  // 100ms
    }
}

// ================================================================
// 6. dataLoggerTask - 데이터 로깅
// ================================================================
void dataLoggerTask(void* param) {
    Serial.println("[Task] dataLoggerTask 시작");
    
    TickType_t lastWakeTime = xTaskGetTickCount();
    const TickType_t frequency = pdMS_TO_TICKS(1000);  // 1초
    
    while (1) {
        #ifdef ENABLE_DATA_LOGGING
        dataLogger.logHealthData(healthMonitor);
        #endif
        
        // SD 쓰기 완료 체크
        checkSDWriteStatus();
        
        vTaskDelayUntil(&lastWakeTime, frequency);
    }
}

// ================================================================
// 7. healthMonitorTask - 건강도 모니터링
// ================================================================
void healthMonitorTask(void* param) {
    Serial.println("[Task] healthMonitorTask 시작");
    
    uint32_t lastUpdate = 0;
    
    while (1) {
        uint32_t now = millis();
        
        #ifdef ENABLE_PREDICTIVE_MAINTENANCE
        if (now - lastUpdate >= HEALTH_UPDATE_INTERVAL) {
            extern Statistics stats;
            
            healthMonitor.update(
                sensorData.pressure,
                sensorData.temperature,
                sensorData.current,
                stats.cycleCount,
                stats.uptime
            );
            lastUpdate = now;
        }
        #endif
        
        vTaskDelay(pdMS_TO_TICKS(1000));  // 1초
    }
}

// ================================================================
// 8. predictorTask - ML 예측
// ================================================================
void predictorTask(void* param) {
    Serial.println("[Task] predictorTask 시작");
    
    uint32_t lastUpdate = 0;
    
    while (1) {
        uint32_t now = millis();
        
        #ifdef ENABLE_PREDICTIVE_MAINTENANCE
        if (now - lastUpdate >= ML_UPDATE_INTERVAL) {
            mlPredictor.addSample(
                sensorData.pressure,
                sensorData.temperature,
                sensorData.current
            );
            lastUpdate = now;
        }
        #endif
        
        vTaskDelay(pdMS_TO_TICKS(1000));  // 1초
    }
}

// ================================================================
// 태스크 생성 헬퍼 함수
// ================================================================
void createAllTasks() {
    Serial.println("[Tasks] FreeRTOS 태스크 생성 시작...");
    
    // TaskConfig는 include/TaskConfig.h에서 정의됨
    
    // 1. Vacuum Control Task (Core 0)
    xTaskCreatePinnedToCore(
        vacuumControlTask,
        "VacuumCtrl",
        TaskConfig::VACUUM_CONTROL_STACK,
        NULL,
        TaskConfig::VACUUM_CONTROL_PRIORITY,
        &vacuumTaskHandle,
        0  // Core 0
    );
    
    // 2. Sensor Read Task (Core 0)
    xTaskCreatePinnedToCore(
        sensorReadTask,
        "SensorRead",
        TaskConfig::SENSOR_READ_STACK,
        NULL,
        TaskConfig::SENSOR_READ_PRIORITY,
        &sensorTaskHandle,
        0  // Core 0
    );
    
    // 3. UI Update Task (Core 1)
    xTaskCreatePinnedToCore(
        uiUpdateTask,
        "UIUpdate",
        TaskConfig::UI_UPDATE_STACK,
        NULL,
        TaskConfig::UI_UPDATE_PRIORITY,
        &uiTaskHandle,
        1  // Core 1
    );
    
    // 4. WiFi Manager Task (Core 1)
    xTaskCreatePinnedToCore(
        wifiManagerTask,
        "WiFiMgr",
        TaskConfig::WIFI_MANAGER_STACK,
        NULL,
        TaskConfig::WIFI_MANAGER_PRIORITY,
        &wifiTaskHandle,
        1  // Core 1
    );
    
    // 5. MQTT Handler Task (Core 1)
    xTaskCreatePinnedToCore(
        mqttHandlerTask,
        "MQTTHandler",
        TaskConfig::MQTT_HANDLER_STACK,
        NULL,
        TaskConfig::MQTT_HANDLER_PRIORITY,
        &mqttTaskHandle,
        1  // Core 1
    );
    
    // 6. Data Logger Task (Core 1)
    xTaskCreatePinnedToCore(
        dataLoggerTask,
        "DataLogger",
        TaskConfig::DATA_LOGGER_STACK,
        NULL,
        TaskConfig::DATA_LOGGER_PRIORITY,
        &loggerTaskHandle,
        1  // Core 1
    );
    
    // 7. Health Monitor Task (Core 1)
    xTaskCreatePinnedToCore(
        healthMonitorTask,
        "HealthMon",
        TaskConfig::HEALTH_MONITOR_STACK,
        NULL,
        TaskConfig::HEALTH_MONITOR_PRIORITY,
        &healthTaskHandle,
        1  // Core 1
    );
    
    // 8. Predictor Task (Core 1)
    xTaskCreatePinnedToCore(
        predictorTask,
        "Predictor",
        TaskConfig::PREDICTOR_STACK,
        NULL,
        TaskConfig::PREDICTOR_PRIORITY,
        &predictorTaskHandle,
        1  // Core 1
    );
    
    Serial.println("[Tasks] ✅ 모든 태스크 생성 완료");
}
