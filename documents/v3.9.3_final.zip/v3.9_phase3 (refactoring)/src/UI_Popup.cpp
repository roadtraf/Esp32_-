/*
 * UI_Popup.cpp
 * 숫자 입력 팝업 모듈
 * v3.7: 유지보수 알림 팝업 터치 처리 추가
 */

// ═══════════════════════════════════════════════════════════════
//  숫자 입력 팝업 - 기존 기능
// ═══════════════════════════════════════════════════════════════

void openNumericPopup(const char* label, float currentVal,
                     float minVal, float maxVal,
                     float step, uint8_t decimals, float* target) {
  popupActive = true;
  popupValue = currentVal;
  popupMin = minVal;
  popupMax = maxVal;
  popupStep = step;
  popupDecimals = decimals;
  popupLabel = label;
  popupTarget = target;
  popupTargetU32 = nullptr;
  
  drawNumericPopup();
}

void openNumericPopupU32(const char* label, uint32_t currentVal,
                        uint32_t minVal, uint32_t maxVal,
                        uint32_t step, uint32_t* target) {
  popupActive = true;
  popupValue = (float)currentVal;
  popupMin = (float)minVal;
  popupMax = (float)maxVal;
  popupStep = (float)step;
  popupDecimals = 0;
  popupLabel = label;
  popupTarget = nullptr;
  popupTargetU32 = target;
  
  drawNumericPopup();
}

void drawNumericPopup() {
  // 반투명 배경
  tft.fillRect(40, 80, 400, 160, TFT_DARKGREY);
  tft.drawRect(40, 80, 400, 160, TFT_WHITE);
  tft.drawRect(41, 81, 398, 158, TFT_WHITE);
  
  // 제목
  tft.setTextSize(1);
  tft.setTextColor(TFT_YELLOW, TFT_DARKGREY);
  tft.setCursor(50, 90);
  tft.print(popupLabel);
  
  // 현재 값
  tft.setTextSize(3);
  tft.setTextColor(TFT_WHITE, TFT_DARKGREY);
  tft.setCursor(140, 120);
  if (popupDecimals == 0) {
    tft.printf("%d", (int)popupValue);
  } else {
    char fmt[10];
    snprintf(fmt, sizeof(fmt), "%%.%df", popupDecimals);
    tft.printf(fmt, popupValue);
  }
  
  // 버튼
  // - 버튼
  tft.fillRect(60, 180, 80, 40, TFT_RED);
  tft.drawRect(60, 180, 80, 40, TFT_WHITE);
  tft.setTextSize(3);
  tft.setTextColor(TFT_WHITE, TFT_RED);
  tft.setCursor(85, 190);
  tft.print("-");
  
  // + 버튼
  tft.fillRect(160, 180, 80, 40, TFT_GREEN);
  tft.drawRect(160, 180, 80, 40, TFT_WHITE);
  tft.setTextColor(TFT_WHITE, TFT_GREEN);
  tft.setCursor(185, 190);
  tft.print("+");
  
  // OK 버튼
  tft.fillRect(260, 180, 80, 40, TFT_BLUE);
  tft.drawRect(260, 180, 80, 40, TFT_WHITE);
  tft.setTextSize(2);
  tft.setTextColor(TFT_WHITE, TFT_BLUE);
  tft.setCursor(275, 195);
  tft.print("OK");
  
  // Cancel 버튼
  tft.fillRect(360, 180, 60, 40, TFT_DARKGREY);
  tft.drawRect(360, 180, 60, 40, TFT_WHITE);
  tft.setTextSize(1);
  tft.setTextColor(TFT_WHITE, TFT_DARKGREY);
  tft.setCursor(370, 197);
  tft.print("X");
}

void handleNumericPopupTouch(uint16_t x, uint16_t y) {
  // - 버튼 (60, 180, 80, 40)
  if (x >= 60 && x <= 140 && y >= 180 && y <= 220) {
    popupValue -= popupStep;
    if (popupValue < popupMin) popupValue = popupMin;
    drawNumericPopup();
  }
  // + 버튼 (160, 180, 80, 40)
  else if (x >= 160 && x <= 240 && y >= 180 && y <= 220) {
    popupValue += popupStep;
    if (popupValue > popupMax) popupValue = popupMax;
    drawNumericPopup();
  }
  // OK 버튼 (260, 180, 80, 40)
  else if (x >= 260 && x <= 340 && y >= 180 && y <= 220) {
    if (popupTarget) {
      *popupTarget = popupValue;
    }
    if (popupTargetU32) {
      *popupTargetU32 = (uint32_t)popupValue;
    }
    saveConfig();
    popupActive = false;
    screenNeedsRedraw = true;
  }
  // Cancel 버튼 (360, 180, 60, 40)
  else if (x >= 360 && x <= 420 && y >= 180 && y <= 220) {
    popupActive = false;
    screenNeedsRedraw = true;
  }
}

// ═══════════════════════════════════════════════════════════════
//  v3.7: 통합된 팝업 터치 처리 함수
// ═══════════════════════════════════════════════════════════════

/*
 * handlePopupTouch()
 * 
 * 모든 팝업 터치를 우선적으로 처리하는 통합 함수
 * 
 * 반환값:
 *   true  - 팝업이 터치를 처리함 (다른 터치 처리 건너뛰기)
 *   false - 팝업이 활성화되지 않음 (일반 터치 처리 계속)
 * 
 * 사용법:
 *   void handleTouch() {
 *     uint16_t x, y;
 *     if (!tft.getTouch(&x, &y)) return;
 *     
 *     // 팝업 우선 처리
 *     if (handlePopupTouch(x, y)) {
 *       return;  // 팝업이 처리함
 *     }
 *     
 *     // 일반 화면 터치 처리...
 *   }
 */
bool handlePopupTouch(uint16_t x, uint16_t y) {
  // v3.7: 유지보수 알림 팝업 최우선 처리
  #ifdef ENABLE_PREDICTIVE_MAINTENANCE
  if (handleMaintenanceAlertTouch(x, y)) {
    return true;  // 유지보수 알림 팝업이 처리함
  }
  #endif
  
  // 숫자 입력 팝업 처리
  if (popupActive) {
    handleNumericPopupTouch(x, y);
    return true;  // 숫자 팝업이 처리함
  }
  
  // 팝업이 없음 - 일반 터치 처리 계속
  return false;
}

/*
 * 사용 예시:
 * 
 * main.cpp의 handleTouch() 함수에서:
 * 
 * void handleTouch() {
 *   uint16_t x, y;
 *   if (!tft.getTouch(&x, &y)) return;
 *   
 *   lastTouchTime = millis();
 *   lastIdleTime = millis();
 *   
 *   if (sleepMode) {
 *     exitSleepMode();
 *     return;
 *   }
 *   
 *   // ★★★ 팝업 우선 처리 ★★★
 *   if (handlePopupTouch(x, y)) {
 *     return;  // 팝업이 터치를 처리했으면 여기서 종료
 *   }
 *   
 *   // 일반 화면별 터치 처리
 *   switch(currentScreen) {
 *     case SCREEN_MAIN:
 *       handleMainScreenTouch(x, y);
 *       break;
 *     case SCREEN_SETTINGS:
 *       handleSettingsTouch(x, y);
 *       break;
 *     // ... 기타 화면들 ...
 *   }
 * }
 */
