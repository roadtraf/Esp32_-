// ================================================================
// SD_Logger.cpp  —  SD 카드 로깅, 일일 리포트, NTP 시간
// ================================================================
#include "Config.h"
#include "SD_Logger.h"
#include "StateMachine.h"  // getStateName()
#include <SD.h>
#include <time.h>

// FreeRTOS (delay 개선)
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

// ─────────────────── SD 초기화 ──────────────────────────────
void initSD() {
  if (!SD.begin()) {
    Serial.println("[경고] SD 카드 없음 (로깅 비활성화)");
    return;
  }

  uint8_t cardType = SD.cardType();
  if (cardType == CARD_NONE) {
    Serial.println("[경고] SD 카드 미감지");
    return;
  }

  Serial.println("[SD] 카드 마운트 성공");
  Serial.printf("  타입: %s\n",
    cardType == CARD_MMC  ? "MMC"  :
    cardType == CARD_SD   ? "SDSC" :
    cardType == CARD_SDHC ? "SDHC" : "UNKNOWN");
  Serial.printf("  용량: %llu MB\n", SD.cardSize() / (1024 * 1024));

  // 디렉토리 생성
  if (!SD.exists("/logs"))    SD.mkdir("/logs");
  if (!SD.exists("/reports")) SD.mkdir("/reports");

  sdReady = true;   // ★ 초기화 완료 플래그
}

// ─────────────────── 사이클 로그 ────────────────────────────
void logCycle() {
  if (!sdReady) return;

  File file = SD.open("/logs/cycle_log.csv", FILE_APPEND);
  if (!file) return;

  // 헤더 (파일이 비어있을 때)
  if (file.size() == 0)
    file.println("CycleNum,ISO8601,Duration,MinPressure,MaxPressure,AvgCurrent,Success");

  uint32_t duration = millis() - stateStartTime;
  char line[256];
  snprintf(line, sizeof(line), "%lu,%s,%lu,%.2f,%.2f,%.2f,%d",
    stats.totalCycles,
    getCurrentTimeISO8601().c_str(),
    duration,
    stats.minPressure,
    stats.maxPressure,
    stats.averageCurrent,
    currentState == STATE_COMPLETE ? 1 : 0);

  file.println(line);
  file.close();
}

// ─────────────────── 에러 로그 ──────────────────────────────
void logError(const ErrorInfo& error) {
  if (!sdReady) return;

  File file = SD.open("/logs/error_log.csv", FILE_APPEND);
  if (!file) {
    Serial.println("[SD] 에러 로그 파일 열기 실패");
    return;
  }

  if (file.size() == 0)
    file.println("Timestamp,ISO8601,Code,Severity,Message");

  char line[256];
  snprintf(line, sizeof(line), "%lu,%s,%d,%d,%s",
    error.timestamp,
    getCurrentTimeISO8601().c_str(),
    error.code,
    error.severity,
    error.message);

  file.println(line);
  file.close();

  Serial.println("[SD] 에러 로그 저장됨");
}

// ─────────────────── 센서 트렌드 로그 ──────────────────────
void logSensorTrend() {
  if (!sdReady) return;

  File file = SD.open("/logs/sensor_trend.csv", FILE_APPEND);
  if (!file) return;

  if (file.size() == 0)
    file.println("Timestamp,ISO8601,Pressure,Current,State");

  char line[256];
  snprintf(line, sizeof(line), "%lu,%s,%.2f,%.2f,%s",
    millis(),
    getCurrentTimeISO8601().c_str(),
    sensorData.pressure,
    sensorData.current,
    getStateName(currentState));

  file.println(line);
  file.close();
}

// ─────────────────── 일일 리포트 ────────────────────────────
void generateDailyReport() {
  if (!sdReady) return;

  time_t now;
  struct tm timeinfo;
  time(&now);
  localtime_r(&now, &timeinfo);

  char filename[64];
  strftime(filename, sizeof(filename), "/reports/daily_%Y%m%d.txt", &timeinfo);

  File file = SD.open(filename, FILE_WRITE);
  if (!file) return;

  file.println("========================================");
  file.println("일일 리포트");
  file.println("========================================");
  file.printf("생성 시간: %s\n", getCurrentTimeISO8601().c_str());
  file.println();
  file.println("통계:");
  file.printf("  총 사이클: %lu\n",  stats.totalCycles);
  file.printf("  성공: %lu\n",       stats.successfulCycles);
  file.printf("  실패: %lu\n",       stats.failedCycles);
  file.printf("  총 에러: %lu\n",    stats.totalErrors);
  file.printf("  가동 시간: %lu초\n", stats.uptime);
  file.println();
  file.println("센서 범위:");
  file.printf("  최소 압력: %.2f kPa\n", stats.minPressure);
  file.printf("  최대 압력: %.2f kPa\n", stats.maxPressure);
  file.printf("  평균 전류: %.2f A\n",   stats.averageCurrent);
  file.println();
  file.println("========================================");
  file.close();

  Serial.printf("[리포트] 일일 리포트 생성: %s\n", filename);
}

void cleanupOldLogs() {
  // 30일 이상 로그 삭제 (간단한 구현)
  Serial.println("[정리] 오래된 로그 정리...");
}

// ─────────────────── NTP / 시간 ─────────────────────────────
void syncTime() {
  configTime(9 * 3600, 0, "pool.ntp.org", "time.google.com", "time.windows.com");

  Serial.print("[NTP] 시간 동기화 중");
  uint8_t attempts = 0;
  while (time(nullptr) < 100000 && attempts < 20) {
    vTaskDelay(pdMS_TO_TICKS(500));
    Serial.print(".");
    attempts++;
  }
  Serial.println();

  time_t now = time(nullptr);
  if (now > 100000) Serial.printf("[NTP] 동기화 성공: %s", ctime(&now));
  else              Serial.println("[NTP] 동기화 실패");
}

void getCurrentTimeISO8601(char* buffer, size_t bufferSize) {
  if (!buffer || bufferSize < ISO8601_BUFFER_SIZE) {
    if (buffer && bufferSize > 0) buffer[0] = '\0';
    return;
  }
  time_t now;
  struct tm timeinfo;
  time(&now);
  localtime_r(&now, &timeinfo);
  strftime(buffer, bufferSize, "%Y-%m-%dT%H:%M:%S+09:00", &timeinfo);
}
