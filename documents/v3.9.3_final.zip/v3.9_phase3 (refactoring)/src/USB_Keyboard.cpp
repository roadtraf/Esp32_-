#include "Config.h"                 // enum, struct, extern 전역변수
#include <USBHIDKeyboard.h>
#include "StateMachine.h"           // changeState()
#include "Network.h"                // saveConfig(), printMemoryInfo(), printStatistics()
#include "Sensor.h"                 // calibratePressure(), calibrateCurrent()
#include "ErrorHandler.h"           // clearError()
#include "State_Diagram.h"          // stateDiagramNextPage() 등

// ==================== USB 키보드 입력 처리 ====================
void handleKeyboardInput() {
  if (!keyboard.available()) {
    return;
  }

  uint8_t key = keyboard.read();
  processKeyboardCommand(key);
}

void processKeyboardCommand(uint8_t key) {
  Serial.printf("[키보드] 키 코드: 0x%02X\n", key);

  // 숫자 키 (0-9)
  if (key >= '0' && key <= '9') {
    uint8_t num = key - '0';

    switch (num) {
      case 1: // START
        if (currentState == STATE_IDLE) {
          changeState(STATE_VACUUM_ON);
          Serial.println("[키보드] START 명령");
        }
        break;

      case 2: // STOP
        changeState(STATE_IDLE);
        Serial.println("[키보드] STOP 명령");
        break;

      case 3: // MODE
        if (currentMode == MODE_MANUAL) {
          currentMode = MODE_AUTO;
          config.controlMode = MODE_AUTO;
        } else if (currentMode == MODE_AUTO) {
          currentMode = MODE_PID;
          config.controlMode = MODE_PID;
        } else {
          currentMode = MODE_MANUAL;
          config.controlMode = MODE_MANUAL;
        }
        saveConfig();
        screenNeedsRedraw = true;
        Serial.printf("[키보드] 모드 변경: %d\n", currentMode);
        break;

      case 4: // RESET
        clearError();
        Serial.println("[키보드] 알람 리셋");
        break;

      case 5: // STATISTICS
        currentScreen = SCREEN_STATISTICS;
        screenNeedsRedraw = true;
        Serial.println("[키보드] 통계 화면");
        break;

      case 6: // ABOUT
        currentScreen = SCREEN_ABOUT;
        screenNeedsRedraw = true;
        Serial.println("[키보드] 정보 화면");
        break;

      case 7: // TIMING SETUP
        currentScreen = SCREEN_TIMING_SETUP;
        screenNeedsRedraw = true;
        Serial.println("[키보드] 타이밍 설정");
        break;

      case 8: // TREND GRAPH
        currentScreen     = SCREEN_TREND_GRAPH;
        screenNeedsRedraw = true;
        Serial.println("[키보드] 추세 그래프");
        break;

      case 9: // HELP
        currentScreen = SCREEN_HELP;
        helpPageIndex = 0;
        screenNeedsRedraw = true;
        Serial.println("[키보드] 도움말");
        break;

      case 0: // MAIN SCREEN
        currentScreen = SCREEN_MAIN;
        screenNeedsRedraw = true;
        Serial.println("[키보드] 메인 화면");
        break;
    }
  }
  // 특수 키
  else if (key == '.') { // STATE DIAGRAM
    currentScreen     = SCREEN_STATE_DIAGRAM;
    screenNeedsRedraw = true;
    Serial.println("[키보드] 상태 다이어그램");
  }
  else if (key == '*') { // MENU
    currentScreen = SCREEN_SETTINGS;
    screenNeedsRedraw = true;
    Serial.println("[키보드] 설정 메뉴");
  }
  else if (key == '/') { // HELP (대체)
    currentScreen = SCREEN_HELP;
    helpPageIndex = 0;
    screenNeedsRedraw = true;
    Serial.println("[키보드] 도움말");
  }
  else if (key == '+') { // 다음 페이지 (값 조정은 팝업으로 이전)
    if (currentScreen == SCREEN_HELP) {
      if (helpPageIndex < 5) {
        helpPageIndex++;
        screenNeedsRedraw = true;
        Serial.printf("[키보드] 도움말 다음 페이지: %d\n", helpPageIndex + 1);
      }
    }
    else if (currentScreen == SCREEN_STATE_DIAGRAM) {
      stateDiagramNextPage();
      Serial.println("[키보드] 상태다이어그램 다음 페이지");
    }
  }
  else if (key == '-') { // 이전 페이지 (값 조정은 팝업으로 이전)
    if (currentScreen == SCREEN_HELP) {
      if (helpPageIndex > 0) {
        helpPageIndex--;
        screenNeedsRedraw = true;
        Serial.printf("[키보드] 도움말 이전 페이지: %d\n", helpPageIndex + 1);
      }
    }
    else if (currentScreen == SCREEN_STATE_DIAGRAM) {
      stateDiagramPrevPage();
      Serial.println("[키보드] 상태다이어그램 이전 페이지");
    }
  }
  else if (key == '\r' || key == '\n') { // Enter
    Serial.println("[키보드] 확인");
    // 현재 화면의 기본 액션 실행 (필요시 구현)
  }
  else if (key == 0x08 || key == 0x7F) { // Backspace
    // 뒤로 가기
    if (currentScreen != SCREEN_MAIN) {
      if (currentScreen == SCREEN_SETTINGS) {
        currentScreen = SCREEN_MAIN;
      } else {
        currentScreen = SCREEN_SETTINGS;
      }
      screenNeedsRedraw = true;
      Serial.println("[키보드] 뒤로 가기");
    }
  }
}