// ================================================================
// UI_Screens.cpp - UI 화면 라우팅 및 헬퍼 함수
// ================================================================
#include "../include/UI_Screens.h"
#include "../include/UIComponents.h"
#include "../include/Config.h"
#include "../include/SystemController.h"

#ifdef ENABLE_PREDICTIVE_MAINTENANCE
#include "../include/HealthMonitor.h"

// FreeRTOS (delay 개선)
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
extern HealthMonitor healthMonitor;
#endif

extern LGFX tft;
extern SystemController systemController;
extern ScreenType currentScreen;
extern bool screenNeedsRedraw;

// 버퍼 참조
extern std::vector<float> temperatureBuffer;
extern std::vector<float> pressureBuffer;
extern std::vector<float> currentBuffer;

// 통계 참조 (프로젝트에 따라 다를 수 있음)
// extern Statistics stats;  // 필요시 주석 해제

// 에러 관련
extern ErrorInfo errorHistory[];
extern uint8_t errorHistIdx;
extern uint8_t errorHistCnt;
extern bool errorActive;
extern ErrorInfo currentError;

using namespace UIComponents;
using namespace UITheme;

// ================================================================
// 접근 권한 확인
// ================================================================
bool canAccessScreen(ScreenType screen) {
    // SystemController에서 권한 정보 가져오기
    Permissions perms = systemController.getPermissions();
    
    switch (screen) {
        // 작업자 권한 화면
        case SCREEN_MAIN:
        case SCREEN_SETTINGS:
        case SCREEN_STATISTICS:
        case SCREEN_TIMING_SETUP:
        case SCREEN_PID_SETUP:
        case SCREEN_ABOUT:
        case SCREEN_HELP:
        case SCREEN_STATE_DIAGRAM:
        case SCREEN_TREND_GRAPH:
            return true;  // 모든 레벨 접근 가능
        
        // 관리자 권한 화면
        case SCREEN_CALIBRATION:
            return perms.canCalibrate;
        
        #ifdef ENABLE_PREDICTIVE_MAINTENANCE
        case SCREEN_HEALTH:
        case SCREEN_HEALTH_TREND:
            return perms.canViewHealth;
        #endif
        
        #ifdef ENABLE_SMART_ALERTS
        case SCREEN_SMART_ALERT_CONFIG:
            return perms.canChangeSettings;
        #endif
        
        #ifdef ENABLE_VOICE_ALERTS
        case SCREEN_VOICE_SETTINGS:
            return perms.canChangeSettings;
        #endif
        
        case SCREEN_ALARM:
            return perms.canViewHealth;
        
        // 개발자 권한 화면
        case SCREEN_ADVANCED_ANALYSIS:
            return perms.canViewAdvanced;
        
        default:
            return true;
    }
}

// ================================================================
// 권한 없음 팝업
// ================================================================
void showAccessDenied(const char* screenName) {
    int16_t popupW = 280;
    int16_t popupH = 140;
    int16_t popupX = (SCREEN_WIDTH - popupW) / 2;
    int16_t popupY = (SCREEN_HEIGHT - popupH) / 2;
    
    // 배경 어둡게
    tft.fillScreen(0x18E3);
    
    // 팝업 카드
    CardConfig popup = {
        .x = popupX,
        .y = popupY,
        .w = popupW,
        .h = popupH,
        .bgColor = COLOR_BG_CARD,
        .borderColor = COLOR_DANGER,
        .elevated = true
    };
    drawCard(popup);
    
    // 경고 아이콘
    drawIconWarning(popupX + popupW / 2 - 8, popupY + 15, COLOR_DANGER);
    
    // 제목
    tft.setTextSize(TEXT_SIZE_MEDIUM);
    tft.setTextColor(COLOR_TEXT_PRIMARY);
    int16_t titleX = popupX + (popupW - strlen("권한 필요") * 12) / 2;
    tft.setCursor(titleX, popupY + 45);
    tft.print("권한 필요");
    
    // 메시지
    tft.setTextSize(TEXT_SIZE_SMALL);
    tft.setTextColor(COLOR_TEXT_SECONDARY);
    
    char msg[64];
    snprintf(msg, sizeof(msg), "%s 접근 권한이 없습니다", screenName);
    int16_t msgX = popupX + (popupW - strlen(msg) * 6) / 2;
    tft.setCursor(msgX, popupY + 70);
    tft.print(msg);
    
    tft.setCursor(popupX + 60, popupY + 85);
    tft.print("관리자 로그인이 필요합니다");
    
    // 확인 버튼
    ButtonConfig okBtn = {
        .x = (int16_t)(popupX + (popupW - 100) / 2),
        .y = (int16_t)(popupY + popupH - 35),
        .w = 100,
        .h = 28,
        .label = "확인",
        .style = BTN_PRIMARY,
        .enabled = true
    };
    drawButton(okBtn);
    
    vTaskDelay(pdMS_TO_TICKS(2000));
}

// ================================================================
// 센서 통계 계산
// ================================================================
void calculateSensorStats(SensorStats& stats) {
    stats.avgTemperature = 0;
    stats.avgPressure = 0;
    stats.avgCurrent = 0;
    stats.sampleCount = 0;
    
    // 온도
    if (temperatureBuffer.size() > 0) {
        float sum = 0;
        for (float val : temperatureBuffer) {
            sum += val;
        }
        stats.avgTemperature = sum / temperatureBuffer.size();
        stats.sampleCount = temperatureBuffer.size();
    }
    
    // 압력
    if (pressureBuffer.size() > 0) {
        float sum = 0;
        for (float val : pressureBuffer) {
            sum += val;
        }
        stats.avgPressure = sum / pressureBuffer.size();
    }
    
    // 전류
    if (currentBuffer.size() > 0) {
        float sum = 0;
        for (float val : currentBuffer) {
            sum += val;
        }
        stats.avgCurrent = sum / currentBuffer.size();
    }
}

// ================================================================
// 유지보수 완료 팝업
// ================================================================
#ifdef ENABLE_PREDICTIVE_MAINTENANCE
void showMaintenanceCompletePopup() {
    int16_t popupW = 280;
    int16_t popupH = 140;
    int16_t popupX = (SCREEN_WIDTH - popupW) / 2;
    int16_t popupY = (SCREEN_HEIGHT - popupH) / 2;
    
    // 배경 어둡게
    tft.fillScreen(0x18E3);
    
    // 팝업 카드
    CardConfig popup = {
        .x = popupX,
        .y = popupY,
        .w = popupW,
        .h = popupH,
        .bgColor = COLOR_SUCCESS,
        .borderColor = COLOR_TEXT_PRIMARY,
        .elevated = true
    };
    drawCard(popup);
    
    // 체크 아이콘
    drawIconCheck(popupX + popupW / 2 - 8, popupY + 20, COLOR_TEXT_PRIMARY);
    
    // 제목
    tft.setTextSize(TEXT_SIZE_MEDIUM);
    tft.setTextColor(COLOR_TEXT_PRIMARY);
    int16_t titleX = popupX + (popupW - strlen("완료!") * 12) / 2;
    tft.setCursor(titleX, popupY + 50);
    tft.print("완료!");
    
    // 메시지
    tft.setTextSize(TEXT_SIZE_SMALL);
    const char* msg1 = "유지보수가 완료되었습니다";
    int16_t msg1X = popupX + (popupW - strlen(msg1) * 6) / 2;
    tft.setCursor(msg1X, popupY + 80);
    tft.print(msg1);
    
    const char* msg2 = "건강도가 100%로 리셋됩니다";
    int16_t msg2X = popupX + (popupW - strlen(msg2) * 6) / 2;
    tft.setCursor(msg2X, popupY + 95);
    tft.print(msg2);
    
    // OK 버튼
    ButtonConfig okBtn = {
        .x = (int16_t)(popupX + (popupW - 100) / 2),
        .y = (int16_t)(popupY + popupH - 35),
        .w = 100,
        .h = 28,
        .label = "확인",
        .style = BTN_OUTLINE,
        .enabled = true
    };
    
    // 버튼 배경 어둡게
    tft.fillRoundRect(okBtn.x, okBtn.y, okBtn.w, okBtn.h, 
                      BUTTON_RADIUS, COLOR_BG_DARK);
    tft.drawRoundRect(okBtn.x, okBtn.y, okBtn.w, okBtn.h, 
                      BUTTON_RADIUS, COLOR_TEXT_PRIMARY);
    
    tft.setTextColor(COLOR_TEXT_PRIMARY);
    tft.setCursor(okBtn.x + 35, okBtn.y + 10);
    tft.print("확인");
    
    vTaskDelay(pdMS_TO_TICKS(2000));
}
#endif

// ================================================================
// 통계 초기화 확인 팝업
// ================================================================
void showResetConfirmation() {
    int16_t popupW = 280;
    int16_t popupH = 140;
    int16_t popupX = (SCREEN_WIDTH - popupW) / 2;
    int16_t popupY = (SCREEN_HEIGHT - popupH) / 2;
    
    tft.fillScreen(0x18E3);
    
    CardConfig popup = {
        .x = popupX,
        .y = popupY,
        .w = popupW,
        .h = popupH,
        .bgColor = COLOR_BG_CARD,
        .borderColor = COLOR_DANGER
    };
    drawCard(popup);
    
    drawIconWarning(popupX + popupW / 2 - 8, popupY + 15, COLOR_DANGER);
    
    tft.setTextSize(TEXT_SIZE_MEDIUM);
    tft.setTextColor(COLOR_TEXT_PRIMARY);
    tft.setCursor(popupX + 80, popupY + 45);
    tft.print("통계 초기화");
    
    tft.setTextSize(TEXT_SIZE_SMALL);
    tft.setTextColor(COLOR_TEXT_SECONDARY);
    tft.setCursor(popupX + 40, popupY + 70);
    tft.print("모든 통계를 초기화합니다");
    
    tft.setCursor(popupX + 70, popupY + 85);
    tft.print("계속하시겠습니까?");
    
    // 버튼
    ButtonConfig cancelBtn = {
        .x = (int16_t)(popupX + 20),
        .y = (int16_t)(popupY + popupH - 35),
        .w = 110,
        .h = 28,
        .label = "취소",
        .style = BTN_OUTLINE,
        .enabled = true
    };
    drawButton(cancelBtn);
    
    ButtonConfig confirmBtn = {
        .x = (int16_t)(popupX + popupW - 130),
        .y = (int16_t)(popupY + popupH - 35),
        .w = 110,
        .h = 28,
        .label = "초기화",
        .style = BTN_DANGER,
        .enabled = true
    };
    drawButton(confirmBtn);
    
    vTaskDelay(pdMS_TO_TICKS(2000));
    screenNeedsRedraw = true;
}

// ================================================================
// 온도 센서 정보 팝업
// ================================================================
void showTemperatureSensorInfo() {
    int16_t popupW = 300;
    int16_t popupH = 160;
    int16_t popupX = (SCREEN_WIDTH - popupW) / 2;
    int16_t popupY = (SCREEN_HEIGHT - popupH) / 2;
    
    // 배경
    tft.fillScreen(0x18E3);
    
    CardConfig popup = {
        .x = popupX,
        .y = popupY,
        .w = popupW,
        .h = popupH,
        .bgColor = COLOR_BG_CARD,
        .borderColor = COLOR_PRIMARY,
        .elevated = true
    };
    drawCard(popup);
    
    // 제목
    tft.setTextSize(TEXT_SIZE_MEDIUM);
    tft.setTextColor(COLOR_PRIMARY);
    tft.setCursor(popupX + CARD_PADDING, popupY + CARD_PADDING);
    tft.print("DS18B20 온도 센서");
    
    // 정보
    tft.setTextSize(TEXT_SIZE_SMALL);
    tft.setTextColor(COLOR_TEXT_PRIMARY);
    
    int16_t infoY = popupY + CARD_PADDING + 30;
    tft.setCursor(popupX + CARD_PADDING, infoY);
    tft.printf("센서 개수: %d개", 1); // getTemperatureSensorCount()
    
    tft.setCursor(popupX + CARD_PADDING, infoY + 20);
    tft.print("해상도: 12비트 (0.0625°C)");
    
    tft.setCursor(popupX + CARD_PADDING, infoY + 40);
    tft.print("정확도: ±0.5°C");
    
    tft.setCursor(popupX + CARD_PADDING, infoY + 60);
    tft.print("공장 캘리브레이션 적용됨");
    
    // 닫기 버튼
    ButtonConfig closeBtn = {
        .x = (int16_t)(popupX + (popupW - 100) / 2),
        .y = (int16_t)(popupY + popupH - 35),
        .w = 100,
        .h = 28,
        .label = "닫기",
        .style = BTN_PRIMARY,
        .enabled = true
    };
    drawButton(closeBtn);
    
    vTaskDelay(pdMS_TO_TICKS(3000));
    screenNeedsRedraw = true;
}
