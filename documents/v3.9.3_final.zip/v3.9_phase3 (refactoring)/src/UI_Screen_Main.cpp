// ================================================================
// UI_Screen_Main.cpp - 메인 화면 (v3.9.2 수정)
// sensorData → sensorManager 변경
// ================================================================

#include "../include/UI_Screens.h"
#include "../include/Config.h"
#include "SensorManager.h"  // ← 추가

extern LGFX tft;
extern SensorManager sensorManager;
extern SystemState currentState;

void drawMainScreen() {
    tft.fillScreen(TFT_BLACK);
    
    // 제목
    tft.setTextSize(2);
    tft.setTextColor(TFT_WHITE);
    tft.setCursor(10, 10);
    tft.print("진공 제어 시스템");
    
    // SensorManager에서 센서 값 가져오기
    float pressure = sensorManager.getPressure();
    float current = sensorManager.getCurrent();
    float temperature = sensorManager.getTemperature();
    
    // 센서 값 표시
    tft.setTextSize(1);
    tft.setCursor(10, 50);
    tft.printf("압력: %.2f kPa", pressure);
    
    tft.setCursor(10, 70);
    tft.printf("전류: %.2f A", current);
    
    tft.setCursor(10, 90);
    tft.printf("온도: %.2f C", temperature);
    
    // 상태 표시
    tft.setCursor(10, 120);
    tft.print("상태: ");
    switch(currentState) {
        case STATE_IDLE: tft.print("대기"); break;
        case STATE_VACUUM_ON: tft.print("진공중"); break;
        case STATE_ERROR: tft.print("에러"); break;
        default: tft.print("알수없음"); break;
    }
    
    // 버튼들
    tft.fillRect(10, 200, 100, 40, TFT_GREEN);
    tft.setTextColor(TFT_BLACK);
    tft.setCursor(30, 215);
    tft.print("시작");
    
    tft.fillRect(120, 200, 100, 40, TFT_RED);
    tft.setCursor(140, 215);
    tft.print("정지");
}

void handleMainTouch(uint16_t x, uint16_t y) {
    // 시작 버튼
    if (x >= 10 && x <= 110 && y >= 200 && y <= 240) {
        Serial.println("[UI] 시작 버튼");
    }
    // 정지 버튼
    else if (x >= 120 && x <= 220 && y >= 200 && y <= 240) {
        Serial.println("[UI] 정지 버튼");
    }
}
