// ================================================================
// EnhancedWatchdog.cpp - 향상된 Watchdog 시스템 구현
// ================================================================
#include "EnhancedWatchdog.h"
#include <Preferences.h>

// FreeRTOS (delay 개선)
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

// 전역 인스턴스
EnhancedWatchdog enhancedWatchdog;

// Preferences 객체 (재시작 정보 저장용)
static Preferences wdtPrefs;

// ================================================================
// 초기화
// ================================================================
void EnhancedWatchdog::begin(uint32_t timeout) {
    Serial.println("[EnhancedWDT] 초기화 시작...");
    
    taskCount = 0;
    enabled = true;
    startTime = millis();
    lastUpdateTime = millis();
    
    // 태스크 배열 초기화
    for (uint8_t i = 0; i < MAX_TASK_MONITORS; i++) {
        tasks[i].name[0] = '\0';
        tasks[i].enabled = false;
        tasks[i].status = TASK_NOT_MONITORED;
    }
    
    // 재시작 정보 로드
    loadRestartInfo();
    
    // ESP32 하드웨어 Watchdog 설정
    esp_task_wdt_init(timeout, true);
    esp_task_wdt_add(NULL);  // 현재 태스크 추가
    
    Serial.printf("[EnhancedWDT] 초기화 완료 (타임아웃: %d초)\n", timeout);
    
    // 재시작 정보 출력
    if (rtcRestartInfo.reason != RESTART_NONE && 
        rtcRestartInfo.reason != RESTART_POWER_ON) {
        Serial.println("[EnhancedWDT] ⚠️ 이전 재시작 감지:");
        printRestartHistory();
    }
}

// ================================================================
// 태스크 등록
// ================================================================
bool EnhancedWatchdog::registerTask(const char* name, uint32_t checkInInterval) {
    if (taskCount >= MAX_TASK_MONITORS) {
        Serial.printf("[EnhancedWDT] ❌ 태스크 등록 실패: 최대 개수 초과 (%s)\n", name);
        return false;
    }
    
    // 중복 확인
    if (findTask(name) >= 0) {
        Serial.printf("[EnhancedWDT] ⚠️  태스크 이미 등록됨: %s\n", name);
        return false;
    }
    
    // 새 태스크 등록
    TaskInfo* task = &tasks[taskCount];
    strncpy(task->name, name, sizeof(task->name) - 1);
    task->name[sizeof(task->name) - 1] = '\0';
    task->checkInInterval = checkInInterval;
    task->lastCheckIn = millis();
    task->missedCheckins = 0;
    task->totalCheckins = 0;
    task->status = TASK_HEALTHY;
    task->enabled = true;
    
    taskCount++;
    
    Serial.printf("[EnhancedWDT] ✅ 태스크 등록: %s (간격: %lums)\n", 
                  name, checkInInterval);
    return true;
}

// ================================================================
// 태스크 등록 해제
// ================================================================
void EnhancedWatchdog::unregisterTask(const char* name) {
    int8_t idx = findTask(name);
    if (idx < 0) return;
    
    // 마지막 태스크로 이동 후 개수 감소
    if (idx < taskCount - 1) {
        tasks[idx] = tasks[taskCount - 1];
    }
    taskCount--;
    
    Serial.printf("[EnhancedWDT] 태스크 등록 해제: %s\n", name);
}

// ================================================================
// 태스크 체크인
// ================================================================
void EnhancedWatchdog::checkIn(const char* name) {
    int8_t idx = findTask(name);
    if (idx < 0) return;
    
    TaskInfo* task = &tasks[idx];
    task->lastCheckIn = millis();
    task->totalCheckins++;
    task->missedCheckins = 0;
    task->status = TASK_HEALTHY;
}

// ================================================================
// 모니터링 업데이트 (loop에서 주기적 호출)
// ================================================================
void EnhancedWatchdog::update() {
    if (!enabled) return;
    
    uint32_t now = millis();
    
    // 주기적 체크 (1초마다)
    if (now - lastUpdateTime < TASK_CHECK_INTERVAL) {
        return;
    }
    lastUpdateTime = now;
    
    // 모든 태스크 상태 확인
    checkTasks();
    
    // 하드웨어 Watchdog feed
    feed();
}

// ================================================================
// 태스크 상태 확인
// ================================================================
void EnhancedWatchdog::checkTasks() {
    uint32_t now = millis();
    
    for (uint8_t i = 0; i < taskCount; i++) {
        TaskInfo* task = &tasks[i];
        if (!task->enabled) continue;
        
        uint32_t elapsed = now - task->lastCheckIn;
        
        // 타임아웃 체크
        if (elapsed > task->checkInInterval * 2) {
            // 2배 초과: 정지됨
            task->status = TASK_STALLED;
            task->missedCheckins++;
            
            // 데드락 체크
            if (task->missedCheckins >= DEADLOCK_THRESHOLD) {
                task->status = TASK_DEADLOCK;
                handleStalledTask(task);
            }
            
        } else if (elapsed > task->checkInInterval * 1.5) {
            // 1.5배 초과: 느림 (경고)
            task->status = TASK_SLOW;
            task->missedCheckins++;
            
        } else {
            // 정상
            task->status = TASK_HEALTHY;
            task->missedCheckins = 0;
        }
    }
}

// ================================================================
// 정지된 태스크 처리
// ================================================================
void EnhancedWatchdog::handleStalledTask(TaskInfo* task) {
    Serial.println("\n╔═══════════════════════════════════════╗");
    Serial.println("║   ⚠️  데드락 감지! ⚠️                ║");
    Serial.println("╠═══════════════════════════════════════╣");
    Serial.printf("║ 태스크: %-28s ║\n", task->name);
    Serial.printf("║ 미응답: %d회 연속                     ║\n", task->missedCheckins);
    Serial.printf("║ 마지막 체크인: %lu ms 전             ║\n", 
                  millis() - task->lastCheckIn);
    Serial.println("║                                       ║");
    Serial.println("║ 5초 후 자동 재시작합니다...          ║");
    Serial.println("╚═══════════════════════════════════════╝\n");
    
    vTaskDelay(pdMS_TO_TICKS(5000));  // 로그 출력 대기
    
    // 재시작 정보 저장 후 재시작
    forceRestart(RESTART_DEADLOCK, task->name);
}

// ================================================================
// 상태 조회
// ================================================================
TaskStatus EnhancedWatchdog::getTaskStatus(const char* name) {
    int8_t idx = findTask(name);
    if (idx < 0) return TASK_NOT_MONITORED;
    return tasks[idx].status;
}

TaskInfo* EnhancedWatchdog::getTaskInfo(const char* name) {
    int8_t idx = findTask(name);
    if (idx < 0) return nullptr;
    return &tasks[idx];
}

uint8_t EnhancedWatchdog::getRegisteredTaskCount() {
    return taskCount;
}

bool EnhancedWatchdog::isHealthy() {
    for (uint8_t i = 0; i < taskCount; i++) {
        if (tasks[i].enabled && tasks[i].status >= TASK_STALLED) {
            return false;
        }
    }
    return true;
}

// ================================================================
// 통계
// ================================================================
uint32_t EnhancedWatchdog::getUptimeSeconds() {
    return (millis() - startTime) / 1000;
}

uint32_t EnhancedWatchdog::getTotalRestarts() {
    return rtcRestartInfo.restartCount;
}

RestartInfo EnhancedWatchdog::getLastRestartInfo() {
    return rtcRestartInfo;
}

// ================================================================
// 제어
// ================================================================
void EnhancedWatchdog::enable() {
    enabled = true;
    Serial.println("[EnhancedWDT] Watchdog 활성화");
}

void EnhancedWatchdog::disable() {
    enabled = false;
    Serial.println("[EnhancedWDT] Watchdog 비활성화");
}

void EnhancedWatchdog::feed() {
    esp_task_wdt_reset();
}

void EnhancedWatchdog::forceRestart(RestartReason reason, const char* taskName) {
    Serial.printf("[EnhancedWDT] 강제 재시작 (원인: %d)\n", reason);
    
    saveRestartInfo(reason, taskName);
    vTaskDelay(pdMS_TO_TICKS(100));  // 저장 대기
    
    ESP.restart();
}

// ================================================================
// 재시작 정보 저장/로드
// ================================================================
void EnhancedWatchdog::saveRestartInfo(RestartReason reason, const char* taskName) {
    wdtPrefs.begin("wdt", false);
    
    wdtPrefs.putUInt("reason", (uint32_t)reason);
    wdtPrefs.putUInt("timestamp", millis() / 1000);
    wdtPrefs.putUInt("count", rtcRestartInfo.restartCount + 1);
    
    if (taskName) {
        wdtPrefs.putString("task", taskName);
    }
    
    wdtPrefs.end();
}

void EnhancedWatchdog::loadRestartInfo() {
    wdtPrefs.begin("wdt", true);
    
    rtcRestartInfo.reason = (RestartReason)wdtPrefs.getUInt("reason", RESTART_POWER_ON);
    rtcRestartInfo.timestamp = wdtPrefs.getUInt("timestamp", 0);
    rtcRestartInfo.restartCount = wdtPrefs.getUInt("count", 0);
    
    char taskNameBuf[32] = {0};
    wdtPrefs.getString("task", taskNameBuf, sizeof(taskNameBuf));
    strncpy(rtcRestartInfo.taskName, taskNameBuf, sizeof(rtcRestartInfo.taskName) - 1);
    rtcRestartInfo.taskName[sizeof(rtcRestartInfo.taskName) - 1] = '\0';
    
    wdtPrefs.end();
}

// ================================================================
// 진단 출력
// ================================================================
void EnhancedWatchdog::printStatus() {
    Serial.println("\n╔═══════════════════════════════════════╗");
    Serial.println("║     Enhanced Watchdog 상태            ║");
    Serial.println("╠═══════════════════════════════════════╣");
    Serial.printf("║ 활성화: %-29s ║\n", enabled ? "예" : "아니오");
    Serial.printf("║ 가동 시간: %lu 초                    ║\n", getUptimeSeconds());
    Serial.printf("║ 등록 태스크: %d개                     ║\n", taskCount);
    Serial.printf("║ 전체 상태: %-26s ║\n", isHealthy() ? "✅ 정상" : "⚠️  경고");
    Serial.println("╠═══════════════════════════════════════╣");
    
    for (uint8_t i = 0; i < taskCount; i++) {
        TaskInfo* task = &tasks[i];
        const char* statusStr;
        
        switch (task->status) {
            case TASK_HEALTHY:  statusStr = "✅ 정상"; break;
            case TASK_SLOW:     statusStr = "⚠️  느림"; break;
            case TASK_STALLED:  statusStr = "❌ 정지"; break;
            case TASK_DEADLOCK: statusStr = "🔴 데드락"; break;
            default:            statusStr = "❔ 미확인"; break;
        }
        
        uint32_t elapsed = millis() - task->lastCheckIn;
        Serial.printf("║ %-16s %s (%lums) ║\n", 
                      task->name, statusStr, elapsed);
    }
    
    Serial.println("╚═══════════════════════════════════════╝\n");
}

void EnhancedWatchdog::printTaskDetails(const char* name) {
    int8_t idx = findTask(name);
    if (idx < 0) {
        Serial.printf("[EnhancedWDT] 태스크 없음: %s\n", name);
        return;
    }
    
    TaskInfo* task = &tasks[idx];
    
    Serial.println("\n╔═══════════════════════════════════════╗");
    Serial.printf("║     태스크 상세 정보: %-15s ║\n", task->name);
    Serial.println("╠═══════════════════════════════════════╣");
    Serial.printf("║ 상태: %-31d ║\n", task->status);
    Serial.printf("║ 총 체크인: %lu회                      ║\n", task->totalCheckins);
    Serial.printf("║ 연속 미응답: %lu회                    ║\n", task->missedCheckins);
    Serial.printf("║ 마지막 체크인: %lu ms 전             ║\n", 
                  millis() - task->lastCheckIn);
    Serial.printf("║ 예상 간격: %lu ms                    ║\n", task->checkInInterval);
    Serial.println("╚═══════════════════════════════════════╝\n");
}

void EnhancedWatchdog::printRestartHistory() {
    const char* reasonStr;
    
    switch (rtcRestartInfo.reason) {
        case RESTART_WATCHDOG:      reasonStr = "Watchdog 타임아웃"; break;
        case RESTART_DEADLOCK:      reasonStr = "데드락 감지"; break;
        case RESTART_TASK_STALLED:  reasonStr = "태스크 정지"; break;
        case RESTART_MANUAL:        reasonStr = "수동 재시작"; break;
        case RESTART_OTA:           reasonStr = "OTA 업데이트"; break;
        case RESTART_POWER_ON:      reasonStr = "전원 켜짐"; break;
        default:                    reasonStr = "알 수 없음"; break;
    }
    
    Serial.println("╔═══════════════════════════════════════╗");
    Serial.println("║       재시작 정보                     ║");
    Serial.println("╠═══════════════════════════════════════╣");
    Serial.printf("║ 원인: %-31s ║\n", reasonStr);
    Serial.printf("║ 시간: %lu 초 전                      ║\n", rtcRestartInfo.timestamp);
    
    if (strlen(rtcRestartInfo.taskName) > 0) {
        Serial.printf("║ 태스크: %-29s ║\n", rtcRestartInfo.taskName);
    }
    
    Serial.printf("║ 총 재시작 횟수: %lu회                ║\n", rtcRestartInfo.restartCount);
    Serial.println("╚═══════════════════════════════════════╝\n");
}

// ================================================================
// 내부 유틸리티
// ================================================================
int8_t EnhancedWatchdog::findTask(const char* name) {
    for (uint8_t i = 0; i < taskCount; i++) {
        if (strcmp(tasks[i].name, name) == 0) {
            return i;
        }
    }
    return -1;
}
