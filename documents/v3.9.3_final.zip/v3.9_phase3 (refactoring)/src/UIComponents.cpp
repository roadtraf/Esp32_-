// ================================================================
// UIComponents.cpp - 재사용 가능한 UI 컴포넌트 구현
// ================================================================
#include "../include/UIComponents.h"
#include "../include/Config.h"
#include "../include/SystemController.h"
#include "../include/HealthMonitor.h"

extern LGFX tft;
extern SystemController systemController;
extern HealthMonitor healthMonitor;

namespace UIComponents {

// ================================================================
// 헤더 컴포넌트
// ================================================================
void drawHeader(const char* title, bool showManagerBadge) {
    using namespace UITheme;
    
    // 배경
    tft.fillRect(0, 0, SCREEN_WIDTH, HEADER_HEIGHT, COLOR_BG_DARK);
    
    // 하단 구분선
    tft.drawFastHLine(0, HEADER_HEIGHT - 1, SCREEN_WIDTH, COLOR_DIVIDER);
    
    // 타이틀
    tft.setTextSize(TEXT_SIZE_SMALL);
    tft.setTextColor(COLOR_TEXT_PRIMARY);
    tft.setCursor(SPACING_SM, 10);
    tft.print(title);
    
    // 관리자 배지 (Phase 2)
    if (showManagerBadge && !systemController.isOperatorMode()) {
        AccessLevel level = systemController.getCurrentLevel();
        const char* badgeText;
        uint16_t badgeColor;
        
        if (level == ACCESS_DEVELOPER) {
            badgeText = "DEV";
            badgeColor = COLOR_DEVELOPER;
        } else {
            badgeText = "MGR";
            badgeColor = COLOR_MANAGER;
        }
        
        // 배지 위치 (타이틀 오른쪽) - 상수 사용
        int16_t badgeX = SPACING_SM + strlen(title) * BADGE_X_OFFSET;
        
        tft.fillRoundRect(badgeX, BADGE_Y_OFFSET, BADGE_WIDTH, BADGE_HEIGHT, 7, badgeColor);
        tft.setTextSize(1);
        tft.setTextColor(COLOR_BG_DARK);
        tft.setCursor(badgeX + 6, 10);
        tft.print(badgeText);
    }
    
    // 건강도 표시 (우측) - 상수 사용
    #ifdef ENABLE_PREDICTIVE_MAINTENANCE
    float healthScore = healthMonitor.getHealthScore();
    
    uint16_t healthColor;
    if (healthScore >= 90.0f) healthColor = COLOR_SUCCESS;
    else if (healthScore >= 75.0f) healthColor = COLOR_WARNING;
    else healthColor = COLOR_DANGER;
    
    // 건강도 아이콘 (하트 모양 근사) - 상수 사용
    int16_t iconX = HEALTH_ICON_X;
    tft.fillCircle(iconX, 14, 4, healthColor);
    tft.fillCircle(iconX + 6, 14, 4, healthColor);
    tft.fillTriangle(iconX - 4, 15, iconX + 10, 15, iconX + 3, 22, healthColor);
    
    // 건강도 수치
    tft.setTextSize(1);
    tft.setTextColor(healthColor);
    tft.setCursor(iconX + 14, 10);
    tft.printf("%.0f%%", healthScore);
    #endif
}

// ================================================================
// 카드 컴포넌트
// ================================================================
void drawCard(const CardConfig& config) {
    using namespace UITheme;
    
    // 그림자 효과 (elevated)
    if (config.elevated) {
        tft.fillRoundRect(config.x + 2, config.y + 2, 
                         config.w, config.h, 
                         CARD_RADIUS, COLOR_DIVIDER);
    }
    
    // 카드 배경
    tft.fillRoundRect(config.x, config.y, config.w, config.h, 
                     CARD_RADIUS, config.bgColor);
    
    // 테두리
    if (config.borderColor != config.bgColor) {
        tft.drawRoundRect(config.x, config.y, config.w, config.h, 
                         CARD_RADIUS, config.borderColor);
    }
}

// ================================================================
// 버튼 컴포넌트
// ================================================================
void drawButton(const ButtonConfig& config) {
    using namespace UITheme;
    
    uint16_t bgColor, borderColor, textColor;
    
    // 스타일별 색상 결정
    switch (config.style) {
        case BTN_PRIMARY:
            bgColor = config.enabled ? COLOR_PRIMARY : COLOR_TEXT_DISABLED;
            borderColor = bgColor;
            textColor = COLOR_TEXT_PRIMARY;
            break;
            
        case BTN_SECONDARY:
            bgColor = config.enabled ? COLOR_ACCENT : COLOR_TEXT_DISABLED;
            borderColor = bgColor;
            textColor = COLOR_TEXT_PRIMARY;
            break;
            
        case BTN_SUCCESS:
            bgColor = config.enabled ? COLOR_SUCCESS : COLOR_TEXT_DISABLED;
            borderColor = bgColor;
            textColor = COLOR_TEXT_PRIMARY;
            break;
            
        case BTN_DANGER:
            bgColor = config.enabled ? COLOR_DANGER : COLOR_TEXT_DISABLED;
            borderColor = bgColor;
            textColor = COLOR_TEXT_PRIMARY;
            break;
            
        case BTN_OUTLINE:
            bgColor = COLOR_BG_CARD;
            borderColor = config.enabled ? COLOR_BORDER : COLOR_TEXT_DISABLED;
            textColor = config.enabled ? COLOR_TEXT_PRIMARY : COLOR_TEXT_DISABLED;
            break;
            
        default:
            bgColor = COLOR_BG_CARD;
            borderColor = COLOR_BORDER;
            textColor = COLOR_TEXT_PRIMARY;
    }
    
    // 버튼 배경
    tft.fillRoundRect(config.x, config.y, config.w, config.h, 
                     BUTTON_RADIUS, bgColor);
    
    // 버튼 테두리
    tft.drawRoundRect(config.x, config.y, config.w, config.h, 
                     BUTTON_RADIUS, borderColor);
    
    // 버튼 라벨 (중앙 정렬)
    tft.setTextSize(TEXT_SIZE_SMALL);
    tft.setTextColor(textColor);
    
    int16_t textW = strlen(config.label) * 6;  // 폰트 크기 1 = 6px
    int16_t textX = config.x + (config.w - textW) / 2;
    int16_t textY = config.y + (config.h - 8) / 2;
    
    tft.setCursor(textX, textY);
    tft.print(config.label);
}

bool isButtonPressed(const ButtonConfig& config, uint16_t touchX, uint16_t touchY) {
    if (!config.enabled) return false;
    
    return (touchX >= config.x && 
            touchX <= config.x + config.w &&
            touchY >= config.y && 
            touchY <= config.y + config.h);
}

// ================================================================
// 값 표시 컴포넌트
// ================================================================
void drawValueDisplay(const ValueDisplayConfig& config) {
    using namespace UITheme;
    
    // 라벨
    tft.setTextSize(1);
    tft.setTextColor(COLOR_TEXT_SECONDARY);
    tft.setCursor(config.x, config.y);
    tft.print(config.label);
    
    // 값
    tft.setTextSize(TEXT_SIZE_MEDIUM);
    tft.setTextColor(config.valueColor);
    tft.setCursor(config.x, config.y + 12);
    tft.print(config.value);
    
    // 단위
    if (config.unit != nullptr) {
        tft.setTextSize(TEXT_SIZE_SMALL);
        tft.print(" ");
        tft.print(config.unit);
    }
}

// ================================================================
// 상태 배지
// ================================================================
void drawBadge(int16_t x, int16_t y, const char* text, BadgeType type) {
    using namespace UITheme;
    
    uint16_t bgColor;
    
    switch (type) {
        case BADGE_SUCCESS:
            bgColor = COLOR_SUCCESS;
            break;
        case BADGE_WARNING:
            bgColor = COLOR_WARNING;
            break;
        case BADGE_DANGER:
            bgColor = COLOR_DANGER;
            break;
        case BADGE_INFO:
        default:
            bgColor = COLOR_INFO;
            break;
    }
    
    // 배지 크기 계산
    int16_t textLen = strlen(text);
    int16_t badgeW = textLen * 6 + SPACING_SM * 2;
    int16_t badgeH = 18;
    
    // 배지 배경
    tft.fillRoundRect(x, y, badgeW, badgeH, BADGE_RADIUS, bgColor);
    
    // 배지 텍스트
    tft.setTextSize(1);
    tft.setTextColor(COLOR_TEXT_PRIMARY);
    tft.setCursor(x + SPACING_SM, y + 5);
    tft.print(text);
}

// ================================================================
// 프로그레스 바
// ================================================================
void drawProgressBar(int16_t x, int16_t y, int16_t w, int16_t h, 
                     float percentage, uint16_t color) {
    using namespace UITheme;
    
    // 범위 제한
    if (percentage < 0) percentage = 0;
    if (percentage > 100) percentage = 100;
    
    // 배경 (회색)
    tft.fillRoundRect(x, y, w, h, 4, COLOR_BG_ELEVATED);
    
    // 진행 바
    int16_t fillW = (w - 4) * percentage / 100;
    if (fillW > 2) {
        tft.fillRoundRect(x + 2, y + 2, fillW, h - 4, 3, color);
    }
    
    // 테두리
    tft.drawRoundRect(x, y, w, h, 4, COLOR_BORDER);
}

// ================================================================
// 아이콘 - 홈
// ================================================================
void drawIconHome(int16_t x, int16_t y, uint16_t color) {
    // 지붕
    tft.fillTriangle(x + 8, y, x, y + 6, x + 16, y + 6, color);
    
    // 벽
    tft.fillRect(x + 2, y + 6, 12, 10, color);
    
    // 문
    tft.fillRect(x + 6, y + 10, 4, 6, UITheme::COLOR_BG_DARK);
}

// ================================================================
// 아이콘 - 설정 (톱니바퀴)
// ================================================================
void drawIconSettings(int16_t x, int16_t y, uint16_t color) {
    // 중심 원
    tft.fillCircle(x + 8, y + 8, 3, color);
    
    // 톱니 (8개)
    for (int i = 0; i < 8; i++) {
        float angle = i * PI / 4;
        int16_t x1 = x + 8 + cos(angle) * 6;
        int16_t y1 = y + 8 + sin(angle) * 6;
        tft.fillCircle(x1, y1, 2, color);
    }
}

// ================================================================
// 아이콘 - 뒤로 (화살표)
// ================================================================
void drawIconBack(int16_t x, int16_t y, uint16_t color) {
    // 화살표 머리
    tft.fillTriangle(x, y + 8, x + 6, y + 2, x + 6, y + 14, color);
    
    // 화살표 몸통
    tft.fillRect(x + 5, y + 6, 10, 4, color);
}

// ================================================================
// 아이콘 - 경고 (삼각형 + !)
// ================================================================
void drawIconWarning(int16_t x, int16_t y, uint16_t color) {
    // 삼각형
    tft.fillTriangle(x + 8, y, x, y + 16, x + 16, y + 16, color);
    
    // 느낌표 (!)
    tft.fillRect(x + 7, y + 5, 2, 6, UITheme::COLOR_BG_DARK);
    tft.fillRect(x + 7, y + 13, 2, 2, UITheme::COLOR_BG_DARK);
}

// ================================================================
// 아이콘 - 체크
// ================================================================
void drawIconCheck(int16_t x, int16_t y, uint16_t color) {
    // 체크 마크
    tft.drawLine(x + 2, y + 8, x + 6, y + 12, color);
    tft.drawLine(x + 6, y + 12, x + 14, y + 2, color);
    
    // 두껍게
    tft.drawLine(x + 2, y + 9, x + 6, y + 13, color);
    tft.drawLine(x + 6, y + 13, x + 14, y + 3, color);
}

// ================================================================
// 구분선
// ================================================================
void drawDivider(int16_t x, int16_t y, int16_t w) {
    tft.drawFastHLine(x, y, w, UITheme::COLOR_DIVIDER);
}

// ================================================================
// 네비게이션 바 (하단)
// ================================================================
void drawNavBar(NavButton buttons[], uint8_t count) {
    using namespace UITheme;
    
    int16_t navY = SCREEN_HEIGHT - FOOTER_HEIGHT;
    
    // 배경
    tft.fillRect(0, navY, SCREEN_WIDTH, FOOTER_HEIGHT, COLOR_BG_DARK);
    
    // 상단 구분선
    tft.drawFastHLine(0, navY, SCREEN_WIDTH, COLOR_DIVIDER);
    
    // 버튼 배치
    int16_t totalSpacing = SPACING_SM * (count + 1);
    int16_t buttonW = (SCREEN_WIDTH - totalSpacing) / count;
    int16_t buttonH = FOOTER_HEIGHT - 4;
    
    for (uint8_t i = 0; i < count; i++) {
        int16_t btnX = SPACING_SM + i * (buttonW + SPACING_SM);
        int16_t btnY = navY + 2;
        
        ButtonConfig btn = {
            .x = btnX,
            .y = btnY,
            .w = buttonW,
            .h = buttonH,
            .label = buttons[i].label,
            .style = buttons[i].style,
            .enabled = buttons[i].enabled
        };
        
        drawButton(btn);
    }
}

} // namespace UIComponents
