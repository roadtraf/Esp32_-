// ================================================================
// main_cpp_refactoring_v3.cpp  —  ESP32-S3 진공 제어 시스템 v3.9.2 Phase 3-1
//              예측 유지보수 + ML + ThingSpeak 클라우드
//              + 스마트 유지보수 알림 + 음성 알림 시스템 + 작업자/관리자 이원화 시스템
//              + 완전 리팩토링 버전 (Manager Pattern)
//              + CommandHandler로 명령 처리 분리
//              + SensorData 캡슐화 (v3 개선)
// ================================================================

#include "../include/Config.h"
#include "../include/LovyanGFX_Config.hpp"

// ================================================================
// Manager 모듈 헤더 (v3.9 Phase 3-1 리팩토링)
// ================================================================
#include "SystemController.h"
#include "SensorManager.h"       // ← 개선된 버전 (sensorData 캡슐화)
#include "ControlManager.h"
#include "NetworkManager.h"
#include "UIManager.h"
#include "ConfigManager.h"
#include "CommandHandler.h"

// 개선사항 헤더 추가
#include "ExceptionHandler.h"
#include "InitializationHelper.h"
#include "CommandHistory.h"
#include "SafeModeEnhanced.h"
#include "Control.h"

// ================================================================
// 기존 필수 모듈 헤더
// ================================================================
#include "Tasks.h"
#include "SerialCommands.h"
#include "UnitTest_Framework.h"

// ── v3.6+ 고급 기능 모듈 ──
#include "../include/CloudManager.h"
#include "../include/HealthMonitor.h"
#include "../include/MLPredictor.h"

// ── 기존 핵심 모듈 ──
#include "../include/Sensor.h"
#include "../include/Control.h"
#include "../include/PID_Control.h"
#include "../include/StateMachine.h"
#include "../include/ErrorHandler.h"
#include "../include/SD_Logger.h"
#include "../include/Network.h"

// ── USB 키보드 ──
#include <USBHIDKeyboard.h>
#include "../include/USB_Keyboard.h"

// ── UI 모듈 ──
#include "../include/UI_Screens.h"
#include "../include/Trend_Graph.h"
#include "../include/UI_Screen_StateDiagram.h"

// ── Data Log ──
#include "../include/DataLogger.h"

// ── Smart Alert (v3.8) ──
#include "../include/SmartAlert.h"

// ── v3.9: 음성 알림 ──
#ifdef ENABLE_VOICE_ALERTS
#include "VoiceAlert.h"
extern VoiceAlert voiceAlert;
#endif

// ── Phase 2 최적화 모듈 ──
#include "TaskConfig.h"
#include "SystemTest.h"
#include "WiFiPowerManager.h"
#include "EnhancedWatchdog.h"

// ================================================================
// 전역 객체 정의 (최소화)
// ================================================================

// 디스플레이
LGFX tft;

// Manager 객체들 (Phase 3-1 리팩토링)
SystemController systemController;
SensorManager sensorManager;      // ← sensorData는 이제 이 안에 캡슐화됨
ControlManager controlManager;
NetworkManager networkManager;
UIManager uiManager;
ConfigManager configManager;
CommandHandler commandHandler;

// USB 키보드
USBHIDKeyboard keyboard;

// 조건부 객체
#ifdef ENABLE_PREDICTIVE_MAINTENANCE
HealthMonitor healthMonitor;
#endif

#ifdef ENABLE_SMART_ALERTS
SmartAlert smartAlert;
#endif

#ifdef ENABLE_VOICE_ALERTS
VoiceAlert voiceAlert;
#endif

// ================================================================
// 타이밍 변수
// ================================================================
uint32_t lastCloudUpdate = 0;
uint32_t lastMLUpdate = 0;
uint32_t lastHealthUpdate = 0;
uint32_t lastSmartAlertCheck = 0;

// ================================================================
// 핀 초기화 함수
// ================================================================
static void initPins() {
  // 제어 출력
  pinMode(PIN_PUMP_PWM,        OUTPUT);
  pinMode(PIN_VALVE,           OUTPUT);
  pinMode(PIN_12V_MAIN,        OUTPUT);
  pinMode(PIN_12V_EMERGENCY,   OUTPUT);
  digitalWrite(PIN_PUMP_PWM,      LOW);
  digitalWrite(PIN_VALVE,         LOW);
  digitalWrite(PIN_12V_MAIN,      LOW);
  digitalWrite(PIN_12V_EMERGENCY, LOW);

  // PWM 설정
  ledcSetup(PWM_CHANNEL_PUMP, PWM_FREQUENCY, PWM_RESOLUTION);
  ledcAttachPin(PIN_PUMP_PWM, PWM_CHANNEL_PUMP);
  ledcWrite(PWM_CHANNEL_PUMP, 0);

  // 센서 입력
  pinMode(PIN_PRESSURE_SENSOR, INPUT);
  pinMode(PIN_CURRENT_SENSOR,  INPUT);
  pinMode(PIN_LIMIT_SWITCH,    INPUT_PULLUP);
  pinMode(PIN_PHOTO_SENSOR,    INPUT_PULLUP);
  pinMode(PIN_EMERGENCY_STOP,  INPUT_PULLUP);

  // 알람 출력
  pinMode(PIN_BUZZER,    OUTPUT);
  pinMode(PIN_LED_GREEN, OUTPUT);
  pinMode(PIN_LED_RED,   OUTPUT);
  digitalWrite(PIN_BUZZER,    LOW);
  digitalWrite(PIN_LED_GREEN, LOW);
  digitalWrite(PIN_LED_RED,   LOW);
}

// ================================================================
// 스플래시 화면
// ================================================================
static void drawSplashScreen() {
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);

  tft.setTextSize(3);
  tft.setCursor(80, 70);
  tft.print("ESP32-S3");

  tft.setTextSize(2);
  tft.setCursor(80, 120);
  tft.print("VACUUM CONTROL");

  tft.setTextSize(2);
  tft.setCursor(180, 160);
  tft.print("v3.9.2");

  tft.setTextSize(1);
  tft.setCursor(90, 190);
  tft.print("Phase 3-1: Refactored v3");
  
  tft.setCursor(70, 210);
  tft.print("SensorData Encapsulated");

  // 로딩 바
  for (int i = 0; i < 400; i += 10) {
    tft.fillRect(40 + i, 260, 10, 20, TFT_GREEN);
    delay(20);
  }
}

// ================================================================
// setup() - 리팩토링 버전 v3
// ================================================================
void setup() {
  // ────────────────────────────────────────────────────────────
  // Step 1: 시리얼 초기화 및 시스템 정보 출력
  // ────────────────────────────────────────────────────────────
  Serial.begin(115200);
  delay(1000);
  Serial.println("\n\n===============================================");
  Serial.println("ESP32-S3 진공 제어 시스템 v3.9.2 Phase 3-1 v3");
  Serial.println("Refactored Architecture with Manager Pattern");
  Serial.println("===============================================");
  Serial.println("Features:");
  Serial.println("  - Predictive Maintenance + ML");
  Serial.println("  - Smart Alerts + Voice System");
  Serial.println("  - Operator/Manager/Developer Modes");
  Serial.println("  - Enhanced Watchdog + Config Management");
  Serial.println("  - CommandHandler for Serial Commands");
  Serial.println("  - SensorData Encapsulation (v3 NEW!)");
  Serial.println("===============================================\n");

  // ────────────────────────────────────────────────────────────
  // Step 2: Safe Mode 초기화 (최우선!)
  // ────────────────────────────────────────────────────────────
 
// Safe Mode 체크 (개선)
    safeModeEnhanced.begin();
    if (safeModeEnhanced.isInSafeMode()) {
        Serial.println("[SAFE] Safe Mode");
        return;
    }

  // ────────────────────────────────────────────────────────────
  // Step 3: 하드웨어 초기화
  // ────────────────────────────────────────────────────────────
  Serial.println("[INIT] 핀 초기화...");
  initPins();
  Serial.println("[INIT] 핀 초기화 완료");

  // ────────────────────────────────────────────────────────────
  // Step 4: 디스플레이 초기화
  // ────────────────────────────────────────────────────────────
  Serial.println("[INIT] 디스플레이 초기화...");
  tft.init();
  tft.setRotation(1);
  drawSplashScreen();
  Serial.println("[INIT] 디스플레이 초기화 완료");

  // ────────────────────────────────────────────────────────────
  // Step 5: Manager 객체 초기화 (리팩토링의 핵심)
  // ────────────────────────────────────────────────────────────
      // 초기화 헬퍼 사용 (개선)
    INIT_MANAGER(systemController, "SystemController", true);
    INIT_MANAGER(sensorManager, "SensorManager", true);
    INIT_MANAGER(controlManager, "ControlManager", true);
    INIT_MANAGER(networkManager, "NetworkManager", false);
    INIT_MANAGER(uiManager, "UIManager", true);
    INIT_MANAGER(configManager, "ConfigManager", false);
    INIT_MANAGER(commandHandler, "CommandHandler", true);
   
  // ────────────────────────────────────────────────────────────
  // Step 6: 기존 모듈 초기화
  // ────────────────────────────────────────────────────────────
  Serial.println("[INIT] 기존 모듈 초기화...");
  
  // USB 키보드
  keyboard.begin();
  USB.begin();
  Serial.println("[INIT] USB 키보드 초기화 완료");
  
  // sensorManager 초기화
  sensorManager.begin();
  initControl();
  Serial.println("[INIT] 센서 매니저 초기화 완료");

  // StateMachine 초기화
  initStateMachine();
  Serial.println("[INIT] 상태 머신 초기화 완료");

  // ErrorHandler 초기화
  initErrorHandler();
  Serial.println("[INIT] 에러 핸들러 초기화 완료");

  // SD Logger 초기화
  initSDLogger();
  Serial.println("[INIT] SD 로거 초기화 완료");

  // DataLogger 초기화
  DataLogger::init();
  Serial.println("[INIT] 데이터 로거 초기화 완료");

  // ────────────────────────────────────────────────────────────
  // Step 7: 조건부 모듈 초기화
  // ────────────────────────────────────────────────────────────
  
  #ifdef ENABLE_PREDICTIVE_MAINTENANCE
  Serial.println("[INIT] HealthMonitor 초기화...");
  healthMonitor.begin();
  Serial.println("[INIT] HealthMonitor 초기화 완료");
  
  Serial.println("[INIT] MLPredictor 초기화...");
  mlPredictor.begin();
  Serial.println("[INIT] MLPredictor 초기화 완료");
  #endif

  #ifdef ENABLE_SMART_ALERTS
  Serial.println("[INIT] SmartAlert 초기화...");
  smartAlert.begin();
  Serial.println("[INIT] SmartAlert 초기화 완료");
  #endif

  #ifdef ENABLE_VOICE_ALERTS
  Serial.println("[INIT] VoiceAlert 초기화...");
  voiceAlert.begin();
  Serial.println("[INIT] VoiceAlert 초기화 완료");
  #endif

  // ────────────────────────────────────────────────────────────
  // Step 8: Enhanced Watchdog 초기화
  // ────────────────────────────────────────────────────────────
  Serial.println("[INIT] EnhancedWatchdog 초기화...");
  enhancedWatchdog.begin();
  enhancedWatchdog.registerTask("main", 5000);
  Serial.println("[INIT] EnhancedWatchdog 초기화 완료");

  // ────────────────────────────────────────────────────────────
  // Step 9: FreeRTOS 태스크 생성
  // ────────────────────────────────────────────────────────────
  Serial.println("\n[RTOS] FreeRTOS 태스크 생성...");
  createTasks();
  Serial.println("[RTOS] FreeRTOS 태스크 생성 완료");

  // ────────────────────────────────────────────────────────────
  // Step 10: 초기화 완료
  // ────────────────────────────────────────────────────────────
  Serial.println("\n===============================================");
  Serial.println("시스템 초기화 완료!");
  Serial.println("===============================================");
  Serial.printf("현재 모드: %s\n", systemController.getModeString());
  Serial.println("시리얼 명령어 입력 대기 중...");
  Serial.println("도움말: 'help' 입력");
  Serial.println("===============================================\n");

  // 스플래시 화면 지우고 메인 화면으로
  delay(1000);
  uiManager.setScreen(SCREEN_MAIN);
  uiManager.redrawScreen();
}

// ================================================================
// loop() - 리팩토링 버전 v3 (sensorData 캡슐화)
// ================================================================
void loop() {
  static uint32_t lastLoopTime = 0;
  uint32_t currentTime = millis();
  
  // Safe Mode 체크
    if (safeModeEnhanced.isInSafeMode()) {
        safeModeEnhanced.update();
        commandHandler.handleSerialCommands();
        vTaskDelay(pdMS_TO_TICKS(100));  // delay(100) 개선
        return;
    }

  // ────────────────────────────────────────────────────────────
  // 1. Watchdog 업데이트
  // ────────────────────────────────────────────────────────────
  enhancedWatchdog.feed("main");

  // ────────────────────────────────────────────────────────────
  // 2. 시리얼 명령 처리 (CommandHandler로 위임)
  // ────────────────────────────────────────────────────────────
  commandHandler.handleSerialCommands();

  // ────────────────────────────────────────────────────────────
  // 3. SystemController 자동 로그아웃 체크
  // ────────────────────────────────────────────────────────────
  systemController.checkAutoLogout();

  // ────────────────────────────────────────────────────────────
  // 4. Manager 객체 업데이트 (리팩토링의 핵심)
  // ────────────────────────────────────────────────────────────
  
  // 센서 읽기 및 버퍼 업데이트 (sensorData는 내부에서 관리됨)
  sensorManager.readAllSensors();
  sensorManager.updateBuffers();
  
  // 제어 업데이트
  controlManager.update();
  
  // 네트워크 업데이트
  networkManager.update();
  
  // UI 업데이트
  uiManager.update();
  
  // 자동 제어 (센서 기반, 추천!)
  updateControl();  
  // 또는 수동 제어
  // controlPump(true, 180);  // PWM 180으로 펌프 ON
  vTaskDelay(pdMS_TO_TICKS(10));
  
  // ────────────────────────────────────────────────────────────
  // 5. 고급 기능 업데이트 (조건부)
  // ────────────────────────────────────────────────────────────
  
  #ifdef ENABLE_PREDICTIVE_MAINTENANCE
  // ML 업데이트 (5초마다) - sensorManager에서 데이터 가져옴
  if (currentTime - lastMLUpdate >= ML_UPDATE_INTERVAL) {
    mlPredictor.addSample(
      sensorManager.getPressure(),
      sensorManager.getTemperature(),
      sensorManager.getCurrent()
    );
    lastMLUpdate = currentTime;
  }

  // Health 업데이트 (10초마다) - sensorManager에서 데이터 가져옴
  if (currentTime - lastHealthUpdate >= HEALTH_UPDATE_INTERVAL) {
    healthMonitor.update(
      sensorManager.getPressure(),
      sensorManager.getTemperature(),
      sensorManager.getCurrent(),
      pumpPWM,
      currentState
    );
    lastHealthUpdate = currentTime;
  }
  #endif

  #ifdef ENABLE_SMART_ALERTS
  // SmartAlert 체크 (1분마다) - sensorManager에서 전체 데이터 가져옴
  if (currentTime - lastSmartAlertCheck >= SMART_ALERT_CHECK_INTERVAL) {
    smartAlert.checkAndAlert(currentState, sensorManager.getData(), stats);
    lastSmartAlertCheck = currentTime;
  }
  #endif

  // ────────────────────────────────────────────────────────────
  // 6. 클라우드 업데이트 (설정된 간격마다)
  // ────────────────────────────────────────────────────────────
  #ifdef ENABLE_CLOUD
  if (currentTime - lastCloudUpdate >= config.cloudUpdateInterval * 1000) {
    if (networkManager.isConnected()) {
      cloudManager.update(sensorManager.getData(), currentState, stats);
      lastCloudUpdate = currentTime;
    }
  }
  #endif

  // ────────────────────────────────────────────────────────────
  // 7. 터치 입력 처리
  // ────────────────────────────────────────────────────────────
  uiManager.handleTouch();

  // ────────────────────────────────────────────────────────────
  // 8. 에러 체크
  // ────────────────────────────────────────────────────────────
  if (errorActive) {
    handleError();
  }

  // ────────────────────────────────────────────────────────────
  // 9. 루프 성능 모니터링 (디버그용)
  // ────────────────────────────────────────────────────────────
  #ifdef DEBUG_LOOP_TIME
  uint32_t loopDuration = millis() - currentTime;
  if (loopDuration > 100) {
    Serial.printf("[WARNING] Loop took %lu ms\n", loopDuration);
  }
  #endif

   // 짧은 딜레이 (CPU 점유율 조절)
    vTaskDelay(pdMS_TO_TICKS(10));  // delay(10) 개선
}
