
#include "Config.h"                 // SystemConfig, wifiConnected …
#include <WiFi.h>
#include <ESPmDNS.h>
#include <WiFiUdp.h>
#include <ArduinoOTA.h>
#include <WebServer.h>
#include <Update.h>

// 웹 서버
WebServer server(80);

// ==================== OTA 초기화 ====================
void initOTA() {
  if (!wifiConnected) {
    Serial.println("[OTA] WiFi 미연결, 건너뜀");
    return;
  }

  // ArduinoOTA 설정
  ArduinoOTA.setHostname("VacuumControl");
  ArduinoOTA.setPassword("admin");

  ArduinoOTA.onStart([]() {
    const char* type = (ArduinoOTA.getCommand() == U_FLASH) ? "sketch" : "filesystem";
    Serial.printf("[OTA] 업데이트 시작: %s\n", type);
  });

  ArduinoOTA.onEnd([]() {
    Serial.println("\n[OTA] 업데이트 완료");
  });

  ArduinoOTA.onProgress([](unsigned int progress, unsigned int total) {
    Serial.printf("[OTA] 진행: %u%%\r", (progress / (total / 100)));
  });

  ArduinoOTA.onError([](ota_error_t error) {
    Serial.printf("[OTA] 에러[%u]: ", error);
    if (error == OTA_AUTH_ERROR) Serial.println("인증 실패");
    else if (error == OTA_BEGIN_ERROR) Serial.println("시작 실패");
    else if (error == OTA_CONNECT_ERROR) Serial.println("연결 실패");
    else if (error == OTA_RECEIVE_ERROR) Serial.println("수신 실패");
    else if (error == OTA_END_ERROR) Serial.println("종료 실패");
  });

  ArduinoOTA.begin();
  Serial.println("[OTA] ArduinoOTA 활성화됨");

  // HTTP 서버 설정
  setupWebServer();
}

// ==================== 웹 서버 설정 ====================
void setupWebServer() {
  // 루트 페이지
  server.on("/", HTTP_GET, []() {
    static const char ROOT_HTML[] =
      "<html><body>"
      "<h1>ESP32-S3 Vacuum Control</h1>"
      "<p>Version: 3.2</p>"
      "<p><a href='/status'>Status</a></p>"
      "<p><a href='/update'>Firmware Update</a></p>"
      "</body></html>";
    server.send(200, "text/html", ROOT_HTML);
  });

  // 상태 페이지
  server.on("/status", HTTP_GET, []() {
    extern SystemState currentState;
    extern SensorData sensorData;
    extern Statistics stats;
    extern const char* getStateName(SystemState);

    char json[256];
    snprintf(json, sizeof(json),
             "{\"state\":\"%s\",\"pressure\":%.2f,\"current\":%.2f,\"cycles\":%lu,\"uptime\":%lu}",
             getStateName(currentState),
             sensorData.pressure,
             sensorData.current,
             stats.totalCycles,
             stats.uptime);
    server.send(200, "application/json", json);
  });

  // 명령 페이지
  server.on("/cmd", HTTP_GET, []() {
    if (server.hasArg("action")) {
      char action[32];
      server.arg("action").toCharArray(action, sizeof(action));
      extern SystemState currentState;
      extern void changeState(SystemState);

      if (strcmp(action, "start") == 0 && currentState == STATE_IDLE) {
        changeState(STATE_VACUUM_ON);
        server.send(200, "text/plain", "Started");
      } else if (strcmp(action, "stop") == 0) {
        changeState(STATE_IDLE);
        server.send(200, "text/plain", "Stopped");
      } else {
        server.send(400, "text/plain", "Invalid action");
      }
    } else {
      server.send(400, "text/plain", "Missing action parameter");
    }
  });

  // 펌웨어 업데이트 페이지
  server.on("/update", HTTP_GET, []() {
    static const char UPDATE_HTML[] =
      "<html><body>"
      "<h1>Firmware Update</h1>"
      "<form method='POST' action='/update' enctype='multipart/form-data'>"
      "<input type='file' name='update'>"
      "<input type='submit' value='Update'>"
      "</form>"
      "</body></html>";
    server.send(200, "text/html", UPDATE_HTML);
  });

  server.on("/update", HTTP_POST, []() {
    server.sendHeader("Connection", "close");
    server.send(200, "text/plain", (Update.hasError()) ? "FAIL" : "OK");
    ESP.restart();
  }, []() {
    HTTPUpload& upload = server.upload();
    if (upload.status == UPLOAD_FILE_START) {
      Serial.printf("[OTA] 업데이트 파일: %s\n", upload.filename.c_str());
      if (!Update.begin(UPDATE_SIZE_UNKNOWN)) {
        Update.printError(Serial);
      }
    } else if (upload.status == UPLOAD_FILE_WRITE) {
      if (Update.write(upload.buf, upload.currentSize) != upload.currentSize) {
        Update.printError(Serial);
      }
    } else if (upload.status == UPLOAD_FILE_END) {
      if (Update.end(true)) {
        Serial.printf("[OTA] 업데이트 성공: %u bytes\n", upload.totalSize);
      } else {
        Update.printError(Serial);
      }
    }
  });

  server.begin();
  Serial.println("[HTTP] 웹 서버 시작됨 (포트 80)");
}

// ==================== OTA 처리 ====================
void handleOTA() {
  ArduinoOTA.handle();
  server.handleClient();
}


