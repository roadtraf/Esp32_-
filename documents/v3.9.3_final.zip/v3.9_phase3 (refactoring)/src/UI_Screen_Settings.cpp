// ================================================================
// UI_Screen_Settings.cpp - 재설계 설정 화면 (Bug Fixed)
// ================================================================
#include "../include/UIComponents.h"
#include "../include/Config.h"
#include "../include/SystemController.h"

// ✅ FIX #1: VoiceAlert 헤더 추가
#ifdef ENABLE_VOICE_ALERTS
#include "../include/VoiceAlert.h"
extern VoiceAlert voiceAlert;
#endif

using namespace UIComponents;
using namespace UITheme;

// ================================================================
// 설정 화면 - 그리드 메뉴 레이아웃
// ================================================================
void drawSettingsScreen() {
    tft.fillScreen(COLOR_BG_DARK);
    
    // ── 헤더 ──
    drawHeader("설정");
    
    // ── 메뉴 그리드 (3x4) ──
    int16_t startY = HEADER_HEIGHT + SPACING_SM;
    int16_t cardW = (SCREEN_WIDTH - SPACING_SM * 4) / 3;
    int16_t cardH = 60;
    
    // 메뉴 항목 데이터
    struct MenuItem {
        const char* title;
        const char* subtitle;
        uint16_t iconColor;
        ScreenType screen;
        bool requiresAuth;
    };
    
    MenuItem menuItems[] = {
        {"타이밍", "시간 설정", COLOR_PRIMARY, SCREEN_TIMING_SETUP, false},
        {"PID", "제어 파라미터", COLOR_ACCENT, SCREEN_PID_SETUP, false},
        {"통계", "사용 기록", COLOR_INFO, SCREEN_STATISTICS, false},
        
        {"추세", "그래프", COLOR_SUCCESS, SCREEN_TREND_GRAPH, false},
        {"캘리브레이션", "센서 조정", COLOR_WARNING, SCREEN_CALIBRATION, true},
        {"정보", "시스템 정보", COLOR_TEXT_SECONDARY, SCREEN_ABOUT, false},
        
        {"도움말", "사용법", COLOR_PRIMARY, SCREEN_HELP, false},
        {"상태도", "시스템 상태", COLOR_ACCENT, SCREEN_STATE_DIAGRAM, false},
        {"언어", currentLang == LANG_KO ? "한국어" : "English", COLOR_INFO, SCREEN_SETTINGS, false},
        
        #ifdef ENABLE_PREDICTIVE_MAINTENANCE
        {"건강도", "예측 유지보수", COLOR_SUCCESS, SCREEN_HEALTH, true},
        #else
        {"", "", 0, SCREEN_MAIN, false},
        #endif
        
        #ifdef ENABLE_SMART_ALERTS
        {"알림", "스마트 알림", COLOR_MANAGER, SCREEN_SMART_ALERT_CONFIG, true},
        #else
        {"", "", 0, SCREEN_MAIN, false},
        #endif
        
        #ifdef ENABLE_VOICE_ALERTS
        // ✅ FIX #2: voiceAlert를 안전하게 사용 (헤더 include됨)
        {"음성", voiceAlert.isOnline() ? "활성" : "비활성", COLOR_DEVELOPER, SCREEN_VOICE_SETTINGS, true}
        #else
        {"", "", 0, SCREEN_MAIN, false}
        #endif
    };
    
    // ✅ FIX #3: 배열 크기 동적 계산
    const int MENU_ITEM_COUNT = sizeof(menuItems) / sizeof(menuItems[0]);
    
    // 메뉴 카드 그리기
    for (int row = 0; row < 4; row++) {
        for (int col = 0; col < 3; col++) {
            int idx = row * 3 + col;
            
            // ✅ FIX #4: 동적 크기 체크
            if (idx >= MENU_ITEM_COUNT) break;
            
            if (strlen(menuItems[idx].title) == 0) continue;
            
            int16_t x = SPACING_SM + col * (cardW + SPACING_SM);
            int16_t y = startY + row * (cardH + SPACING_SM);
            
            // 권한 확인
            bool hasAccess = true;
            if (menuItems[idx].requiresAuth) {
                hasAccess = !systemController.isOperatorMode();
            }
            
            CardConfig menuCard = {
                .x = x,
                .y = y,
                .w = cardW,
                .h = cardH,
                .bgColor = hasAccess ? COLOR_BG_CARD : COLOR_BG_DARK,
                .borderColor = hasAccess ? menuItems[idx].iconColor : COLOR_TEXT_DISABLED
            };
            drawCard(menuCard);
            
            // 아이콘 영역 (상단 색상 바)
            tft.fillRect(x + 2, y + 2, cardW - 4, 4, menuItems[idx].iconColor);
            
            // 타이틀
            tft.setTextSize(TEXT_SIZE_SMALL);
            tft.setTextColor(hasAccess ? COLOR_TEXT_PRIMARY : COLOR_TEXT_DISABLED);
            tft.setCursor(x + 6, y + 12);
            tft.print(menuItems[idx].title);
            
            // 서브타이틀
            tft.setTextSize(1);
            tft.setTextColor(COLOR_TEXT_SECONDARY);
            tft.setCursor(x + 6, y + 28);
            
            // 텍스트 길이 체크 후 축약
            if (strlen(menuItems[idx].subtitle) > 10) {
                char shortText[11];
                strncpy(shortText, menuItems[idx].subtitle, 9);
                shortText[9] = '.';
                shortText[10] = '\0';
                tft.print(shortText);
            } else {
                tft.print(menuItems[idx].subtitle);
            }
            
            // 권한 필요 표시
            if (menuItems[idx].requiresAuth && !hasAccess) {
                tft.fillCircle(x + cardW - 12, y + 12, 6, COLOR_WARNING);
                tft.setTextSize(1);
                tft.setTextColor(COLOR_BG_DARK);
                tft.setCursor(x + cardW - 14, y + 9);
                tft.print("!");
            }
        }
    }
    
    // ── 유지보수 완료 버튼 (필요시) ──
    #ifdef ENABLE_PREDICTIVE_MAINTENANCE
    MaintenanceLevel level = healthMonitor.getMaintenanceLevel();
    if (level >= MAINTENANCE_REQUIRED && !systemController.isOperatorMode()) {
        int16_t btnY = startY + 4 * (cardH + SPACING_SM);
        
        ButtonConfig maintBtn = {
            .x = SPACING_SM,
            .y = btnY,
            .w = (int16_t)(SCREEN_WIDTH - SPACING_SM * 2),
            .h = 32,
            .label = "유지보수 완료",
            .style = BTN_SUCCESS,
            .enabled = true
        };
        drawButton(maintBtn);
    }
    #endif
    
    // ── 하단 네비게이션 ──
    NavButton navButtons[] = {
        {"뒤로", BTN_OUTLINE, true}
    };
    drawNavBar(navButtons, 1);
}

// ================================================================
// 설정 화면 터치 처리
// ================================================================
void handleSettingsTouch(uint16_t x, uint16_t y) {
    // ── 하단 네비게이션 ──
    int16_t navY = SCREEN_HEIGHT - FOOTER_HEIGHT;
    
    if (y >= navY) {
        // 뒤로 버튼
        ButtonConfig backBtn = {
            .x = SPACING_SM,
            .y = (int16_t)(navY + 2),
            .w = (int16_t)(SCREEN_WIDTH - SPACING_SM * 2),
            .h = (int16_t)(FOOTER_HEIGHT - 4),
            .label = "뒤로",
            .style = BTN_OUTLINE,
            .enabled = true
        };
        
        if (isButtonPressed(backBtn, x, y)) {
            currentScreen = SCREEN_MAIN;
            screenNeedsRedraw = true;
            return;
        }
    }
    
    // ── 메뉴 그리드 터치 ──
    int16_t startY = HEADER_HEIGHT + SPACING_SM;
    int16_t cardW = (SCREEN_WIDTH - SPACING_SM * 4) / 3;
    int16_t cardH = 60;
    
    // 메뉴 매핑 (drawSettingsScreen과 동일한 순서)
    ScreenType screens[] = {
        SCREEN_TIMING_SETUP, SCREEN_PID_SETUP, SCREEN_STATISTICS,
        SCREEN_TREND_GRAPH, SCREEN_CALIBRATION, SCREEN_ABOUT,
        SCREEN_HELP, SCREEN_STATE_DIAGRAM, SCREEN_SETTINGS, // 언어는 특별 처리
        #ifdef ENABLE_PREDICTIVE_MAINTENANCE
        SCREEN_HEALTH,
        #else
        SCREEN_MAIN,
        #endif
        #ifdef ENABLE_SMART_ALERTS
        SCREEN_SMART_ALERT_CONFIG,
        #else
        SCREEN_MAIN,
        #endif
        #ifdef ENABLE_VOICE_ALERTS
        SCREEN_VOICE_SETTINGS
        #else
        SCREEN_MAIN
        #endif
    };
    
    bool requiresAuth[] = {
        false, false, false,  // 타이밍, PID, 통계
        false, true, false,   // 추세, 캘리브레이션, 정보
        false, false, false,  // 도움말, 상태도, 언어
        true, true, true      // 건강도, 알림, 음성
    };
    
    // ✅ FIX #5: 배열 크기 동적 계산 (터치 처리도 동일하게)
    const int SCREEN_COUNT = sizeof(screens) / sizeof(screens[0]);
    
    for (int row = 0; row < 4; row++) {
        for (int col = 0; col < 3; col++) {
            int idx = row * 3 + col;
            if (idx >= SCREEN_COUNT) break;
            
            int16_t cardX = SPACING_SM + col * (cardW + SPACING_SM);
            int16_t cardY = startY + row * (cardH + SPACING_SM);
            
            if (x >= cardX && x <= cardX + cardW &&
                y >= cardY && y <= cardY + cardH) {
                
                // 언어 전환 (특별 처리)
                if (idx == 8) {
                    currentLang = (currentLang == LANG_EN) ? LANG_KO : LANG_EN;
                    config.language = (uint8_t)currentLang;
                    
                    #ifdef ENABLE_VOICE_ALERTS
                    if (voiceAlert.isOnline()) {
                        Language voiceLang = (currentLang == LANG_KO) 
                                            ? LANGUAGE_KOREAN 
                                            : LANGUAGE_ENGLISH;
                        voiceAlert.setLanguage(voiceLang);
                        voiceAlert.playSystem(VOICE_READY);
                    }
                    #endif
                    
                    saveConfig();
                    screenNeedsRedraw = true;
                    return;
                }
                
                // 권한 확인
                if (requiresAuth[idx] && !canAccessScreen(screens[idx])) {
                    const char* screenNames[] = {
                        "타이밍", "PID", "통계",
                        "추세", "캘리브레이션", "정보",
                        "도움말", "상태도", "언어",
                        "건강도", "알림", "음성"
                    };
                    showAccessDenied(screenNames[idx]);
                    screenNeedsRedraw = true;
                    return;
                }
                
                // 화면 전환
                currentScreen = screens[idx];
                screenNeedsRedraw = true;
                return;
            }
        }
    }
    
    // ── 유지보수 완료 버튼 터치 ──
    #ifdef ENABLE_PREDICTIVE_MAINTENANCE
    MaintenanceLevel level = healthMonitor.getMaintenanceLevel();
    if (level >= MAINTENANCE_REQUIRED && !systemController.isOperatorMode()) {
        int16_t btnY = startY + 4 * (cardH + SPACING_SM);
        
        ButtonConfig maintBtn = {
            .x = SPACING_SM,
            .y = btnY,
            .w = (int16_t)(SCREEN_WIDTH - SPACING_SM * 2),
            .h = 32,
            .label = "유지보수 완료",
            .style = BTN_SUCCESS,
            .enabled = true
        };
        
        if (isButtonPressed(maintBtn, x, y)) {
            healthMonitor.performMaintenance();
            screenNeedsRedraw = true;
            
            #ifdef ENABLE_VOICE_ALERTS
            if (voiceAlert.isOnline()) {
                voiceAlert.playSystem(VOICE_READY);
            }
            #endif
        }
    }
    #endif
}
