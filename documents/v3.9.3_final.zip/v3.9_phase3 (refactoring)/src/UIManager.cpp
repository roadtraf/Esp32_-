// ================================================================
// UIManager.cpp - UI 관리 구현
// ESP32-S3 v3.9.2 Phase 3-1 - Step 6
// ================================================================
#include "UIManager.h"
#include "../include/UI_Screens.h"

// 전역 인스턴스
UIManager uiManager;

// 외부 참조
extern LGFX tft;
extern LGFX_Sprite ts;
extern ScreenType currentScreen;
extern bool screenNeedsRedraw;

// ================================================================
// 초기화
// ================================================================
void UIManager::begin() {
    Serial.println("[UIMgr] 초기화 시작...");
    
    currentScreen = SCREEN_MAIN;
    previousScreen = SCREEN_MAIN;
    needsRedraw = true;
    lastUpdate = 0;
    
    messageActive = false;
    messageDuration = 0;
    
    popupActive = false;
    popupTargetFloat = nullptr;
    popupTargetU32 = nullptr;
    
    brightness = 255;
    sleepMode = false;
    savedBrightness = 255;
    
    Serial.println("[UIMgr] ✅ 초기화 완료");
}

void UIManager::update() {
    uint32_t now = millis();
    
    // 화면 업데이트 (200ms마다)
    if (now - lastUpdate >= 200) {
        lastUpdate = now;
        
        if (needsRedraw) {
            drawCurrentScreen();
            needsRedraw = false;
        }
    }
    
    // 메시지 자동 숨김
    if (messageActive && (now - messageStartTime >= messageDuration)) {
        hideMessage();
    }
}

// ================================================================
// 화면 관리
// ================================================================
void UIManager::setScreen(ScreenType screen) {
    if (currentScreen == screen) return;
    
    previousScreen = currentScreen;
    currentScreen = screen;
    ::currentScreen = screen;  // 전역 변수 업데이트
    
    needsRedraw = true;
    
    Serial.printf("[UIMgr] 화면 전환: %d -> %d\n", previousScreen, currentScreen);
}

void UIManager::redrawScreen() {
    needsRedraw = true;
}

void UIManager::drawCurrentScreen() {
    // 실제 화면 그리기는 기존 UI_Screens.cpp 함수 호출
    switch (currentScreen) {
        case SCREEN_MAIN:
            drawMainScreen();
            break;
        case SCREEN_SETTINGS:
            drawSettingsScreen();
            break;
        case SCREEN_GRAPH:
            drawGraphScreen();
            break;
        // ... 기타 화면들
        default:
            Serial.printf("[UIMgr] ⚠️  알 수 없는 화면: %d\n", currentScreen);
            break;
    }
}

// ================================================================
// 터치 처리
// ================================================================
void UIManager::handleTouch() {
    // 팝업이 활성화되어 있으면 팝업 터치 처리
    if (popupActive) {
        // 터치 좌표 가져오기
        extern void getTouch(uint16_t* x, uint16_t* y);
        uint16_t x, y;
        getTouch(&x, &y);
        
        if (x != 0 || y != 0) {
            handlePopupTouch(x, y);
        }
        return;
    }
    
    // 일반 터치 처리는 기존 함수 호출
    extern void handleTouch();
    ::handleTouch();
}

void UIManager::handlePopupTouch(uint16_t x, uint16_t y) {
    // 팝업 터치 처리 로직
    // (기존 handlePopupTouch 함수 내용)
}

// ================================================================
// 메시지 표시
// ================================================================
void UIManager::showMessage(const char* message, uint32_t duration) {
    strncpy(messageText, message, sizeof(messageText) - 1);
    messageText[sizeof(messageText) - 1] = '\0';
    
    messageActive = true;
    messageStartTime = millis();
    messageDuration = duration;
    
    // 화면에 메시지 그리기
    tft.fillRect(0, SCREEN_HEIGHT - 40, SCREEN_WIDTH, 40, TFT_BLACK);
    tft.setTextSize(2);
    tft.setTextColor(TFT_WHITE);
    tft.setCursor(10, SCREEN_HEIGHT - 30);
    tft.print(message);
}

void UIManager::showToast(const char* message, uint16_t color) {
    tft.fillRect(0, SCREEN_HEIGHT / 2 - 20, SCREEN_WIDTH, 40, color);
    tft.setTextSize(2);
    tft.setTextColor(TFT_WHITE);
    
    // 텍스트 중앙 정렬
    int16_t textWidth = strlen(message) * 12;  // 대략적인 계산
    int16_t x = (SCREEN_WIDTH - textWidth) / 2;
    
    tft.setCursor(x, SCREEN_HEIGHT / 2 - 10);
    tft.print(message);
    
    messageActive = true;
    messageStartTime = millis();
    messageDuration = 2000;
}

void UIManager::hideMessage() {
    if (!messageActive) return;
    
    messageActive = false;
    
    // 메시지 영역 지우기
    tft.fillRect(0, SCREEN_HEIGHT - 40, SCREEN_WIDTH, 40, TFT_BLACK);
    needsRedraw = true;
}

// ================================================================
// 팝업 관리
// ================================================================
void UIManager::showPopup(const char* label, float* target, float min, 
                          float max, float step, uint8_t decimals) {
    strncpy(popupLabel, label, sizeof(popupLabel) - 1);
    popupLabel[sizeof(popupLabel) - 1] = '\0';
    
    popupValue = *target;
    popupMin = min;
    popupMax = max;
    popupStep = step;
    popupDecimals = decimals;
    popupTargetFloat = target;
    popupTargetU32 = nullptr;
    
    popupActive = true;
    
    // 팝업 그리기
    extern void drawPopup();
    drawPopup();
}

void UIManager::showPopupU32(const char* label, uint32_t* target, 
                             uint32_t min, uint32_t max, uint32_t step) {
    strncpy(popupLabel, label, sizeof(popupLabel) - 1);
    popupLabel[sizeof(popupLabel) - 1] = '\0';
    
    popupValue = (float)*target;
    popupMin = (float)min;
    popupMax = (float)max;
    popupStep = (float)step;
    popupDecimals = 0;
    popupTargetFloat = nullptr;
    popupTargetU32 = target;
    
    popupActive = true;
    
    // 팝업 그리기
    extern void drawPopup();
    drawPopup();
}

void UIManager::hidePopup() {
    popupActive = false;
    needsRedraw = true;
}

// ================================================================
// 백라이트 제어
// ================================================================
void UIManager::setBrightness(uint8_t level) {
    brightness = constrain(level, 0, 255);
    updateBrightness();
    
    Serial.printf("[UIMgr] 밝기: %d\n", brightness);
}

void UIManager::updateBrightness() {
    // 실제 백라이트 제어
    ledcWrite(1, brightness);  // PWM 채널 1
}

// ================================================================
// 절전 모드
// ================================================================
void UIManager::enterSleepMode() {
    if (sleepMode) return;
    
    sleepMode = true;
    savedBrightness = brightness;
    
    setBrightness(0);
    
    Serial.println("[UIMgr] 절전 모드 진입");
}

void UIManager::exitSleepMode() {
    if (!sleepMode) return;
    
    sleepMode = false;
    setBrightness(savedBrightness);
    
    needsRedraw = true;
    
    Serial.println("[UIMgr] 절전 모드 해제");
}

// ================================================================
// 상태 출력
// ================================================================
void UIManager::printStatus() {
    Serial.println("\n╔═══════════════════════════════════════╗");
    Serial.println("║       UI 상태                         ║");
    Serial.println("╠═══════════════════════════════════════╣");
    Serial.printf("║ 현재 화면: %d                         ║\n", currentScreen);
    Serial.printf("║ 재그리기 필요: %s                     ║\n", 
                  needsRedraw ? "예" : "아니오");
    Serial.println("╠═══════════════════════════════════════╣");
    Serial.printf("║ 메시지: %s                            ║\n",
                  messageActive ? "표시 중" : "없음");
    Serial.printf("║ 팝업: %s                              ║\n",
                  popupActive ? "활성화" : "비활성화");
    Serial.println("╠═══════════════════════════════════════╣");
    Serial.printf("║ 밝기: %d                              ║\n", brightness);
    Serial.printf("║ 절전 모드: %s                         ║\n",
                  sleepMode ? "활성화" : "비활성화");
    Serial.println("╚═══════════════════════════════════════╝\n");
}
