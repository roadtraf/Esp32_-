// ================================================================
// UI_Screen_Alarm.cpp - 재설계 알람 화면
// ================================================================
#include "../include/UIComponents.h"
#include "../include/Config.h"

using namespace UIComponents;
using namespace UITheme;

void drawAlarmScreen() {
    tft.fillScreen(COLOR_BG_DARK);
    
    // ── 헤더 ──
    drawHeader("알람");
    
    // ── 현재 에러 상태 ──
    int16_t startY = HEADER_HEIGHT + SPACING_SM;
    
    CardConfig currentCard = {
        .x = SPACING_SM,
        .y = startY,
        .w = (int16_t)(SCREEN_WIDTH - SPACING_SM * 2),
        .h = 70,
        .bgColor = errorActive ? COLOR_DANGER : COLOR_SUCCESS,
        .elevated = true
    };
    drawCard(currentCard);
    
    if (errorActive) {
        drawIconWarning(currentCard.x + CARD_PADDING, currentCard.y + 15, COLOR_TEXT_PRIMARY);
        
        tft.setTextSize(TEXT_SIZE_MEDIUM);
        tft.setTextColor(COLOR_TEXT_PRIMARY);
        tft.setCursor(currentCard.x + CARD_PADDING + 25, currentCard.y + CARD_PADDING);
        tft.print("에러 발생!");
        
        tft.setTextSize(TEXT_SIZE_SMALL);
        tft.setCursor(currentCard.x + CARD_PADDING + 25, currentCard.y + CARD_PADDING + 22);
        tft.print(currentError.message);
        
        // 클리어 버튼
        tft.fillRoundRect(currentCard.x + currentCard.w - 80, currentCard.y + CARD_PADDING + 10,
                          70, 28, BUTTON_RADIUS, COLOR_TEXT_PRIMARY);
        tft.setTextSize(TEXT_SIZE_SMALL);
        tft.setTextColor(COLOR_DANGER);
        tft.setCursor(currentCard.x + currentCard.w - 65, currentCard.y + CARD_PADDING + 20);
        tft.print("클리어");
    } else {
        drawIconCheck(currentCard.x + CARD_PADDING, currentCard.y + 15, COLOR_TEXT_PRIMARY);
        
        tft.setTextSize(TEXT_SIZE_MEDIUM);
        tft.setTextColor(COLOR_TEXT_PRIMARY);
        tft.setCursor(currentCard.x + CARD_PADDING + 25, currentCard.y + CARD_PADDING);
        tft.print("정상 작동 중");
        
        tft.setTextSize(TEXT_SIZE_SMALL);
        tft.setCursor(currentCard.x + CARD_PADDING + 25, currentCard.y + CARD_PADDING + 22);
        tft.print("시스템에 문제가 없습니다");
    }
    
    // ── 에러 이력 ──
    int16_t histY = currentCard.y + currentCard.h + SPACING_SM;
    
    tft.setTextSize(TEXT_SIZE_SMALL);
    tft.setTextColor(COLOR_TEXT_SECONDARY);
    tft.setCursor(SPACING_SM, histY);
    tft.printf("에러 이력 (%u개)", errorHistCnt);
    
    // 이력 목록
    int16_t listY = histY + 20;
    int16_t itemH = 42;
    
    uint8_t displayCount = (errorHistCnt < 4) ? errorHistCnt : 4;
    
    for (uint8_t i = 0; i < displayCount; i++) {
        int16_t y = listY + i * (itemH + 4);
        
        ErrorInfo* err = &errorHistory[(errorHistIdx - 1 - i + ERROR_HIST_MAX) % ERROR_HIST_MAX];
        
        CardConfig histCard = {
            .x = SPACING_SM,
            .y = y,
            .w = (int16_t)(SCREEN_WIDTH - SPACING_SM * 2),
            .h = itemH,
            .bgColor = COLOR_BG_CARD
        };
        drawCard(histCard);
        
        // 에러 코드
        tft.setTextSize(TEXT_SIZE_SMALL);
        uint16_t errColor;
        switch (err->severity) {
            case SEVERITY_CRITICAL: errColor = COLOR_DANGER; break;
            case SEVERITY_RECOVERABLE: errColor = COLOR_WARNING; break;
            default: errColor = COLOR_INFO;
        }
        
        tft.setTextColor(errColor);
        tft.setCursor(histCard.x + CARD_PADDING, histCard.y + CARD_PADDING);
        tft.printf("E%03d", err->code);
        
        // 에러 메시지
        tft.setTextSize(1);
        tft.setTextColor(COLOR_TEXT_PRIMARY);
        tft.setCursor(histCard.x + CARD_PADDING + 40, histCard.y + CARD_PADDING);
        
        if (strlen(err->message) > 20) {
            char shortMsg[21];
            strncpy(shortMsg, err->message, 18);
            shortMsg[18] = '.';
            shortMsg[19] = '.';
            shortMsg[20] = '\0';
            tft.print(shortMsg);
        } else {
            tft.print(err->message);
        }
        
        // 타임스탬프
        tft.setTextColor(COLOR_TEXT_SECONDARY);
        tft.setCursor(histCard.x + CARD_PADDING + 40, histCard.y + CARD_PADDING + 16);
        
        uint32_t elapsed = (millis() - err->timestamp) / 1000;
        if (elapsed < 60) {
            tft.printf("%lu초 전", elapsed);
        } else if (elapsed < 3600) {
            tft.printf("%lu분 전", elapsed / 60);
        } else {
            tft.printf("%lu시간 전", elapsed / 3600);
        }
    }
    
    if (errorHistCnt == 0) {
        tft.setTextSize(TEXT_SIZE_SMALL);
        tft.setTextColor(COLOR_TEXT_SECONDARY);
        int16_t msgX = (SCREEN_WIDTH - strlen("에러 이력 없음") * 6) / 2;
        tft.setCursor(msgX, listY + 60);
        tft.print("에러 이력 없음");
    }
    
    // ── 하단 네비게이션 ──
    NavButton navButtons[] = {
        {"뒤로", BTN_OUTLINE, true},
        {"전체 삭제", BTN_DANGER, systemController.getPermissions().canChangeSettings && errorHistCnt > 0}
    };
    
    int navCount = systemController.getPermissions().canChangeSettings && errorHistCnt > 0 ? 2 : 1;
    drawNavBar(navButtons, navCount);
}

void handleAlarmTouch(uint16_t x, uint16_t y) {
    int16_t startY = HEADER_HEIGHT + SPACING_SM;
    int16_t navY = SCREEN_HEIGHT - FOOTER_HEIGHT;
    
    // 클리어 버튼 (에러 활성 시)
    if (errorActive) {
        if (x >= SCREEN_WIDTH - SPACING_SM - 80 && 
            x <= SCREEN_WIDTH - SPACING_SM - 10 &&
            y >= startY + CARD_PADDING + 10 && 
            y <= startY + CARD_PADDING + 38) {
            clearError();
            screenNeedsRedraw = true;
            return;
        }
    }
    
    // 네비게이션
    if (y >= navY) {
        int16_t buttonW = (SCREEN_WIDTH - SPACING_SM * 3) / 2;
        
        // 뒤로
        ButtonConfig backBtn = {
            .x = SPACING_SM,
            .y = (int16_t)(navY + 2),
            .w = buttonW,
            .h = (int16_t)(FOOTER_HEIGHT - 4),
            .label = "뒤로",
            .style = BTN_OUTLINE,
            .enabled = true
        };
        
        if (isButtonPressed(backBtn, x, y)) {
            currentScreen = SCREEN_SETTINGS;
            screenNeedsRedraw = true;
            return;
        }
        
        // 전체 삭제
        if (systemController.getPermissions().canChangeSettings && errorHistCnt > 0) {
            ButtonConfig clearAllBtn = {
                .x = (int16_t)(SPACING_SM + buttonW + SPACING_SM),
                .y = (int16_t)(navY + 2),
                .w = buttonW,
                .h = (int16_t)(FOOTER_HEIGHT - 4),
                .label = "전체 삭제",
                .style = BTN_DANGER,
                .enabled = true
            };
            
            if (isButtonPressed(clearAllBtn, x, y)) {
                errorHistCnt = 0;
                errorHistIdx = 0;
                screenNeedsRedraw = true;
                return;
            }
        }
    }
}
