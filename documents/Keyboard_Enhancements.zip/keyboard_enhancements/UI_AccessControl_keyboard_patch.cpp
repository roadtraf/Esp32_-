// ================================================================
// UI_AccessControl.cpp — PIN 화면 키보드 입력 추가
// 
// 추가 기능:
// - handleKeyboardOnPinScreen() 함수로 키보드 입력 지원
// - 숫자 0~9: PIN 입력
// - Enter/확인: PIN 검증
// - Backspace/Delete: 한 자 지우기
// - ESC: 취소
// ================================================================

// ──────────────────────────────────────────────────────────────
// 기존 UI_AccessControl.cpp의 313라인 끝에 추가
// ──────────────────────────────────────────────────────────────

// ================================================================
// 키보드 입력 처리 (PIN 화면 전용)
// ================================================================
void handleKeyboardOnPinScreen(uint8_t key) {
    if (!g_pinActive) return;

    // 잠금 상태 체크
    if (g_locked) {
        if (millis() >= g_lockEndMs) {
            g_locked = false;
            drawPinInputScreen();
        }
        return;
    }

    // 숫자 입력 (0~9)
    if (key >= '0' && key <= '9') {
        if (g_pinLen < PIN_MAX_DIGITS) {
            g_pinInput[g_pinLen++] = key;
            g_pinInput[g_pinLen] = '\0';
            drawPinInputScreen();
            Serial.printf("[PIN] 키보드 입력: %c (길이: %d)\n", key, g_pinLen);
        }
        return;
    }

    // Enter (확인) — OK 버튼과 동일
    if (key == '\r' || key == '\n') {
        Serial.println("[PIN] 키보드 Enter — PIN 검증");

        // PIN 검증
        bool ok = false;
        if (g_targetMode == SystemMode::MANAGER) {
            ok = systemController.enterManagerMode(g_pinInput);
        } else {
            ok = systemController.enterDeveloperMode(g_pinInput);
        }

        g_pinLen = 0;
        memset(g_pinInput, 0, sizeof(g_pinInput));
        g_pinActive = false;

        if (ok) {
            uiManager.showToast(
                (g_targetMode == SystemMode::MANAGER)
                    ? "관리자 모드" : "개발자 모드",
                COLOR_MANAGER);
        } else {
            // 잠금 여부 확인
            if (systemController.isLockedOut()) {
                g_locked    = true;
                g_lockEndMs = millis() + systemController.getLockoutRemainingTime();
                drawPinInputScreen();
                return;
            }
            uiManager.showToast("PIN 오류", COLOR_DANGER);
        }

        if (g_callback) g_callback(ok, g_targetMode);
        uiManager.requestRedraw();
        return;
    }

    // Backspace / Delete (지우기) — ← 버튼과 동일
    if (key == 0x08 || key == 0x7F) {
        if (g_pinLen > 0) {
            g_pinLen--;
            g_pinInput[g_pinLen] = '\0';
            drawPinInputScreen();
            Serial.printf("[PIN] 키보드 Backspace (길이: %d)\n", g_pinLen);
        }
        return;
    }

    // ESC (취소) — 취소 버튼과 동일
    if (key == 0x1B) {
        Serial.println("[PIN] 키보드 ESC — 취소");
        g_pinActive = false;
        g_pinLen    = 0;
        memset(g_pinInput, 0, sizeof(g_pinInput));
        if (g_callback) g_callback(false, g_targetMode);
        uiManager.requestRedraw();
        return;
    }
}
