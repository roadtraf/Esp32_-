// ================================================================
// UI_Screen_Help.cpp — 키보드 단축키 페이지 추가
// 
// 수정사항:
// 1. 페이지 수: "페이지 %d / 4" → "페이지 %d / 5"
// 2. case 4 추가: 키보드 단축키 안내
// 3. 네비게이션: helpPageIndex < 3 → helpPageIndex < 4
// ================================================================

// ──────────────────────────────────────────────────────────────
// 수정 1: 25라인 — 페이지 수 변경
// ──────────────────────────────────────────────────────────────
// 기존:
//     tft.printf("페이지 %d / 4", helpPageIndex + 1);
//
// 수정 후:
    tft.printf("페이지 %d / 5", helpPageIndex + 1);

// ──────────────────────────────────────────────────────────────
// 수정 2: 147라인 끝 (case 3 다음) — case 4 추가
// ──────────────────────────────────────────────────────────────
// case 3의 break; 다음에 아래 코드 추가:

        case 4: // 키보드 단축키
            tft.setTextColor(COLOR_ACCENT);
            tft.setCursor(contentCard.x + CARD_PADDING, textY);
            tft.print("키보드 단축키");
            
            tft.setTextColor(COLOR_TEXT_SECONDARY);
            textY += lineH + 4;
            tft.setCursor(contentCard.x + CARD_PADDING, textY);
            tft.print("USB 키보드 연결 시 사용 가능");
            textY += lineH + 4;
            
            // 좌측 컬럼
            tft.setTextColor(COLOR_TEXT_PRIMARY);
            int16_t col1X = contentCard.x + CARD_PADDING;
            
            tft.setCursor(col1X, textY);
            tft.print("0: 메인 화면");
            textY += lineH;
            
            tft.setCursor(col1X, textY);
            tft.print("1: 시작");
            textY += lineH;
            
            tft.setCursor(col1X, textY);
            tft.print("2: 정지");
            textY += lineH;
            
            tft.setCursor(col1X, textY);
            tft.print("3: 모드 전환");
            textY += lineH;
            
            tft.setCursor(col1X, textY);
            tft.print("4: 알람 리셋");
            textY += lineH;
            
            // 우측 컬럼
            int16_t col2X = contentCard.x + CARD_PADDING + 140;
            textY = contentCard.y + CARD_PADDING + lineH * 2 + 4;
            
            tft.setCursor(col2X, textY);
            tft.print("5: 통계");
            textY += lineH;
            
            tft.setCursor(col2X, textY);
            tft.print("*: 설정");
            textY += lineH;
            
            tft.setCursor(col2X, textY);
            tft.print("ESC: 메인");
            textY += lineH;
            
            tft.setCursor(col2X, textY);
            tft.print("←: 뒤로");
            textY += lineH;
            
            tft.setCursor(col2X, textY);
            tft.print("+/-: 페이지");
            break;

// ──────────────────────────────────────────────────────────────
// 수정 3: 195라인 — 다음 버튼 조건 변경
// ──────────────────────────────────────────────────────────────
// 기존:
//     if (helpPageIndex < 3) {
//
// 수정 후:
    if (helpPageIndex < 4) {

// ──────────────────────────────────────────────────────────────
// 수정 4: 206라인 — 버튼 개수 조건 변경
// ──────────────────────────────────────────────────────────────
// 기존:
//     int buttonCount = (helpPageIndex > 0 && helpPageIndex < 3) ? 2 : 1;
//
// 수정 후:
    int buttonCount = (helpPageIndex > 0 && helpPageIndex < 4) ? 2 : 1;
