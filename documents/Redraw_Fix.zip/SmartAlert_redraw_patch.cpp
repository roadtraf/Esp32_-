// ================================================================
// SmartAlert.cpp — sendDisplayAlert() 수정본
//
// [R3] 문제: sendDisplayAlert()가 현재 어떤 화면이든 무조건
//            screenNeedsRedraw = true 설정
//            → 그래프 화면, PID 화면 등 관계없는 화면에서도
//              전체 화면 재그리기 발생
//
// 수정: 현재 화면이 SCREEN_HEALTH 또는 SCREEN_MAIN일 때만 트리거
//       그 외 화면은 다음번 해당 화면 진입 시 자연스럽게 반영됨
// ================================================================

// ── SmartAlert.cpp 내 sendDisplayAlert() 함수 교체본 ──

void SmartAlert::sendDisplayAlert(MaintenanceLevel level,
                                   float healthScore,
                                   const char* message) {
    // 실제 팝업은 UI_Screen_Health.cpp의 showMaintenanceAlert()에서 처리
    // [R3] 현재 보고 있는 화면이 관련 있을 때만 redraw 트리거
    if (currentScreen == SCREEN_HEALTH ||
        currentScreen == SCREEN_MAIN) {
        screenNeedsRedraw = true;
    }
    // 그 외 화면: 화면 전환 시 최신값 자동 반영되므로 즉시 redraw 불필요
}
