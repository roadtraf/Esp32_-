// ================================================================
// Tasks.cpp — uiUpdateStep() / sensorReadStep() 수정본 (v2)
// 
// [R1] 메인화면 센서값 무갱신 버그 수정
// [R2] E-Stop 화면 150ms 강제 redraw → 1초 단위로 변경
// 
// v2 수정사항:
// - sensorData.state → currentState (전역 변수)
// - g_estopStartMs extern 선언 추가
// ================================================================

// ================================================================
// Tasks.cpp 상단에 추가할 내용 (extern 선언 섹션)
// ================================================================
// 기존 extern 섹션(33~67라인) 끝에 아래 추가:

extern uint32_t g_estopStartMs;  // UI_Screen_EStop.cpp에서 정의

// ================================================================
// 센서 변화 감지용 구조체 [R1]
// Tasks.cpp 상단 (static 선언 섹션)에 추가
// ================================================================
struct SensorSnapshot {
    float pressure    = 9999.0f;
    float temperature = 9999.0f;
    float current     = 9999.0f;
    SystemState state = STATE_IDLE;
    bool  errorActive = false;
};

// 변화 임계치
static constexpr float PRESSURE_DELTA  = 0.2f;   // kPa
static constexpr float TEMP_DELTA      = 0.3f;   // °C
static constexpr float CURRENT_DELTA   = 0.05f;  // A

// 이전 센서값 저장
static SensorSnapshot g_lastSensor;

// ================================================================
// [R1] sensorReadStep() 교체본
// 기존 105~117라인을 아래 내용으로 교체
// ================================================================
static void sensorReadStep() {
    readSensors();
    updateSensorBuffers();
    checkSensorHealth();

    // [9] DS18B20 비동기 온도 반영
    if (safeDS18B20.isPresent()) {
        sensorData.temperature = safeDS18B20.getTemperature();
    }

    // [R1] 메인화면 센서값 변화 감지
    if (currentScreen == SCREEN_MAIN) {
        bool changed =
            fabsf(sensorData.pressure    - g_lastSensor.pressure)    > PRESSURE_DELTA  ||
            fabsf(sensorData.temperature - g_lastSensor.temperature) > TEMP_DELTA      ||
            fabsf(sensorData.current     - g_lastSensor.current)     > CURRENT_DELTA   ||
            currentState != g_lastSensor.state ||                     // ← 수정: sensorData.state → currentState
            errorActive  != g_lastSensor.errorActive;

        if (changed) {
            g_lastSensor.pressure    = sensorData.pressure;
            g_lastSensor.temperature = sensorData.temperature;
            g_lastSensor.current     = sensorData.current;
            g_lastSensor.state       = currentState;              // ← 수정
            g_lastSensor.errorActive = errorActive;
            screenNeedsRedraw        = true;
        }
    }

    WDT_CHECKIN("SensorRead");
}

// ================================================================
// [R2] uiUpdateStep() 교체본
// 기존 121~161라인을 아래 내용으로 교체
// ================================================================
static void uiUpdateStep() {
    static uint32_t lastUpdate   = 0;
    static uint8_t  lastEstopSec = 0xFF;   // E-Stop 초 변화 감지

    uint32_t now = millis();

    // [8] 터치: SPI 뮤텍스 획득 후 접근
    {
        SPIGuard touchGuard(SPI_DEV_TOUCH, SPI_MUTEX_TIMEOUT_MS);
        if (touchGuard.acquired()) {
            handleTouch();
        }
    }

    if (keyboardConnected) {
        handleKeyboardInput();
    }

    // [8] TFT 업데이트: SPI 뮤텍스 획득 후 접근
    if (now - lastUpdate >= 200) {
        lastUpdate = now;

        // [R2] E-Stop 깜빡임: 1초 단위로만 redraw
        if (currentScreen == SCREEN_ESTOP) {
            uint8_t currentSec = (uint8_t)((millis() - g_estopStartMs) / 1000);
            if (currentSec != lastEstopSec) {
                lastEstopSec = currentSec;
                screenNeedsRedraw = true;
            }
        }

        if (screenNeedsRedraw) {
            SPIGuard tftGuard(SPI_DEV_TFT, SPI_MUTEX_TIMEOUT_MS);
            if (tftGuard.acquired()) {
                WDT_FEED();
                updateUI();
                screenNeedsRedraw = false;
            } else {
                Serial.println("[UITask] SPI 뮤텍스 대기 중, UI 업데이트 지연");
            }
        }
    }

    if (!sleepMode && (now - lastIdleTime > IDLE_TIMEOUT)) {
        if (currentState == STATE_IDLE) {
            enterSleepMode();
        }
    }

    WDT_CHECKIN("UIUpdate");
}
