# 불필요한 UI Redraw 분석 및 수정 가이드

## 발견된 문제 요약

분석 결과 **4가지 독립적인 불필요 redraw 문제**가 발견됐습니다.

---

## [R1] 메인화면 센서값 무갱신 버그 ★★★ 가장 중요

**파일**: `Tasks.cpp` — `sensorReadStep()`

**문제**:
```
sensorReadStep()  →  readSensors() 완료
                  →  screenNeedsRedraw = true  ← 이 코드가 없음!
```
센서값이 바뀌어도 `screenNeedsRedraw`를 세우는 곳이 없습니다.  
메인화면의 압력/온도 숫자는 **상태 전이(StateMachine)가 일어날 때만** 갱신됩니다.  
즉, 진공 운전 중 STATE_VACUUM_ON 상태가 유지되는 동안은 센서값이 아무리 바뀌어도 화면이 멈춰 있습니다.

**수정**: 센서값 변화량이 임계치를 초과할 때만 `screenNeedsRedraw = true`

```cpp
// sensorReadStep() 끝에 추가
if (currentScreen == SCREEN_MAIN) {
    bool changed =
        fabsf(sensorData.pressure    - g_lastSensor.pressure)    > 0.2f ||
        fabsf(sensorData.temperature - g_lastSensor.temperature)  > 0.3f ||
        fabsf(sensorData.current     - g_lastSensor.current)      > 0.05f ||
        errorActive != g_lastSensor.errorActive;
    if (changed) {
        g_lastSensor = { sensorData.pressure, sensorData.temperature,
                         sensorData.current, errorActive };
        screenNeedsRedraw = true;
    }
}
```

**효과**: 센서값 변화가 없을 때 redraw 0회. 변화 있을 때만 정확히 트리거.

---

## [R2] E-Stop 화면 매 150ms 전체 fillScreen 강제 redraw ★★

**파일**: 새 `UIManager.cpp` — `update()` 내

**문제**:
```cpp
// UIManager.cpp (개선판에 남아있는 코드)
if (currentScreen == SCREEN_ESTOP) {
    drawCurrentScreen();   // ← needsRedraw와 무관하게 무조건 호출
}
```
E-Stop 화면의 1초 경과 타이머 깜빡임을 위해 150ms마다 `drawEStopScreen()` 호출.  
`drawEStopScreen()` 내부에는 `tft.fillScreen(COLOR_BG_DARK)` + 전체 화면 재그리기가 있습니다.

**비용**:
- ILI9488 480×320, SPI 40MHz: fillScreen ≈ 15~30ms
- 150ms 주기 → SPI 버스 점유율 **~13~20%** 상시 낭비
- SD 카드 쓰기, 터치 응답 지연 발생

**수정**: 초(秒)가 바뀔 때만 `screenNeedsRedraw = true` 설정

```cpp
// uiUpdateStep() 내 수정
if (currentScreen == SCREEN_ESTOP) {
    uint8_t currentSec = (uint8_t)((millis() - g_estopStartMs) / 1000);
    if (currentSec != lastEstopSec) {
        lastEstopSec = currentSec;
        screenNeedsRedraw = true;   // 1초에 한 번만
    }
}
// drawCurrentScreen()은 needsRedraw가 true일 때만 → 기존 if문 하나로 통합
```

**효과**: E-Stop 화면 redraw 회수 150ms→1000ms로 **6.7배 감소**.

---

## [R3] SmartAlert 화면 무관 redraw ★

**파일**: `SmartAlert.cpp` — `sendDisplayAlert()`

**문제**:
```cpp
void SmartAlert::sendDisplayAlert(...) {
    screenNeedsRedraw = true;   // 현재 화면 상관없이 무조건
}
```
건강도 경보가 발생하면 현재 PID 설정 화면, 그래프 화면, 통계 화면 어디서든 전체 화면 재그리기.  
Health 화면이 아니라면 갱신해봐야 시각적 효과도 없습니다.

**수정**: 관련 화면에서만 트리거

```cpp
void SmartAlert::sendDisplayAlert(...) {
    if (currentScreen == SCREEN_HEALTH || currentScreen == SCREEN_MAIN) {
        screenNeedsRedraw = true;
    }
    // 그 외: 해당 화면 진입 시 최신값 자동 반영
}
```

---

## [R4] UI 태스크 블로킹 vTaskDelay 팝업 7곳 ★★

**파일**: `UI_Screens.cpp` (3곳), `UI_Screen_Calibration.cpp`, `UI_Screen_Statistics.cpp`, `ManagerUI.cpp` (2곳)

**문제**: 팝업을 그린 뒤 `vTaskDelay(2000~3000ms)` 로 UI 태스크 전체 블로킹.
- 이 시간 동안 터치 무반응
- 센서값 화면 갱신 중단
- WDT feed 지연 → WDT 타임아웃 위험 (UIUpdate 태스크 WDT 시간 설정에 따라)

**수정**: `uiManager.showMessage(msg, duration)` 타이머 방식으로 교체.  
단, `showResetConfirmation()`은 버튼 선택 결과가 필요하므로 플래그 기반으로 전환.

```
기존: 그리기 → vTaskDelay(2000) → screenNeedsRedraw = true → 반환
수정: 그리기 → uiManager.showMessage("...", 2000) → 즉시 반환
               (타이머가 2초 후 자동으로 needsRedraw 설정)
```

**7곳 위치**:

| 파일 | 함수 | delay |
|---|---|---|
| `UI_Screens.cpp:152` | `showAccessDenied()` | 2000ms |
| `UI_Screens.cpp:261` | `showMaintenanceCompletePopup()` | 2000ms |
| `UI_Screens.cpp:324` | `showResetConfirmation()` | 2000ms |
| `UI_Screens.cpp:386` | `showTemperatureSensorInfo()` | 3000ms |
| `UI_Screen_Calibration.cpp:325` | 캘리브레이션 완료 | 3000ms |
| `UI_Screen_Statistics.cpp:266` | 통계 관련 | 2000ms |
| `ManagerUI.cpp:156,225` | 권한 다이얼로그 | 3000ms ×2 |

---

## 수정 후 예상 redraw 횟수 비교

| 상황 | 수정 전 | 수정 후 |
|---|---|---|
| 메인화면 정상운전 (센서 미변화) | 상태전이 때만 | 동일 (임계치 이하 무시) |
| 메인화면 정상운전 (센서 변화) | **0회** (버그) | **100ms마다** (sensorReadStep 주기) |
| E-Stop 화면 | **150ms마다** 전체 redraw | **1000ms마다** 전체 redraw |
| SmartAlert 경보 (타 화면에서) | 전체 화면 redraw | **0회** |
| 팝업 표시 중 | 2~3초 완전 멈춤 | 즉시 반환, 타이머 소멸 |

---

## 적용 방법

### Step 1 — Tasks.cpp 수정

`Tasks_redraw_patch.cpp`의 두 함수로 기존 함수 교체:
- `sensorReadStep()` 전체 교체
- `uiUpdateStep()` 전체 교체

`g_lastSensor` 전역 구조체와 `g_estopStartMs` extern 선언도 추가 필요:
```cpp
// Tasks.cpp 상단 extern 추가
extern uint32_t g_estopStartMs;  // UI_Screen_EStop.cpp에서 정의
```

### Step 2 — SmartAlert.cpp 수정

`SmartAlert_redraw_patch.cpp`의 `sendDisplayAlert()` 함수 본체로 교체.

### Step 3 — UI_Screens.cpp 수정

`UI_Screens_popup_patch.cpp`의 4개 함수로 기존 함수 교체.

`UI_Screens.h`에 새 선언 추가:
```cpp
bool handleResetConfirmTouch(uint16_t x, uint16_t y);
bool isResetConfirmPending();
```

`UI_Screen_Statistics.cpp`의 `handleStatisticsTouch()` 내:
```cpp
// 통계 초기화 팝업이 활성화되어 있으면 우선 처리
if (isResetConfirmPending()) {
    if (handleResetConfirmTouch(x, y)) return;
}
```

### Step 4 — 나머지 vTaskDelay 3곳

`UI_Screen_Calibration.cpp:325`, `UI_Screen_Statistics.cpp:266`, `ManagerUI.cpp:156,225` 에서:
```cpp
// 제거
vTaskDelay(pdMS_TO_TICKS(N));
screenNeedsRedraw = true;

// 교체
uiManager.showMessage("완료", N);   // N 밀리초
// (함수 즉시 반환)
```

---

## 전체 체크리스트

```
[R1] ✅ Tasks.cpp sensorReadStep — 변화 감지 후 redraw 트리거
[R2] ✅ UIManager.cpp uiUpdateStep — E-Stop 1초 단위로 변경
[R3] ✅ SmartAlert.cpp sendDisplayAlert — 관련 화면만 트리거
[R4] ✅ UI_Screens.cpp 팝업 4곳 — vTaskDelay 제거
[R4] □  UI_Screen_Calibration.cpp:325 — vTaskDelay 제거 (직접 수정)
[R4] □  UI_Screen_Statistics.cpp:266  — vTaskDelay 제거 (직접 수정)
[R4] □  ManagerUI.cpp:156,225         — vTaskDelay 제거 (직접 수정)
```
