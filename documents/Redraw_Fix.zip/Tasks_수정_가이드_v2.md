# Tasks.cpp Redraw Fix 적용 가이드 (수정판)

## 1단계 — extern 선언 추가

**Tasks.cpp 33~67라인 extern 섹션 끝**에 추가:

```cpp
extern uint32_t g_estopStartMs;  // UI_Screen_EStop.cpp에서 정의
```

---

## 2단계 — 센서 스냅샷 구조체 추가

**Tasks.cpp 73라인 (registerAllTasks 함수 위)**에 추가:

```cpp
// ================================================================
// [R1] 센서 변화 감지용
// ================================================================
struct SensorSnapshot {
    float pressure    = 9999.0f;
    float temperature = 9999.0f;
    float current     = 9999.0f;
    SystemState state = STATE_IDLE;
    bool  errorActive = false;
};

static constexpr float PRESSURE_DELTA  = 0.2f;   // kPa
static constexpr float TEMP_DELTA      = 0.3f;   // °C
static constexpr float CURRENT_DELTA   = 0.05f;  // A

static SensorSnapshot g_lastSensor;
```

---

## 3단계 — sensorReadStep() 본체 교체

**Tasks.cpp 105~117라인** 전체를:

```cpp
static void sensorReadStep() {
    readSensors();
    updateSensorBuffers();
    checkSensorHealth();

    // [9] DS18B20 비동기 온도 반영
    if (safeDS18B20.isPresent()) {
        sensorData.temperature = safeDS18B20.getTemperature();
    }

    // [R1] 메인화면 센서값 변화 감지
    if (currentScreen == SCREEN_MAIN) {
        bool changed =
            fabsf(sensorData.pressure    - g_lastSensor.pressure)    > PRESSURE_DELTA  ||
            fabsf(sensorData.temperature - g_lastSensor.temperature) > TEMP_DELTA      ||
            fabsf(sensorData.current     - g_lastSensor.current)     > CURRENT_DELTA   ||
            currentState != g_lastSensor.state ||
            errorActive  != g_lastSensor.errorActive;

        if (changed) {
            g_lastSensor.pressure    = sensorData.pressure;
            g_lastSensor.temperature = sensorData.temperature;
            g_lastSensor.current     = sensorData.current;
            g_lastSensor.state       = currentState;
            g_lastSensor.errorActive = errorActive;
            screenNeedsRedraw        = true;
        }
    }

    WDT_CHECKIN("SensorRead");
}
```

---

## 4단계 — uiUpdateStep() 본체 교체

**Tasks.cpp 121~161라인** 전체를:

```cpp
static void uiUpdateStep() {
    static uint32_t lastUpdate   = 0;
    static uint8_t  lastEstopSec = 0xFF;

    uint32_t now = millis();

    // [8] 터치: SPI 뮤텍스 획득 후 접근
    {
        SPIGuard touchGuard(SPI_DEV_TOUCH, SPI_MUTEX_TIMEOUT_MS);
        if (touchGuard.acquired()) {
            handleTouch();
        }
    }

    if (keyboardConnected) {
        handleKeyboardInput();
    }

    // [8] TFT 업데이트: SPI 뮤텍스 획득 후 접근
    if (now - lastUpdate >= 200) {
        lastUpdate = now;

        // [R2] E-Stop 깜빡임: 1초 단위로만 redraw
        if (currentScreen == SCREEN_ESTOP) {
            uint8_t currentSec = (uint8_t)((millis() - g_estopStartMs) / 1000);
            if (currentSec != lastEstopSec) {
                lastEstopSec = currentSec;
                screenNeedsRedraw = true;
            }
        }

        if (screenNeedsRedraw) {
            SPIGuard tftGuard(SPI_DEV_TFT, SPI_MUTEX_TIMEOUT_MS);
            if (tftGuard.acquired()) {
                WDT_FEED();
                updateUI();
                screenNeedsRedraw = false;
            } else {
                Serial.println("[UITask] SPI 뮤텍스 대기 중, UI 업데이트 지연");
            }
        }
    }

    if (!sleepMode && (now - lastIdleTime > IDLE_TIMEOUT)) {
        if (currentState == STATE_IDLE) {
            enterSleepMode();
        }
    }

    WDT_CHECKIN("UIUpdate");
}
```

---

## 수정 완료 체크리스트

```
✅ extern uint32_t g_estopStartMs; 추가 (상단)
✅ SensorSnapshot 구조체 추가 (static 섹션)
✅ sensorReadStep() 본체 교체 (105~117라인)
✅ uiUpdateStep() 본체 교체 (121~161라인)
```

---

## 주의사항

### ❌ 기존 패치 파일의 오류
```cpp
sensorData.state  // ← 존재하지 않는 필드!
```

### ✅ 수정된 코드
```cpp
currentState  // ← 전역 변수 사용
```

`SensorData` 구조체에는 `state` 필드가 없습니다.  
`currentState`는 별도의 전역 변수입니다.
