// ================================================================
// StateMachine.cpp — changeState() 함수 Mutex 추가 (완전한 교체본)
// 
// 교체 위치: 199~284라인
// 
// 변경사항:
// - [K3] Mutex 획득/해제 추가
// - 중복 진입 방지 (Mutex 보호)
// - 원본 로직 100% 유지
// ================================================================

void changeState(SystemState newState) {
  // [K3] Mutex 획득 (100ms 타임아웃)
  if (g_stateMutex == nullptr || 
      xSemaphoreTake(g_stateMutex, pdMS_TO_TICKS(100)) != pdTRUE) {
    Serial.println("[StateMachine] ⚠️  Mutex 획득 실패 — 상태 전이 건너뜀");
    return;
  }

  // 중복 진입 방지
  if (currentState == newState) {
    xSemaphoreGive(g_stateMutex);
    return;
  }

  previousState = currentState;
  currentState = newState;
  stateStartTime = millis();
  screenNeedsRedraw = true;
  
  Serial.printf("[상태 전이] %s → %s\n", 
                getStateName(previousState), 
                getStateName(currentState));
  
  // v3.9: 음성 알림 - 상태 변경 시 자동 재생
  #ifdef ENABLE_VOICE_ALERTS
  if (voiceAlert.isOnline() && voiceAlert.isAutoVoiceEnabled()) {
    voiceAlert.playStateMessage(newState);
  }
  #endif
    
  // 상태 진입 시 초기화
  if (newState == STATE_WAIT_REMOVAL) {
    holdExtensionCount = 0;
  }

  // 상태별 진입 처리
  switch (newState) {
    case STATE_IDLE:
      controlPump(0);
      controlValve(false);
      resetPID();
      break;

    case STATE_VACUUM_ON:
      controlValve(false);
      stats.totalCycles++;
      initGraphData();
      break;

    case STATE_VACUUM_HOLD:
      if (currentMode == MODE_AUTO) controlPump(config.manualPWM);
      break;

    case STATE_VACUUM_BREAK:
      controlPump(0);
      controlValve(true);
      break;

    case STATE_WAIT_REMOVAL:
      controlPump(0);
      controlValve(false);
      
      // v3.9: 박스 제거 안내 음성
      #ifdef ENABLE_VOICE_ALERTS
      if (voiceAlert.isOnline()) {
        voiceAlert.playGuide(VOICE_GUIDE_REMOVE_BOX);
      }
      #endif
      break;

    case STATE_COMPLETE:
      stats.successfulCycles++;
      logCycle(true, sensorData.pressure, sensorData.current);
      digitalWrite(PIN_BUZZER, HIGH);
      vTaskDelay(pdMS_TO_TICKS(100));
      digitalWrite(PIN_BUZZER, LOW);
      break;

    case STATE_ERROR:
      controlPump(0);
      controlValve(true);
      stats.failedCycles++;
      stats.totalErrors++;
      logCycle(false, sensorData.pressure, sensorData.current);
      digitalWrite(PIN_BUZZER, HIGH);
      vTaskDelay(pdMS_TO_TICKS(500));
      digitalWrite(PIN_BUZZER, LOW);
      break;

    case STATE_EMERGENCY_STOP:
      emergencyShutdown();
      digitalWrite(PIN_BUZZER, HIGH);
      vTaskDelay(pdMS_TO_TICKS(1000));
      digitalWrite(PIN_BUZZER, LOW);
      break;
  }

  // [K3] Mutex 해제
  xSemaphoreGive(g_stateMutex);
}
