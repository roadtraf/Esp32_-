# StateMachine.cpp Mutex 추가 — 정확한 수정 가이드

귀하의 질문에 대한 정확한 답변입니다.

---

## ❓ 질문 1: 전체를 changeState()로 대체?

### ❌ 아닙니다!

**StateMachine_mutex.cpp는 참고용 코드**이며, 전체 파일이 아닙니다.  
실제로는 **3가지 수정**이 필요합니다:

1. ✅ **Mutex 변수 추가** (파일 상단)
2. ✅ **initStateMachine() 함수 추가** (새 함수)
3. ✅ **changeState() 함수 본체만 교체** (199~284라인)

---

## ❓ 질문 2: getStateName() case가 5개인 이유?

### ❌ 제 실수입니다!

**원본은 9개 상태**를 모두 포함해야 합니다:
```cpp
STATE_IDLE            // 대기
STATE_VACUUM_ON       // 진공 동작
STATE_VACUUM_HOLD     // 진공 유지 ← 누락!
STATE_VACUUM_BREAK    // 진공 해제 ← 누락!
STATE_WAIT_REMOVAL    // 제품 제거 대기
STATE_COMPLETE        // 완료 ← 누락!
STATE_ERROR           // 에러
STATE_EMERGENCY_STOP  // 비상정지 ← 누락!
STATE_STANDBY         // 대기 ← 누락!
```

**getStateName()은 수정하지 않습니다!**  
(원본 그대로 유지)

---

## ✅ 정확한 적용 방법

### Step 1 — 파일 상단에 Mutex 변수 추가

**위치**: StateMachine.cpp 25라인 (holdExtensionCount 다음)

**추가할 코드**:
```cpp
// 자동 연장 카운터
static uint8_t holdExtensionCount = 0;

// [K3] 상태 전이 Mutex (터치/키보드 동시 입력 보호)
static SemaphoreHandle_t g_stateMutex = nullptr;
```

---

### Step 2 — initStateMachine() 함수 추가

**위치**: StateMachine.cpp 199라인 (changeState 함수 바로 위)

**추가할 코드**:
```cpp
// ================================================================
// StateMachine 초기화 — Mutex 생성
// ================================================================
void initStateMachine() {
  if (g_stateMutex == nullptr) {
    g_stateMutex = xSemaphoreCreateMutex();
    if (g_stateMutex == nullptr) {
      Serial.println("[StateMachine] ⚠️  Mutex 생성 실패!");
    } else {
      Serial.println("[StateMachine] Mutex 생성 완료");
    }
  }
}

// ================================================================
// 상태 전이 (기존 함수)
// ================================================================
```

---

### Step 3 — changeState() 함수 본체 교체

**위치**: StateMachine.cpp 199~284라인

**기존 코드** (199라인부터):
```cpp
void changeState(SystemState newState) {
  if (currentState == newState) return;

  previousState = currentState;
  currentState = newState;
  stateStartTime = millis();
  screenNeedsRedraw = true;
  
  // ... 중략 ...
}
```

**교체 코드**:
```cpp
void changeState(SystemState newState) {
  // [K3] Mutex 획득 (100ms 타임아웃)
  if (g_stateMutex == nullptr || 
      xSemaphoreTake(g_stateMutex, pdMS_TO_TICKS(100)) != pdTRUE) {
    Serial.println("[StateMachine] ⚠️  Mutex 획득 실패 — 상태 전이 건너뜀");
    return;
  }

  // 중복 진입 방지
  if (currentState == newState) {
    xSemaphoreGive(g_stateMutex);
    return;
  }

  previousState  = currentState;
  currentState   = newState;
  stateStartTime = millis();
  screenNeedsRedraw = true;
  
  Serial.printf("[상태 전이] %s → %s\n", 
                getStateName(previousState), 
                getStateName(currentState));
  
  // v3.9: 음성 알림 - 상태 변경 시 자동 재생
  #ifdef ENABLE_VOICE_ALERTS
  if (voiceAlert.isOnline() && voiceAlert.isAutoVoiceEnabled()) {
    voiceAlert.playStateMessage(newState);
  }
  #endif
    
  // 상태 진입 시 초기화
  if (newState == STATE_WAIT_REMOVAL) {
    holdExtensionCount = 0;
    // [K3] 이 부분은 원본의 나머지 코드 그대로 유지
    // ... (원본에 있는 나머지 로직)
  }

  // [K3] Mutex 해제
  xSemaphoreGive(g_stateMutex);
}
```

**⚠️ 중요**: `STATE_WAIT_REMOVAL` 블록 내부는 원본 코드를 그대로 복사해야 합니다!

---

### Step 4 — getStateName() 함수는 그대로!

**위치**: StateMachine.cpp 287~299라인

**❌ 수정하지 않습니다!**  
원본 그대로 유지:
```cpp
const char* getStateName(SystemState state) {
  switch (state) {
    case STATE_IDLE:            return L(SN_IDLE);
    case STATE_VACUUM_ON:       return L(SN_VAC_ON);
    case STATE_VACUUM_HOLD:     return L(SN_VAC_HOLD);
    case STATE_VACUUM_BREAK:    return L(SN_VAC_BREAK);
    case STATE_WAIT_REMOVAL:    return L(SN_WAIT_REM);
    case STATE_COMPLETE:        return L(SN_COMPLETE);
    case STATE_ERROR:           return L(SN_ERROR);
    case STATE_EMERGENCY_STOP:  return L(SN_EMERGENCY);
    default:                    return L(SN_UNKNOWN);
  }
}
```

---

### Step 5 — StateMachine.h 헤더 수정

**파일**: `include/StateMachine.h`

함수 선언 추가:
```cpp
// 기존 선언
void updateStateMachine();
void changeState(SystemState newState);
const char* getStateName(SystemState state);

// [K3] 추가
void initStateMachine();  // Mutex 초기화
```

---

### Step 6 — main.cpp setup() 호출 추가

**파일**: `src/main.cpp`

**위치**: `setup()` 함수 내부

```cpp
void setup() {
  Serial.begin(115200);
  
  // ... 기존 초기화 ...
  
  // [K3] StateMachine Mutex 초기화
  initStateMachine();
  
  // ... 나머지 초기화 ...
}
```

---

## 📋 전체 수정 요약

```
수정 파일:
  ✅ src/StateMachine.cpp
     - 25라인: Mutex 변수 추가
     - 199라인 위: initStateMachine() 함수 추가
     - 199~284라인: changeState() 본체 교체
     - 287~299라인: getStateName() 그대로 유지 (수정 안 함!)
  
  ✅ include/StateMachine.h
     - 함수 선언 추가: void initStateMachine();
  
  ✅ src/main.cpp
     - setup() 내: initStateMachine() 호출 추가
```

---

## ⚠️ 주의사항

### 1. changeState() 본체 교체 시

원본의 `STATE_WAIT_REMOVAL` 블록 내부에 있는 로직을 **반드시 그대로 복사**하세요:

```cpp
if (newState == STATE_WAIT_REMOVAL) {
    holdExtensionCount = 0;
    // ← 원본에 있는 나머지 코드 여기 복사
    // (제거 대기 타이머, 로깅 등)
}
```

### 2. getStateName()은 절대 수정 안 함!

- L() 매크로 사용 (다국어 지원)
- 9개 상태 모두 포함
- 제가 제공한 간략 버전은 무시하세요!

### 3. Mutex는 setup()에서 초기화

`initStateMachine()`을 반드시 `setup()`에서 호출해야 합니다.

---

## ✅ 체크리스트

```
□ StateMachine.cpp 25라인: Mutex 변수 추가
□ StateMachine.cpp 199라인 위: initStateMachine() 추가
□ StateMachine.cpp 199~284라인: changeState() 교체
    □ STATE_WAIT_REMOVAL 블록 내부 원본 로직 복사
    □ Mutex acquire/release 코드 포함
□ StateMachine.cpp 287라인: getStateName() 그대로 유지
□ StateMachine.h: initStateMachine() 선언 추가
□ main.cpp: initStateMachine() 호출 추가
```

---

## 요약

**질문 1 답변**: 아니요, changeState() 본체만 교체합니다.  
**질문 2 답변**: 제 실수입니다. getStateName()은 수정하지 않습니다!

제가 제공한 StateMachine_mutex.cpp는 **참고용**이며,  
실제로는 **위 6단계**를 따라 수정하세요.
