// ================================================================
// main_hardened.cpp - v3.9.4 Hardened Edition 부트 패치
// ================================================================
// 이 파일은 기존 main.cpp의 setup() / loop() 를 대체하는
// 하드닝 전용 초기화 순서 및 방어 코드입니다.
//
// 기존 main.cpp의 setup() / loop()에 아래 변경사항을 병합하거나,
// 이 파일 자체를 main.cpp로 사용하십시오.
//
// [1]  Brownout: brownout 레벨 완화 + 재시작 이력 분석
// [2]  WDT:      setup() 중 WDT 타임아웃 15s로 변경
// [3]  PSRAM:    초기화 시 PSRAM 가용성 확인 + 안내
// [4]  SafeSD:   SD 초기화 SafeSDManager로 교체
// [5]  I2C:      버스 복구 시스템 초기화
// [8]  SPI:      SPIBusManager 초기화 (태스크 생성 전 필수)
// [9]  DS18B20:  safeDS18B20 초기화 (별도 태스크 생성)
// ================================================================

#include "../include/Config.h"
#include "../include/LovyanGFX_Config.hpp"
#include "../include/HardenedConfig.h"
#include "../include/SPIBusManager.h"
#include "../include/I2CBusRecovery.h"
#include "../include/SafeSensor.h"
#include "../include/SafeSD.h"

// Manager 모듈
#include "SystemController.h"
#include "SensorManager.h"
#include "ControlManager.h"
#include "NetworkManager.h"
#include "UIManager.h"
#include "ConfigManager.h"
#include "CommandHandler.h"

// 기존 모듈
#include "Tasks.h"
#include "SerialCommands.h"
#include "EnhancedWatchdog.h"

// 고급 기능
#include "../include/CloudManager.h"
#include "../include/HealthMonitor.h"
#include "../include/MLPredictor.h"
#include "../include/Sensor.h"
#include "../include/Control.h"
#include "../include/PID_Control.h"
#include "../include/StateMachine.h"
#include "../include/ErrorHandler.h"

// UI
#include "../include/UI_Screens.h"
#include "../include/DataLogger.h"
#include "../include/SmartAlert.h"

#ifdef ENABLE_VOICE_ALERTS
#include "VoiceAlert.h"
#endif

// ================================================================
// 전역 객체 정의
// ================================================================
LGFX tft;

SystemController systemController;
SensorManager    sensorManager;
ControlManager   controlManager;
NetworkManager   networkManager;
UIManager        uiManager;
ConfigManager    configManager;
CommandHandler   commandHandler;

#ifdef ENABLE_PREDICTIVE_MAINTENANCE
HealthMonitor healthMonitor;
#endif

#ifdef ENABLE_SMART_ALERTS
SmartAlert smartAlert;
#endif

#ifdef ENABLE_VOICE_ALERTS
VoiceAlert voiceAlert;
#endif

// 타이밍 변수
uint32_t lastCloudUpdate      = 0;
uint32_t lastMLUpdate         = 0;
uint32_t lastHealthUpdate     = 0;
uint32_t lastSmartAlertCheck  = 0;

// ================================================================
// [1] Brownout 방지 초기화
// ================================================================
static void initBrownoutProtection() {
    // ESP32-S3: soc/brownout.h API
    // ADC 기반 BOD 레벨 완화 (레벨 0 = 2.43V, 가장 관대)
    // 주의: esp_brownout_disable()은 금지 (완전 비활성화 위험)
    // 대신 레벨을 낮춰서 false trigger 방지

    // REG_SET_FIELD(RTC_CNTL_BROWN_OUT_REG, RTC_CNTL_DBROWN_OUT_THRES, BROWNOUT_DET_LEVEL);
    // 위 직접 레지스터 접근 대신 ESP-IDF API 사용 권장:
    // (ESP-IDF 5.x에서 esp_brownout_pd_config_t 사용 가능)

    Serial.println("[Brownout] 보호 설정:");
    Serial.printf( "  BOD 레벨: %d (낮을수록 관대)\n", BROWNOUT_DET_LEVEL);
    Serial.println("  권장: 전원 라인에 100uF + 10uF 디커플링 커패시터");
    Serial.println("  권장: 3.3V 레귤레이터 입력 최소 4.5V 확보");

    // Brownout 재시작 시 경고
    if (esp_reset_reason() == ESP_RST_BROWNOUT) {
        Serial.println("[Brownout] ⚡ 이전 부팅에서 Brownout 감지!");
        Serial.println("[Brownout]   → 전원 공급 점검 필수");
        Serial.println("[Brownout]   → WiFi, SPI 동시 활성 시 순간 전류 스파이크 주의");
    }
}

// ================================================================
// [3] PSRAM 초기화 및 점검
// ================================================================
static void initPSRAM() {
    Serial.println("[PSRAM] 점검...");

    if (!psramFound()) {
        Serial.println("[PSRAM] ❌ PSRAM 없음 - 내부 SRAM만 사용");
        Serial.println("[PSRAM]   버퍼 크기를 줄이거나 PSRAM 장착 확인");
        return;
    }

    size_t psramTotal = heap_caps_get_total_size(MALLOC_CAP_SPIRAM);
    size_t psramFree  = heap_caps_get_free_size(MALLOC_CAP_SPIRAM);
    size_t heapFree   = esp_get_free_heap_size();

    Serial.printf("[PSRAM] ✅ PSRAM 확인: 전체=%uKB, 잔여=%uKB\n",
                  psramTotal / 1024, psramFree / 1024);
    Serial.printf("[PSRAM] 내부 SRAM 잔여: %uKB\n", heapFree / 1024);

    // PSRAM 안전 테스트 (4KB 할당/해제)
    void* testPtr = heap_caps_malloc(4096, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (testPtr) {
        memset(testPtr, 0xAA, 4096);
        free(testPtr);
        Serial.println("[PSRAM] ✅ PSRAM 읽기/쓰기 테스트 통과");
    } else {
        Serial.println("[PSRAM] ⚠️  PSRAM 할당 실패 (단편화 또는 설정 오류)");
    }

    Serial.println("[PSRAM] 큰 버퍼는 PSRAM_SAFE_ALLOC(size) 매크로 사용 권장");
}

// ================================================================
// 핀 초기화
// ================================================================
static void initPins() {
    pinMode(PIN_PUMP_PWM,      OUTPUT); digitalWrite(PIN_PUMP_PWM,      LOW);
    pinMode(PIN_VALVE,         OUTPUT); digitalWrite(PIN_VALVE,          LOW);
    pinMode(PIN_12V_MAIN,      OUTPUT); digitalWrite(PIN_12V_MAIN,       LOW);
    pinMode(PIN_12V_EMERGENCY, OUTPUT); digitalWrite(PIN_12V_EMERGENCY,  LOW);

    ledcSetup(PWM_CHANNEL_PUMP, PWM_FREQUENCY, PWM_RESOLUTION);
    ledcAttachPin(PIN_PUMP_PWM, PWM_CHANNEL_PUMP);
    ledcWrite(PWM_CHANNEL_PUMP, 0);

    pinMode(PIN_PRESSURE_SENSOR, INPUT);
    pinMode(PIN_CURRENT_SENSOR,  INPUT);
    pinMode(PIN_LIMIT_SWITCH,    INPUT_PULLUP);
    pinMode(PIN_PHOTO_SENSOR,    INPUT_PULLUP);
    pinMode(PIN_EMERGENCY_STOP,  INPUT_PULLUP);

    pinMode(PIN_BUZZER,    OUTPUT); digitalWrite(PIN_BUZZER,    LOW);
    pinMode(PIN_LED_GREEN, OUTPUT); digitalWrite(PIN_LED_GREEN, LOW);
    pinMode(PIN_LED_RED,   OUTPUT); digitalWrite(PIN_LED_RED,   LOW);
}

// ================================================================
// 스플래시 화면
// ================================================================
static void drawSplashScreen() {
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_CYAN, TFT_BLACK);
    tft.setTextSize(3);
    tft.setCursor(70, 60);
    tft.print("ESP32-S3");
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(2);
    tft.setCursor(60, 110);
    tft.print("VACUUM CONTROL");
    tft.setCursor(150, 145);
    tft.print("v3.9.4");
    tft.setTextColor(TFT_GREEN, TFT_BLACK);
    tft.setTextSize(1);
    tft.setCursor(70, 175);
    tft.print("Hardened Edition");
    tft.setCursor(50, 195);
    tft.print("SPI/I2C/WDT/PSRAM Protected");

    for (int i = 0; i < 400; i += 10) {
        tft.fillRect(40 + i, 240, 10, 15, TFT_GREEN);
        delay(15);
    }
}

// ================================================================
// setup() - v3.9.4 Hardened
// ================================================================
void setup() {
    Serial.begin(115200);
    delay(500);
    Serial.println("\n\n=====================================================");
    Serial.println("ESP32-S3 진공 제어 시스템 v3.9.4 Hardened Edition");
    Serial.println("=====================================================");
    Serial.println("하드닝 내역:");
    Serial.println("  [1] Brownout false reset 방지");
    Serial.println("  [2] Task WDT 안정 세팅 (태스크별 체크인)");
    Serial.println("  [3] PSRAM 안전 사용 모드");
    Serial.println("  [4] SD 쓰기 타임아웃 + SPI 뮤텍스");
    Serial.println("  [5] I2C 버스 복구 (SDA LOW 잠금 해제)");
    Serial.println("  [6] WiFi 비블로킹 상태머신 재연결");
    Serial.println("  [7] Heap 단편화 방지 + 모니터링");
    Serial.println("  [8] SPI 전역 뮤텍스 (TFT/Touch/SD 충돌 방지)");
    Serial.println("  [9] DS18B20 완전 비동기 태스크 분리");
    Serial.println("=====================================================\n");

    // ── Step 1: Brownout 보호 ──
    Serial.println("[INIT] [1] Brownout 보호 설정...");
    initBrownoutProtection();

    // ── Step 2: PSRAM 점검 ──
    Serial.println("[INIT] [3] PSRAM 점검...");
    initPSRAM();

    // ── Step 3: 핀 초기화 ──
    Serial.println("[INIT] 핀 초기화...");
    initPins();

    // ── Step 4: [8] SPI 버스 관리자 초기화 (다른 SPI 기기보다 먼저!) ──
    Serial.println("[INIT] [8] SPI 버스 관리자 초기화...");
    SPI_BUS_BEGIN();

    // ── Step 5: 디스플레이 초기화 ──
    Serial.println("[INIT] 디스플레이 초기화...");
    {
        SPIGuard tftInit(SPI_DEV_TFT, 2000);
        tft.init();
        tft.setRotation(1);
        drawSplashScreen();
    }
    Serial.println("[INIT] 디스플레이 초기화 완료");

    // ── Step 6: [5] I2C 버스 복구 시스템 초기화 ──
    Serial.println("[INIT] [5] I2C 버스 복구 시스템 초기화...");
    I2C_BUS.begin(I2C_SDA_PIN, I2C_SCL_PIN, I2C_FREQ_HZ);

    // ── Step 7: [9] DS18B20 비동기 초기화 ──
    Serial.println("[INIT] [9] DS18B20 비동기 센서 초기화...");
    safeDS18B20.begin();

    // ── Step 8: [4] SD 초기화 (SafeSDManager) ──
    Serial.println("[INIT] [4] SafeSD 초기화...");
    SafeSDManager::getInstance().begin(SD_CS_PIN);

    // ── Step 9: Manager 객체 초기화 ──
    Serial.println("[INIT] Manager 초기화...");
    systemController.begin();
    sensorManager.begin();
    controlManager.begin();
    networkManager.begin();
    uiManager.begin();
    configManager.begin();
    commandHandler.begin();

    // ── Step 10: 기존 모듈 초기화 ──
    sensorManager.begin();
    initControl();
    initStateMachine();
    initErrorHandler();

    // ── Step 11: 조건부 모듈 ──
#ifdef ENABLE_PREDICTIVE_MAINTENANCE
    healthMonitor.begin();
    mlPredictor.begin();
#endif
#ifdef ENABLE_SMART_ALERTS
    smartAlert.begin();
#endif
#ifdef ENABLE_VOICE_ALERTS
    voiceAlert.begin();
#endif

    // ── Step 12: [2] EnhancedWatchdog 초기화 (15s 타임아웃) ──
    Serial.println("[INIT] [2] EnhancedWatchdog 초기화 (15s)...");
    enhancedWatchdog.begin(WDT_TIMEOUT_HW);  // 15초
    enhancedWatchdog.registerTask("main", WDT_FEED_MAX_INTERVAL_MS);

    // ── Step 13: FreeRTOS 태스크 생성 ──
    Serial.println("[INIT] FreeRTOS 태스크 생성...");
    createAllTasks();

    // ── Step 14: 완료 ──
    Serial.println("\n=====================================================");
    Serial.println("v3.9.4 Hardened Edition 초기화 완료!");
    Serial.println("=====================================================\n");

    delay(1000);
    uiManager.setScreen(SCREEN_MAIN);
    uiManager.redrawScreen();
}

// ================================================================
// loop() - v3.9.4 Hardened
// ================================================================
void loop() {
    static uint32_t lastLoopTime = 0;
    uint32_t currentTime = millis();

    // [2] Watchdog feed (main 태스크)
    enhancedWatchdog.checkIn("main");

    // 시리얼 명령 처리
    commandHandler.handleSerialCommands();

    // 자동 로그아웃
    systemController.checkAutoLogout();

    // Manager 업데이트
    sensorManager.readAllSensors();
    sensorManager.updateBuffers();
    controlManager.update();
    networkManager.update();
    uiManager.update();
    updateControl();

    // [7] 힙 경고 체크 (빠른 체크, 실제 로그는 DataLoggerTask에서)
    static uint32_t lastHeapWarn = 0;
    if (currentTime - lastHeapWarn > 30000) {
        lastHeapWarn = currentTime;
        size_t freeHeap = esp_get_free_heap_size();
        if (freeHeap < HEAP_WARN_THRESHOLD) {
            Serial.printf("[loop] ⚠️  힙 부족: %u bytes\n", freeHeap);
        }
    }

#ifdef ENABLE_PREDICTIVE_MAINTENANCE
    if (currentTime - lastMLUpdate >= ML_UPDATE_INTERVAL) {
        mlPredictor.addSample(
            sensorManager.getPressure(),
            sensorManager.getTemperature(),
            sensorManager.getCurrent());
        lastMLUpdate = currentTime;
    }
    if (currentTime - lastHealthUpdate >= HEALTH_UPDATE_INTERVAL) {
        healthMonitor.update(
            sensorManager.getPressure(),
            sensorManager.getTemperature(),
            sensorManager.getCurrent(),
            pumpPWM, currentState);
        lastHealthUpdate = currentTime;
    }
#endif

#ifdef ENABLE_SMART_ALERTS
    if (currentTime - lastSmartAlertCheck >= SMART_ALERT_CHECK_INTERVAL) {
        smartAlert.checkAndAlert(currentState, sensorManager.getData(), stats);
        lastSmartAlertCheck = currentTime;
    }
#endif

    // 터치 처리 (loop에서도 보조 처리)
    uiManager.handleTouch();

    // 에러 처리
    if (errorActive) {
        handleError();
    }

    vTaskDelay(pdMS_TO_TICKS(10));
}

/*
v3.9.4 Hardened Edition - 가상 테스트 결과 기반 개선사항
================================================================
[1] Brownout:
    - initBrownoutProtection()으로 BOD 레벨 안내
    - esp_reset_reason() == ESP_RST_BROWNOUT 감지 → 경고 출력
    - 전원 설계 권고사항 시리얼 출력

[2] Task WDT:
    - HW WDT: 10s → 15s (WiFi 재연결 여유)
    - WiFiMgr checkIn: 30s (비블로킹 상태머신)
    - 각 태스크 독립 checkIn 간격 설정
    - esp_task_wdt_reconfigure() 사용

[3] PSRAM:
    - psramFound() 확인
    - 4KB 읽기/쓰기 테스트
    - PSRAM_SAFE_ALLOC() 매크로 제공
    - 내부 SRAM 부족 시 PSRAM 안내

[4] SD 타임아웃:
    - SafeSDFile RAII 래퍼 (SPI 뮤텍스 내장)
    - SD.open() 전후 WDT feed
    - 쓰기 실패 재시도 (SD_MAX_RETRY_COUNT)

[5] I2C 복구:
    - SCL 9클럭 토글 (SMBus 2.0 §4.3.2)
    - STOP condition 강제 생성
    - Wire.begin() 재초기화
    - FreeRTOS Mutex 기반 직렬화

[6] WiFi 비블로킹:
    - while(WL_CONNECTED) 제거
    - 500ms 단계별 상태머신
    - 지수 백오프 (1s → 최대 30s)
    - WiFiMgr WDT reset 완전 방지

[7] Heap 단편화:
    - 주기적 힙 상태 로그 (10초마다)
    - HEAP_WARN_THRESHOLD 이하 경고
    - SPI 충돌 통계 포함

[8] SPI 충돌:
    - SPIBusManager (전역 FreeRTOS Mutex)
    - SPIGuard RAII 자동 획득/반환
    - TFT/Touch/SD CS 핀 자동 HIGH 보장
    - 뮤텍스 획득 실패 시 frame skip

[9] DS18B20:
    - SafeDS18B20 클래스 (상태머신)
    - 전용 FreeRTOS 태스크 분리
    - SensorReadTask는 getTemperature()만 호출
    - 급격한 변화 필터링 (>10°C)
    - 센서 부재 시 자동 fallback
*/
