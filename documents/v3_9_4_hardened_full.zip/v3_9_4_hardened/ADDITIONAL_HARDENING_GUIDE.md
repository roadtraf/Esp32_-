# v3.9.4 Hardened Edition - 추가 발견 취약점 분석 보고서

> 가상 하드웨어 테스트 중 자체 발견한 추가 항목입니다.

---

## [A] 공유 전역변수 멀티태스크 동시접근 (Race Condition)

### 재현 조건
- `SensorReadTask(Core1)`: `sensorData` 구조체 전체 갱신 중
- `UIUpdateTask(Core1)`: `sensorData.pressure` 읽어서 화면 출력
- `ControlTask(Core1)`: `sensorData.current`로 PID 계산

### 발생하는 문제
```
SensorTask 쓰기:  pressure=-80.0 | current=3.5 | temp=... (갱신 중)
UITask 읽기:      pressure=-80.0 | current=0.0 (갱신 전 값 혼재)
→ UI에 순간적으로 전류 0A 표시 → 오경보 트리거 가능
```
`SensorData`는 28바이트 구조체 → 32비트 CPU에서 원자적 복사 불가

### 해결
- `SharedStateManager::readSensorData()` / `writeSensorData()` Mutex 래퍼
- `stats`, `currentState` 도 동일하게 보호

### 적용
```cpp
// 기존 (위험)
sensorData.pressure = readPressure();  // SensorTask
float p = sensorData.pressure;         // UITask

// 개선 (안전)
SensorData snap = SHARED_STATE.readSensorData();  // UITask
float p = snap.pressure;
```

---

## [B] PWM 채널 동시 Write - 모터 제어 불안정

### 재현 조건
- `Control.cpp(vacuumControlStep)`: `ledcWrite(0, pumpPWM)`
- `ControlManager.cpp(update)`:     `ledcWrite(0, pwm)`
- `UIManager.cpp(setBacklight)`:    `ledcWrite(1, brightness)` ← 채널 다름, 무해
- **단**: Control.cpp와 ControlManager.cpp 양쪽에서 채널 0 동시 Write

### 발생하는 문제
```
VacuumCtrl Task → ledcWrite(0, 180)  // 진공 ON
loop() Task     → ledcWrite(0, 0)    // ControlManager update
→ 펌프가 100ms마다 0→180→0 반복 → 인덕터 전류 스파이크
→ 전원 노이즈 → Brownout 트리거
```

### 해결
```cpp
// 기존
ledcWrite(PWM_CHANNEL_PUMP, pumpPWM);

// 개선
SAFE_PWM_WRITE(PWM_CHANNEL_PUMP, pumpPWM);
// 내부적으로 Mutex 사용
```

---

## [C] NVS(Preferences) 동시 Write - Flash Corruption

### 재현 조건
- `EnhancedWatchdog`의 `saveRestartInfo()`: `wdtPrefs.putUInt(...)` 다수
- `SystemController`의 `prefs.putUChar("lastMode", ...)` : 모드 변경 시
- `SmartAlert`의 `preferences.putXxx(...)`: 설정 저장 시
- 모두 동일 Preferences 라이브러리 (내부 NVS 파티션 공유)

### 발생하는 문제
- NVS는 파티션 단위 write → 동시 접근 시 내부 B-tree 손상 가능
- 증상: 재부팅 후 설정값 초기화, 또는 NVS 파티션 포맷 필요

### 해결
```cpp
// 기존
preferences.begin("key");
preferences.putUInt("val", data);
preferences.end();

// 개선 (NVSGuard RAII)
{
    NVSGuard nvs;
    if (!nvs.acquired()) return;
    preferences.begin("key");
    preferences.putUInt("val", data);
    preferences.end();
}
```

---

## [D] Serial.print 멀티태스크 경쟁 - 로그 오염

### 재현 조건
- 8개 FreeRTOS 태스크 + loop() 모두 `Serial.printf()` 호출
- ESP32 HardwareSerial은 내부 128바이트 링버퍼 + ISR 기반
- 멀티코어에서 동시 호출 시 출력 뒤섞임

### 발생하는 문제
```
정상: [WiFi] 연결 성공
오염: [Wi[Sensor] 압력: -80Fi] 연결 성공
→ 시리얼 모니터 파싱 불가, 디버깅 혼란
```

### 해결
```cpp
// 기존
Serial.printf("[WiFi] 연결 성공\n");

// 개선
SAFE_LOG("[WiFi] 연결 성공\n");
// 릴리즈 빌드에서는 자동 비활성화 (오버헤드 0)
```

---

## [E] 스택 오버플로우 - SmartAlert 이메일 함수

### 재현 조건
- `MQTTHandler Task` 스택: 4096바이트
- `SmartAlert::sendEmail()` 호출:
  - `char emailBody[1024]` 로컬 변수 → 스택에 할당
  - `char cmd[256]`, `char user64[128]`, `char pwd64[128]`
  - 총 스택 사용량: ~1.5KB (로컬변수만)
  - + FreeRTOS context: ~1KB
  - + 함수 호출 깊이: ~0.5KB
  - **합계: 3KB → 4KB 스택 한계 초과 위험**

### 발생하는 문제
- 스택 오버플로우 → 인접 태스크/힙 메모리 오염
- `MQTTHandler Task`가 `WiFiMgr Task` 스택을 침범
- 증상: 무작위 크래시, WiFi 연결 실패, Guru Meditation Error

### 해결
```
MQTTHandler 스택: 4096 → 6144 bytes
UIUpdate 스택:    8192 → 10240 bytes (LovyanGFX 렌더링 고려)
```
`AdditionalHardening.h`의 `STACK_*` 상수 참조

### 진단 명령
```cpp
// 런타임 스택 여유 확인
checkStackWatermarks();  // OTA_Hardened.cpp
// 출력: [Stack] MQTTHandler: 128 words 여유 ⚠️ 위험
```

---

## [F] MQTT Callback에서 직접 changeState() - 크로스태스크 상태 변경

### 재현 조건
```cpp
// Network.cpp mqttCallback() - Core0에서 실행
if (strcmp(cmd, "START") == 0) {
    changeState(STATE_VACUUM_ON);  // ← Core1의 전역변수 직접 변경!
}
```

### 발생하는 문제
- `changeState()`는 Core1 VacuumCtrl Task가 소유한 `currentState` 변경
- Core0에서의 직접 변경 → 메모리 가시성 보장 안됨
- VacuumCtrl Task가 변경을 인식하지 못하거나, 중간 상태에서 읽을 수 있음
- 최악: STATE_VACUUM_ON으로 전환됐지만 PID 초기화 로직 미실행

### 해결
```cpp
// 기존 (위험)
changeState(STATE_VACUUM_ON);

// 개선 (안전 - Queue 경유)
SHARED_STATE.sendStateCmd(STATE_VACUUM_ON);

// VacuumCtrl Task에서 처리:
SharedStateManager::MQTTCommand cmd;
if (SHARED_STATE.receivePendingCmd(cmd)) {
    if (cmd.type == SharedStateManager::CMD_STATE_CHANGE) {
        changeState((SystemState)cmd.param);
    }
}
```

---

## [G] OTA 업데이트 중 하드웨어 미정지 - 안전 위험

### 재현 조건
- OTA 업데이트 시작 (플래시 에라이즈/라이트)
- ESP32 Flash 작업 중 캐시 비활성화 → 코드 실행 중단
- **VacuumCtrl Task도 멈춤** → 마지막 PWM 상태 유지
- 펌프 PWM이 180으로 켜진 상태에서 OTA 시작 → **펌프 계속 동작**

### 발생하는 문제
- 진공 과도 발생 → 제품 손상
- 과열/과전류 발생 가능
- OTA 중 전류 증가 → Brownout

### 해결 (OTA_Hardened.cpp)
```cpp
ArduinoOTA.onStart([]() {
    emergencyHardwareShutdown("OTA 시작");
    // → ledcWrite(0,0), 모든 핀 LOW
    delay(OTA_SAFE_SHUTDOWN_DELAY_MS);  // 500ms 확인 대기
});
```

---

## [H] ADC + WiFi 동시 사용

### ESP32 vs ESP32-S3 차이
| 항목 | ESP32 | ESP32-S3 |
|------|-------|----------|
| ADC2 + WiFi | **사용 불가** | 사용 가능 |
| GPIO4 (압력) | ADC2_CH0 ❌ | ADC1_CH3 ✅ |
| GPIO5 (전류) | ADC2_CH4 ❌ | ADC1_CH4 ✅ |

이 프로젝트는 **ESP32-S3** 사용 → 현재 핀 배치는 안전  
단, `analogRead()`는 재진입 불가 → Mutex 추가

### 추가 개선: 오버샘플링
```cpp
// 기존 (단일 샘플 - 노이즈 취약)
int raw = analogRead(PIN_PRESSURE_SENSOR);

// 개선 (4x 오버샘플링 + 이상값 제거)
int raw = SHARED_STATE.safeAnalogRead(PIN_PRESSURE_SENSOR);
```

---

## [I] DFPlayer UART 동시 접근 - 음성 시스템 중단

### 재현 조건
- 긴급 알람 발생 → `SmartAlert`가 `voiceAlert.play()` 호출
- 동시에 `StateMachine`에서도 `voiceAlert.play()` 호출
- DFPlayer UART 명령 중첩 → DFPlayer 내부 state machine 오류
- 이후 모든 재생 명령 무시 (전원 재인가 전까지)

### 해결
```cpp
// 기존 (위험)
voiceAlert.play(folder, track);  // 어디서든 직접 호출

// 개선 (큐 기반)
safeVoiceAlert.enqueue(folder, track, VOICE_PRI_ERROR);
// 전용 VoiceTask가 순차 재생
```

---

## [J] volatile 미선언 - 컴파일러 캐싱 문제

### 재현 조건 (컴파일러 최적화 -O2)
```cpp
// ControlTask (Core1)
while (currentState == STATE_VACUUM_ON) {  // 최적화로 레지스터에 고정
    updatePID();
}
// MQTT callback (Core0)이 currentState = STATE_IDLE로 변경해도
// ControlTask는 루프에서 빠져나오지 못함
```

### 해결
핵심 공유 변수에 `volatile` 또는 FreeRTOS Mutex 사용  
(FreeRTOS Mutex는 내부적으로 메모리 배리어 포함 → volatile 불필요)

```cpp
// Config.h 수정
volatile SystemState currentState;  // [J] 추가
volatile bool        errorActive;   // [J] 추가
volatile bool        sleepMode;     // [J] 추가
```

---

## [K] NTP 미동기화 시 1970년 파일명 생성

### 재현 조건
- 오프라인 환경 (WiFi 없음) 또는 NTP 동기화 전 로그 발생
- `time(nullptr) = 70` (1970-01-01 00:01:10)
- `strftime("%Y%m%d")` → `"19700101"`
- SD 파일명: `/reports/daily_19700101.txt`

### 발생하는 문제
- 매 부팅 시 같은 파일에 덮어쓰기 → 이전 로그 손실
- 파일 크기 계속 증가 (append) → SD 카드 고갈

### 해결
```cpp
// OTA_Hardened.cpp
void getSafeISO8601(char* buf, size_t bufSize) {
    if (isNTPSynced()) {
        // 정상 NTP 기반 타임스탬프
    } else {
        // BOOT+00:01:10 형식 (uptime 기반)
        snprintf(buf, bufSize, "BOOT+%02lu:%02lu:%02lu", ...);
    }
}
```

---

## [L] 비상정지 핀 디바운스 없음 - 채터링 오동작

### 재현 조건
- 기계적 버튼: 누를 때 5~50ms 동안 ON/OFF 채터링
- `digitalRead(PIN_EMERGENCY_STOP) == LOW` 를 100ms마다 폴링
- 채터링 중 LOW 감지 → 비상정지 상태 진입

### 발생하는 문제
- 의도하지 않은 비상정지 → 생산 라인 중단
- 특히 진동 환경에서 빈발

### 해결 (EStopDebouncer - SharedState.h)
```cpp
// SensorReadStep에서
bool rawStop = readEmergencyStop();
bool confirmedStop = eStopDebouncer.update(rawStop);

if (confirmedStop) {
    changeState(STATE_EMERGENCY_STOP);
}
```
- 20ms 안정화 + 3회 연속 확인 = 총 60ms 디바운스

---

## 적용 우선순위

| 우선순위 | 항목 | 위험도 | 난이도 |
|---------|------|--------|--------|
| **즉시** | [G] OTA 안전 정지 | 🔴 안전 | 낮음 |
| **즉시** | [F] MQTT 상태 Queue | 🔴 크래시 | 중간 |
| **즉시** | [L] 비상정지 디바운스 | 🔴 안전 | 낮음 |
| **높음** | [E] 스택 크기 조정 | 🟠 크래시 | 낮음 |
| **높음** | [B] PWM Mutex | 🟠 하드웨어 | 낮음 |
| **높음** | [A] SensorData Mutex | 🟠 데이터 | 중간 |
| **보통** | [I] VoiceAlert Queue | 🟡 기능 | 중간 |
| **보통** | [K] NTP 파일명 보호 | 🟡 데이터 | 낮음 |
| **낮음** | [C] NVS Mutex | 🟢 설정 손실 | 낮음 |
| **낮음** | [D] Serial Mutex | 🟢 디버그 | 낮음 |
| **낮음** | [H] ADC 오버샘플링 | 🟢 정확도 | 낮음 |
| **낮음** | [J] volatile 선언 | 🟢 가시성 | 낮음 |

---

## 신규 파일 요약

```
include/AdditionalHardening.h   ← 추가 방어 설정 상수
include/SharedState.h           ← [A][B][C][D][F][H][L] 공유 상태 보호
include/VoiceAlert_Hardened.h   ← [I] DFPlayer 큐 기반 안전 재생
src/OTA_Hardened.cpp            ← [G][E][K] OTA/스택/NTP 보호
```
