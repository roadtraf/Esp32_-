# v3.9.4 Hardened Edition - 가상 하드웨어 테스트 기반 업그레이드 가이드

---

## 테스트 시나리오 → 문제 → 해결 요약

### [1] Brownout false reset

| 항목 | 내용 |
|------|------|
| **재현 조건** | WiFi + SPI 동시 활성화 시 순간 전류 스파이크 → VCC 순간 강하 |
| **기존 증상** | `rst:0xc (SW_CPU_RESET)` 반복, `BROWNOUT_RST` |
| **원인** | BOD 레벨 기본값(레벨 7 ≈ 3.00V)이 너무 민감 |
| **해결** | `HardenedConfig.h`: `BROWNOUT_DET_LEVEL=0` (2.43V) |
| **추가** | `esp_reset_reason()==ESP_RST_BROWNOUT` 감지 시 경고 + 전원 점검 안내 |
| **하드웨어 권장** | 3.3V 라인: 100μF 전해 + 10μF 세라믹 병렬, 벌크 캐패시터 |

---

### [2] Task Watchdog 안정 세팅

| 항목 | 내용 |
|------|------|
| **재현 조건** | `connectWiFi()` → `WiFi.begin()` + `while(WL_CONNECTED)` 최대 10s 블로킹 |
| **기존 증상** | `Task watchdog got triggered. The following tasks did not reset the watchdog in time: WiFiMgr` |
| **원인** | HW WDT=10s, WiFiMgr 블로킹=10s → 동일하여 간헐적 reset |
| **해결** | HW WDT: **10s → 15s** (`WDT_TIMEOUT_HW`) |
| | WiFiMgr: 비블로킹 상태머신 (500ms 단계, `[6]`과 연동) |
| | 각 태스크별 체크인 간격 최적화 (`WDT_TIMEOUT_TASK_*`) |
| **파일** | `EnhancedWatchdog_Hardened.cpp`, `Tasks_Hardened.cpp` |

**태스크별 WDT 체크인 간격:**
```
VacuumCtrl  : 3,000ms  (100ms 주기 × 30 여유)
SensorRead  : 3,000ms
UIUpdate    : 5,000ms  (렌더링 길어질 수 있음)
WiFiMgr     : 30,000ms (비블로킹이지만 여유 확보)
MQTTHandler : 10,000ms
DataLogger  : 5,000ms
DS18B20     : 5,000ms
```

---

### [3] PSRAM 안전 사용 모드

| 항목 | 내용 |
|------|------|
| **재현 조건** | `std::vector<float>` 버퍼 × 3개, 각 100 샘플 → 내부 SRAM 고갈 |
| **기존 증상** | `assert failed: tlsf_malloc tlsf.c` 또는 `Guru Meditation Error: Core 0 panic'ed` |
| **원인** | 모든 할당이 내부 SRAM → 단편화 후 대형 블록 할당 실패 |
| **해결** | `PSRAM_SAFE_ALLOC(size)` 매크로: 1KB 이상 → PSRAM 자동 전환 |
| | 초기화 시 PSRAM 4KB 읽기/쓰기 테스트 |
| | 힙 잔여량 주기적 로그 (10초마다) |
| **파일** | `HardenedConfig.h`, `main_hardened.cpp:initPSRAM()` |

**사용 예:**
```cpp
// 기존 (위험)
float* buf = (float*)malloc(1000 * sizeof(float));

// 개선 (안전)
float* buf = (float*)PSRAM_SAFE_ALLOC(1000 * sizeof(float));
// 사용 후:
PSRAM_SAFE_FREE(buf);
```

---

### [4] SD 쓰기 타임아웃

| 항목 | 내용 |
|------|------|
| **재현 조건** | SD 카드 접촉 불량 + SPI 충돌 동시 발생 |
| **기존 증상** | `SD.open()` 무한 대기 → DataLoggerTask WDT reset |
| **원인** | `SD.open()`이 내부적으로 SPI를 직접 점유, 타임아웃 없음 |
| **해결** | `SafeSDFile` RAII 래퍼: SPI 뮤텍스 획득 후 SD 접근 |
| | 접근 전 `WDT_FEED()` 삽입 |
| | 실패 시 `SD_MAX_RETRY_COUNT`(3회) 재시도 |
| **파일** | `SafeSD.h`, `SD_Logger_Hardened.cpp` |

---

### [5] I2C 버스 복구

| 항목 | 내용 |
|------|------|
| **재현 조건** | 센서 전원 순간 OFF/ON → 슬레이브가 READ 중 리셋 → SDA LOW 고정 |
| **기존 증상** | `Wire.endTransmission()` 반환 4 반복, 이후 모든 I2C 통신 불가 |
| **원인** | 슬레이브 state machine이 SDA를 LOW로 잡은 채 RESET → 마스터가 해제 불가 |
| **해결** | SMBus 2.0 §4.3.2 복구 프로시저: |
| | 1. `Wire.end()` + GPIO 직접 제어 전환 |
| | 2. SCL **9클럭** 토글 (어떤 state에서도 슬레이브 리셋) |
| | 3. STOP condition 강제 생성 (SDA LOW→HIGH, SCL HIGH) |
| | 4. `Wire.begin()` 재초기화 + 200ms 안정화 대기 |
| **파일** | `I2CBusRecovery.h` |

**SDA LOW 해제 확인:**
```
[I2C] === 버스 복구 시작 ===
[I2C] SCL 9클럭 토글 중...
[I2C] SDA 해제 확인 (5번째 클럭)    ← 정상 복구
[I2C] ✅ 복구 성공
```

---

### [6] WiFi reconnect blocking

| 항목 | 내용 |
|------|------|
| **재현 조건** | AP 신호 약함 → `WiFi.begin()` 후 `WL_CONNECTED` 대기 중 10s 경과 |
| **기존 코드** | `while(WiFi.status() != WL_CONNECTED && millis()-start < 10000)` |
| **기존 증상** | WiFiMgr Task가 10s 동안 WDT feed 불가 → reset |
| **해결** | 비블로킹 상태머신 (500ms 단계별 체크) |
| | 지수 백오프: 1s → 2s → 4s → ... → 최대 30s |
| **파일** | `Tasks_Hardened.cpp:wifiManagerStep()` |

**상태머신:**
```
IDLE → BEGIN → WAITING(500ms 단계) → CONNECTED
                    ↓ (20단계 실패)
               BACKOFF(지수, 최대30s) → BEGIN
```

---

### [7] Heap fragmentation

| 항목 | 내용 |
|------|------|
| **재현 조건** | 72시간 연속 운전 후 `push_back()` 반복 → 힙 단편화 |
| **기존 증상** | `malloc` 실패 (여유는 있지만 연속 블록 없음) |
| **원인** | `std::vector` 동적 재할당 반복, `String` 객체 생성/파괴 |
| **해결** | `CIRCULAR_BUFFER_SIZE=100` 고정 크기 순환 버퍼 사용 권장 |
| | 10초마다 힙 상태 로그 (`esp_get_minimum_free_heap_size()`) |
| | `heap_caps_get_largest_free_block()` 단편화 지표 모니터링 |
| | SRAM 부족 시 → PSRAM 전환 안내 |
| **파일** | `Tasks_Hardened.cpp:heapMonitorStep()` |

**힙 모니터 출력 예:**
```
[Heap] 잔여: 124832 | 최소: 98416 | 최대블록: 65536 | PSRAM: 7864320
[SPIBus] 타임아웃 발생: 0회, 현재 소유: 255
```

---

### [8] SPI 충돌 (ILI9488 + XPT2046 + SD)

| 항목 | 내용 |
|------|------|
| **재현 조건** | UITask: TFT 렌더링 중 → DataLoggerTask: SD 접근 동시 발생 |
| **기존 증상** | TFT 화면 깨짐, SD 파일 corruption, 또는 시스템 패닉 |
| **원인** | 동일 SPI2_HOST 공유, CS 핀 동시 LOW 가능성 |
| | LovyanGFX `use_lock=true` 설정돼있지만 SD와는 별개 |
| **해결** | `SPIBusManager`: 전역 FreeRTOS Mutex로 직렬화 |
| | `SPIGuard` RAII: 스코프 종료 시 자동 CS HIGH + Mutex 반환 |
| | 뮤텍스 획득 실패 시 → 해당 프레임 skip (데이터 보존 우선) |
| **파일** | `SPIBusManager.h` |

**SPI CS 핀 배치:**
```
ILI9488 TFT  : CS=10  (SPI_DEV_TFT)
XPT2046 Touch: CS=14  (SPI_DEV_TOUCH)
SD Card      : CS=46  (SPI_DEV_SD)
모두 동일: SCLK=12, MOSI=11, MISO=13
```

---

### [9] DS18B20 블로킹 → WDT reset

| 항목 | 내용 |
|------|------|
| **재현 조건** | SensorReadTask 100ms 주기 + `requestTemperatures()` 호출 |
| **기존 증상** | OneWire 통신 중 인터럽트 비활성화 → UI 프레임 드롭 |
| | 센서 부재 시 `getTempCByIndex()` 타임아웃 대기 |
| **원인** | DS18B20 12bit 변환: 750ms, OneWire 프로토콜 자체 블로킹 |
| **해결** | `SafeDS18B20`: 전용 FreeRTOS Task 분리 |
| | 상태머신: `IDLE → REQUEST → WAIT(750ms) → READ → IDLE` |
| | `SensorReadTask`는 `getTemperature()` 만 호출 (즉시 반환) |
| | 급격한 변화 필터링 (>10°C 는 노이즈로 무시) |
| | 센서 부재: 30초마다 재검색, fallback 25.0°C |
| **파일** | `SafeSensor.h`, `SafeSensor.cpp` |

---

## 파일 적용 방법

### 신규 파일 (include/)
```
include/HardenedConfig.h        ← 모든 방어 설정 상수
include/SPIBusManager.h         ← SPI 전역 뮤텍스 관리자
include/I2CBusRecovery.h        ← I2C 버스 복구 시스템
include/SafeSensor.h            ← DS18B20 비동기 래퍼
include/SafeSD.h                ← SD 안전 접근 래퍼
```

### 대체 파일 (src/)
```
src/Tasks_Hardened.cpp          ← Tasks.cpp 대체
src/SD_Logger_Hardened.cpp      ← SD_Logger.cpp 대체
src/EnhancedWatchdog_Hardened.cpp ← EnhancedWatchdog.cpp 대체
src/main_hardened.cpp           ← main.cpp 대체
src/SafeSensor.cpp              ← 신규 (DS18B20 태스크 구현)
```

### platformio.ini 변경
```
기존: [env:esp32-s3-release]
변경: [env:esp32-s3-hardened]  ← platformio_v394.ini 참조
```

---

## 빌드 전 체크리스트

- [ ] `HardenedConfig.h`의 핀 번호가 실제 하드웨어와 일치하는지 확인
  - `SD_CS_PIN`, `TOUCH_CS_PIN`, `TFT_CS_PIN`
  - `I2C_SDA_PIN`, `I2C_SCL_PIN`
  - `PIN_TEMP_SENSOR` (DS18B20)
- [ ] `platformio_v394.ini`를 `platformio.ini`로 복사 또는 내용 병합
- [ ] 기존 `Tasks.cpp` → `Tasks_Hardened.cpp` 로 교체
- [ ] 기존 `SD_Logger.cpp` → `SD_Logger_Hardened.cpp` 로 교체
- [ ] 기존 `EnhancedWatchdog.cpp` → `EnhancedWatchdog_Hardened.cpp` 로 교체
- [ ] `SafeSensor.cpp` 추가 (신규)
- [ ] `main.cpp` → `main_hardened.cpp` 로 교체

---

## 기대 효과

| 항목 | 기존 | v3.9.4 |
|------|------|--------|
| Brownout false reset | 간헐적 발생 | ESP_RST_BROWNOUT 감지 + 경고 |
| WiFiMgr WDT reset | 발생 가능 | 비블로킹으로 완전 방지 |
| SPI 충돌 | 발생 가능 | Mutex 직렬화로 방지 |
| DS18B20 블로킹 | 100ms마다 호출 | 별도 태스크, 비블로킹 |
| I2C SDA LOW 잠금 | 복구 불가 | SCL 9클럭 자동 복구 |
| SD 쓰기 무한 대기 | 가능 | SPI 뮤텍스 + WDT feed |
| 힙 단편화 감지 | 없음 | 10초마다 모니터링 |
| PSRAM 활용 | 수동 | PSRAM_SAFE_ALLOC 매크로 |
